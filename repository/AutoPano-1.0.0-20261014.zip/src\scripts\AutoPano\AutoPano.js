#engine v8
// AutoPano 1.0.0 for PixInsight - Copyright (c) 2026 BananAndrews. All rights reserved.
// Free to use. Modification, reverse engineering and redistribution of modified versions are not permitted.
#feature-id    AutoPano : Utilities > AutoPano
#feature-info  One-button mosaic of linear (unstretched) panels.<br/>\
   Plate-solves the panels if needed, refines their positions on the stars of \
   all overlaps at once, reprojects them, matches their photometry, joins them \
   along seams through the sky with multiband blending and makes the noise \
   change between panels gradual.
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "AutoPanoSolver"
#include "../ImageSolver/ImageSolver.js"
#undef TITLE
#undef VERSION
!function(){function t(t,r,e){for(var a=0,o=r-1;o>a;){for(var n=t[a+o>>1],i=a,s=o;i<=s;){for(;t[i]<n;)i++;for(;t[s]>n;)s--;if(i<=s){var h=t[i];t[i]=t[s],t[s]=h,
i++,s--}}if(e<=s)o=s;else{if(!(e>=i))return t[e];a=i}}return t[e]}function r(r,e){if(void 0===e&&(e=r.length),e<=0)return NaN
;for(var a=new Float64Array(e),o=0;o<e;o++)a[o]=r[o];var n=t(a,e,e>>1);if(1&e)return n;var i=-1/0;for(o=0;o<e>>1;o++)a[o]>i&&(i=a[o]);return.5*(i+n)}
function e(t,e){void 0===e&&(e=t.length);for(var a=r(t,e),o=new Float64Array(e),n=0;n<e;n++)o[n]=Math.abs(t[n]-a);return{med:a,sigma:1.4826*r(o,e)}}
function a(t,r,e){e=e||1;for(var a=0,o=t.length,n=0;n<o;n+=e)r&&!r[n]||a++;var i=new Float64Array(a),s=0;for(n=0;n<o;n+=e)r&&!r[n]||(i[s++]=t[n]);return i}
function o(t,r){return Math.sqrt(t*t+r*r)}function n(t){for(var r=[],e=0;e<t;e++)r.push(0);return r}function i(t,r,e){
for(var a=e.length===r&&"number"==typeof e[0]?[e]:e,o=0;o<r;o++){for(var n=t[o*r+o],i=0;i<o;i++)n-=t[o*r+i]*t[o*r+i];var s=n>1e-300?Math.sqrt(n):1e-150
;t[o*r+o]=s;for(var h=o+1;h<r;h++){var l=t[h*r+o];for(i=0;i<o;i++)l-=t[h*r+i]*t[o*r+i];t[h*r+o]=l/s}}for(var f=0;f<a.length;f++){var u=a[f];for(h=0;h<r;h++){
for(l=u[h],i=0;i<h;i++)l-=t[h*r+i]*u[i];u[h]=l/t[h*r+h]}for(h=r-1;h>=0;h--){for(l=u[h],i=h+1;i<r;i++)l-=t[i*r+h]*u[i];u[h]=l/t[h*r+h]}}return e}function s(t,r){
this.n=t,this.nrhs=r||1,this.M=new Float64Array(t*t),this.v=[];for(var e=0;e<this.nrhs;e++)this.v.push(new Float64Array(t))}function h(t,r,e){
for(var a=r*e,o=t.length,n=new Float32Array(a),i=0;i<o;i++)for(var s=t[i],h=0;h<a;h++)n[h]+=s[h];if(o>1)for(h=0;h<a;h++)n[h]/=o;return n}function l(t,r,e,a){
for(var o=Math.floor(r/a),n=Math.floor(e/a),i=new Float32Array(o*n),s=1/(a*a),h=0;h<n;h++)for(var l=0;l<a;l++)for(var f=(h*a+l)*r,u=h*o,c=0;c<o;c++){
for(var d=0,p=f+c*a,v=0;v<a;v++)d+=t[p+v];i[u+c]+=d}for(var m=0;m<i.length;m++)i[m]*=s;return{data:i,w:o,h:n}}function f(t,r,e,a,o){
for(var n=new Float32Array(a*o),i=r/a,s=e/o,h=new Int32Array(a),l=new Int32Array(a),f=new Float32Array(a),u=0;u<a;u++){
var c=Math.min(Math.max((u+.5)*i-.5,0),r-1),d=Math.floor(c);h[u]=d,l[u]=Math.min(d+1,r-1),f[u]=c-d}for(var p=0;p<o;p++){
var v=Math.min(Math.max((p+.5)*s-.5,0),e-1),m=Math.floor(v),w=v-m,g=m*r,y=Math.min(m+1,e-1)*r,x=p*a;for(u=0;u<a;u++){
var M=t[g+h[u]]+f[u]*(t[g+l[u]]-t[g+h[u]]),b=t[y+h[u]]+f[u]*(t[y+l[u]]-t[y+h[u]]);n[x+u]=M+w*(b-M)}}return n}function u(r,e,a,o){
var n=o>>1,i=new Float32Array(e*a),s=new Float64Array(o*o);function h(t,r){for(;t<0||t>=r;)t=t<0?-t-1:2*r-t-1;return t}for(var l=0;l<a;l++)for(var f=0;f<e;f++){
for(var u=0,c=-n;c<=n;c++)for(var d=h(l+c,a)*e,p=-n;p<=n;p++)s[u++]=r[d+h(f+p,e)];i[l*e+f]=t(s,u,u>>1)}return i}function c(t,r,e,a){return function(t,r,e,a){
var o=a.length-1>>1,n=new Float32Array(r*e),i=new Float32Array(r*e),s=new Float64Array(r+2*o),h=new Float64Array(r);function l(t,r){if(1===r)return 0
;for(;t<0||t>=r;)t=t<0?-t:2*r-2-t;return t}for(var f=0;f<e;f++){for(var u=f*r,c=-o;c<r+o;c++)s[c+o]=t[u+l(c,r)];for(var d=0;d<r;d++){
for(var p=0,v=0;v<a.length;v++)p+=a[v]*s[d+v];n[u+d]=p}}for(f=0;f<e;f++){for(d=0;d<r;d++)h[d]=0;for(v=0;v<a.length;v++){var m=a[v],w=l(f+v-o,e)*r
;for(d=0;d<r;d++)h[d]+=m*n[w+d]}for(u=f*r,d=0;d<r;d++)i[u+d]=h[d]}return i}(t,r,e,function(t){
for(var r=Math.max(1,Math.round(4*t)),e=new Float64Array(2*r+1),a=0,o=-r;o<=r;o++)e[o+r]=Math.exp(-o*o/(2*t*t)),a+=e[o+r];for(o=0;o<e.length;o++)e[o]/=a
;return e}(a))}function d(t,r,e){for(var a=new Int32Array(r*e),o=0;o<e;o++)for(var n=0;n<r;n++)if(t[h=o*r+n]){var i=n>0?a[h-1]:0,s=o>0?a[h-r]:0
;a[h]=Math.min(i,s)+1}else a[h]=0;for(o=e-1;o>=0;o--)for(n=r-1;n>=0;n--){var h;if(a[h=o*r+n]){i=n<r-1?a[h+1]:0,s=o<e-1?a[h+r]:0;var l=Math.min(i,s)+1
;l<a[h]&&(a[h]=l)}}return a}CoreApplication.ensureMinimumVersion(1,9,5),s.prototype.add=function(t,r,e){for(var a=this.n,o=this.M,n=0;n<a;n++){var i=t[n]
;if(0!==i){for(var s=e*i,h=n*a,l=0;l<a;l++)o[h+l]+=s*t[l];for(var f=0;f<this.nrhs;f++)this.v[f][n]+=s*r[f]}}},s.prototype.solve=function(t){
for(var r=this.n,e=new Float64Array(this.M),a=[],o=0;o<r;o++)e[o*r+o]+=t||0;for(var n=0;n<this.nrhs;n++)a.push(new Float64Array(this.v[n]));return i(e,r,a),a}
;function p(t,r){var e=t*Math.PI/180,a=r*Math.PI/180;return[Math.cos(a)*Math.cos(e),Math.cos(a)*Math.sin(e),Math.sin(a)]}function v(t){
var r=Math.atan2(t[1],t[0]),e=Math.asin(Math.max(-1,Math.min(1,t[2])));this.ra0=180*r/Math.PI,this.ra0<0&&(this.ra0+=360),this.dec0=180*e/Math.PI,this.t=t,
this.e=[-Math.sin(r),Math.cos(r),0],this.n=[-Math.sin(e)*Math.cos(r),-Math.sin(e)*Math.sin(r),Math.cos(e)]}function m(t,r){var e=t*t,a=e*t;r[0]=.5*(2*e-a-t),
r[1]=.5*(3*a-5*e+2),r[2]=.5*(-3*a+4*e+t),r[3]=.5*(a-e)}function w(t,r,e,a,o,n,i,s,h){var l=Math.floor(o),f=Math.floor(n);l<1?l=1:l>e-3&&(l=e-3),
f<1?f=1:f>a-3&&(f=a-3),m(o-l,s),m(n-f,h);for(var u=0,c=0,d=0;d<4;d++){for(var p=(f-1+d)*e+l-1,v=0,w=0,g=0;g<4;g++)v+=s[g]*t[p+g],w+=s[g]*r[p+g];u+=h[d]*v,
c+=h[d]*w}return i[0]=u,i[1]=c,i}function g(t,r,e){var a=t.grid;this.step=a.step,this.nx=a.nx,this.ny=a.ny,this.cx=r,this.cy=e,this.wx=new Float64Array(4),
this.wy=new Float64Array(4),this.tmp=[0,0]
;var o=(t.w-1)/2,n=(t.h-1)/2,i=this.fwd(o+8,n),s=this.fwd(o-8,n),h=this.fwd(o,n+8),l=this.fwd(o,n-8),f=(i[0]-s[0])/16,u=(i[1]-s[1])/16,c=(h[0]-l[0])/16,d=(h[1]-l[1])/16,p=f*d-c*u
;this.k11=d/p,this.k12=-c/p,this.k21=-u/p,this.k22=f/p,this.centre=this.fwd(o,n),this.xc=o,this.yc=n}function y(t,r,e){for(var a=[],o=0;o<e;o++){var n=o/e
;a.push([n*(t-1),0]),a.push([t-1,n*(r-1)]),a.push([(1-n)*(t-1),r-1]),a.push([0,(1-n)*(r-1)])}return a}function x(t){var r=t[0],e=-t[1],a=t[2],o=-t[3];return{
rot:180*Math.atan2(a,o)/Math.PI,parity:r*o-e*a<0?-1:1}}function M(t,r,e){this.c0=t,this.s=r,this.order=e,this.nb=[1,3,6,10][e],
this.cx=new Float64Array(this.nb),this.cy=new Float64Array(this.nb),this.phiBuf=new Float64Array(this.nb)}function b(t,e,a,o,n,i){function s(t,e,a){
for(var s=Math.min(i,a),h=Math.floor(e/10),l=e-Math.floor(e/10)-h,f=new Uint8Array(l),u=0;u<l;u++){for(var c=1,d=n;d<s&&c;d++)0===t(d,h+u)&&(c=0);f[u]=c}
var p=new Float64Array(s),v=new Float64Array(s),m=new Uint8Array(s),w=new Float64Array(l),g=new Float64Array(l);for(d=0;d<s;d++){var y=0,x=1;for(u=0;u<l;u++){
var M=t(d,h+u);0===M&&(x=0),f[u]&&(w[y++]=M)}m[d]=x;for(var b=0;b+1<y;b++)g[b]=w[b+1]-w[b];var A=r(g,y-1);for(b=0;b+1<y;b++)g[b]=Math.abs(g[b]-A)
;p[d]=1.4826*r(g,y-1)/Math.SQRT2,v[d]=r(w,y)}var k=r(p.subarray(n,s),s-n),F=0,S=0,C=0,B=0,I=s-n;for(d=n;d<s;d++)F+=d,S+=v[d],C+=d*d,B+=d*v[d]
;var z=(I*B-F*S)/(I*C-F*F),P=(S-z*F)/I;for(c=new Uint8Array(s),d=0;d<s;d++)c[d]=p[d]<1.1*k&&Math.abs(v[d]-(z*d+P))<.3*k&&m[d]?1:0;var T=o;for(d=0;d<o;d++){
for(var W=1,R=d;R<d+5;R++)if(!c[R]){W=0;break}if(W){T=d;break}}return T?T+2:0}return o=o||200,n=n||250,i=i||400,{top:s(function(r,a){return t[r*e+a]},e,a),
bottom:s(function(r,o){return t[(a-1-r)*e+o]},e,a),left:s(function(r,a){return t[a*e+r]},a,e),right:s(function(r,a){return t[a*e+(e-1-r)]},a,e)}}
function A(t,o,n,i){i=i||4e3
;for(var s=o*n,h=l(t,o,n,16),p=f(u(h.data,h.w,h.h,9),h.w,h.h,o,n),v=new Float32Array(s),m=new Uint8Array(s),w=0;w<s;w++)v[w]=t[w]-p[w],m[w]=t[w]>0?1:0
;for(var g=e(a(v,m,3)).sigma,y=c(v,o,n,1.2),x=e(a(y,m,3)).sigma,M=r(a(p,m,7)),b=d(m,o,n),A=6*x,k=[],F=5;F<n-5;F++)for(var S=5;S<o-5;S++)if(!(!((N=y[w=F*o+S])>A)||b[w]<=16||t[w]>.9||p[w]-M>=20*g)){
for(var C=!0,B=-5;B<=5&&C;B++)for(var I=w+B*o,z=-5;z<=5;z++)if(y[I+z]>N){C=!1;break}C&&k.push(w)}k.sort(function(t,r){return y[r]-y[t]}),
k.length>i&&(k.length=i);for(var P=13,T=new Float64Array(169),W={x:[],y:[],flux:[]},R=new Float64Array(52),G=0;G<k.length;G++){var q=k[G],L=q%o,j=(q-L)/o
;if(!(j<6||L<6||j>=n-6||L>=o-6)){for(var D=0;D<P;D++)for(w=0;w<P;w++)T[D*P+w]=v[(j-6+D)*o+L-6+w];var H=0;for(w=0;w<P;w++)R[H++]=T[w],R[H++]=T[156+w],
R[H++]=T[w*P],R[H++]=T[w*P+P-1];for(var U=r(R,H),V=0,E=0;E<169;E++){var N=T[E]-U;T[E]=N>0?N:0,V+=T[E]}if(!(V<=0)){var O=0,X=0
;for(D=0;D<P;D++)for(w=0;w<P;w++)O+=T[D*P+w]*(w-6),X+=T[D*P+w]*(D-6);O/=V,X/=V;var K=0,_=0;for(D=0;D<P;D++)for(w=0;w<P;w++){var Y=T[D*P+w];K+=Y*(w-6-O)*(w-6-O),
_+=Y*(D-6-X)*(D-6-X)}_/=V;var Z=(K/=V)/Math.max(_,1e-6);if(Z>.4&&Z<2.5){for(var J=!0,Q=0;Q<10;Q++){var $=0,tt=0,rt=0;for(D=0;D<P;D++)for(w=0;w<P;w++){
var et=w-6,at=D-6,ot=Math.exp(-((et-O)*(et-O)+(at-X)*(at-X))/4.5)*T[D*P+w];$+=ot,tt+=ot*et,rt+=ot*at}if($<=0){J=!1;break}tt/=$,rt/=$
;var nt=Math.abs(tt-O)+Math.abs(rt-X)<.001;if(O=tt,X=rt,nt)break}!J||Math.abs(O)>2||Math.abs(X)>2||(W.x.push(L+O),W.y.push(j+X),W.flux.push(V))}}}}return W}
function k(t,e){for(var a=t.length,n=0,i=0,s=0,h=new Float64Array(a),l=0;l<a;l++)n+=t[l],i+=e[l],h[l]=o(t[l],e[l]),s+=h[l]*h[l];return{n:a,dx:n/a,dy:i/a,
rms:Math.sqrt(s/a),med:r(h,a)}}function F(t,r){for(var e=0,a=t.length;e<a;){var o=e+a>>1;t[o]<r?e=o+1:a=o}return e/Math.max(t.length,1)}function S(t,r,e,a,n,i){
var s=t.stars[e],h=t.stars[a];function l(e,a){for(var o=t.maps[a],n=r[a],i=[],s=0;s<e.qx.length;s++){var h=o.inv(e.qx[s],e.qy[s])
;h[0]>20&&h[1]>20&&h[0]<n.w-20&&h[1]<n.h-20&&i.push(s)}return i}var f=l(s,a),u=l(h,e);if(f.length<5||u.length<5)return null;function c(t,r,e){
for(var a=new Float64Array(r.length),o=new Float64Array(r.length),n=0;n<r.length;n++){var s=i?i[e].apply(t.qx[r[n]],t.qy[r[n]]):[t.qx[r[n]],t.qy[r[n]]]
;a[n]=s[0],o[n]=s[1]}return{x:a,y:o}}for(var d=c(s,f,e),p=c(h,u,a),v=n,m={},w=0;w<u.length;w++){var g=Math.floor(p.x[w]/v)+","+Math.floor(p.y[w]/v)
;(m[g]||(m[g]=[])).push(w)}var y=new Int32Array(f.length);for(w=0;w<f.length;w++){
for(var x=Math.floor(d.x[w]/v),M=Math.floor(d.y[w]/v),b=-1,A=n,k=-1;k<=1;k++)for(var S=-1;S<=1;S++){var C=m[x+S+","+(M+k)];if(C)for(var B=0;B<C.length;B++){
var I=o(p.x[C[B]]-d.x[w],p.y[C[B]]-d.y[w]);I<A&&(A=I,b=C[B])}}y[w]=b}var z={},P=[],T=[];for(w=0;w<f.length;w++)y[w]<0||z[y[w]]||(z[y[w]]=1,P.push(f[w]),
T.push(u[y[w]]));if(P.length<5)return null;var W={ax:[],ay:[],bx:[],by:[],bright:[]};for(w=0;w<P.length;w++)W.ax.push(s.qx[P[w]]),W.ay.push(s.qy[P[w]]),
W.bx.push(h.qx[T[w]]),W.by.push(h.qy[T[w]]),W.bright.push(Math.min(F(s.sorted,s.flux[P[w]]),F(h.sorted,h.flux[T[w]])));return W}function C(t,r,e,a,n){
for(var i=r.length,h=[],l=0;l<i;l++)h.push(new M(t.maps[l].centre,Math.max(r[l].w,r[l].h)/2,n));var f=h[0].nb,u={},c=0;for(l=0;l<i;l++)l!==a&&(u[l]=c++*f)
;var d=c*f,p=[];for(var v in e)p.push(v);for(var m={},w=0;w<p.length;w++){for(var g=e[p[w]],y=new Uint8Array(g.ax.length),x=0;x<y.length;x++)y[x]=1;m[p[w]]=y}
for(var b=new Float64Array(d),A=new Float64Array(f),k=new Float64Array(f),F=0;F<6;F++){var S=new s(d,2),C=0;for(w=0;w<p.length;w++){g=e[p[w]]
;var B=+(q=p[w].split(","))[0],I=+q[1];for(y=m[p[w]],x=0;x<g.ax.length;x++)if(y[x]){for(var z=0;z<d;z++)b[z]=0;if(void 0!==u[B])for(h[B].phi(g.ax[x],g.ay[x],A),
z=0;z<f;z++)b[u[B]+z]+=A[z];if(void 0!==u[I])for(h[I].phi(g.bx[x],g.by[x],k),z=0;z<f;z++)b[u[I]+z]-=k[z];var P=.1+g.bright[x]*g.bright[x]
;S.add(b,[g.bx[x]-g.ax[x],g.by[x]-g.ay[x]],P),C++}}var T=S.solve(.001*C);for(l=0;l<i;l++)if(void 0!==u[l])for(z=0;z<f;z++)h[l].cx[z]=T[0][u[l]+z],
h[l].cy[z]=T[1][u[l]+z];var W={},R=0,G=0;for(w=0;w<p.length;w++){g=e[p[w]],B=+(q=p[w].split(","))[0],I=+q[1];var q,L=new Float64Array(g.ax.length)
;for(x=0;x<g.ax.length;x++){var j=h[B].apply(g.ax[x],g.ay[x]),D=h[I].apply(g.bx[x],g.by[x]);L[x]=o(D[0]-j[0],D[1]-j[1]),m[p[w]][x]&&(R+=L[x]*L[x],G++)}W[p[w]]=L
}var H=Math.max(3*Math.sqrt(R/Math.max(G,1)),.5);for(w=0;w<p.length;w++)for(L=W[p[w]],y=m[p[w]],x=0;x<L.length;x++)y[x]=L[x]<H?1:0}return h}function B(t,r,e){
for(var a=t.w,o=t.h,n=a*o,i=new Uint8Array(n),s=0;s<n;s++)i[s]=1;for(var h=0;h<t.chans.length;h++){var l=t.chans[h];for(s=0;s<n;s++)0===l[s]&&(i[s]=0)}
for(var f=0;f<o;f++)for(var u=0;u<a;u++)(f<r.top||f>=o-r.bottom||u<r.left||u>=a-r.right)&&(i[f*a+u]=0);var c=d(i,a,o);for(s=0;s<n;s++)i[s]=c[s]>e?1:0;return i}
function I(t,r,e,a,o){for(var n=t.maps[e],i=t.corrs?t.corrs[e]:null,s=t.W,h=t.H,l=y(r.w,r.h,64),f=1/0,u=1/0,c=-1/0,d=-1/0,p=0;p<l.length;p++){
var v=n.fwd(l[p][0],l[p][1]);i&&(v=i.apply(v[0],v[1])),v[0]<f&&(f=v[0]),v[0]>c&&(c=v[0]),v[1]<u&&(u=v[1]),v[1]>d&&(d=v[1])}
for(var m=Math.max(Math.floor(f)-1,0),w=Math.max(Math.floor(u)-1,0),g=Math.min(Math.ceil(c)+2,s),x=Math.min(Math.ceil(d)+2,h),M=g-m,b=x-w,A=16,k=Math.ceil((M-1)/A)+4,F=Math.ceil((b-1)/A)+4,S=new Float64Array(k*F),C=new Float64Array(k*F),B=null,I=0;I<F;I++)for(B=null,
p=0;p<k;p++){var z=m+(p-1)*A,P=w+(I-1)*A;i&&(z=(q=i.invert(z,P))[0],P=q[1]);var T=n.inv(z,P,B);S[I*k+p]=T[0],C[I*k+p]=T[1],B=T}
for(var W=r.chans.length,R=[],G=new Uint8Array(M*b),q=0;q<W;q++)R.push(new Float32Array(M*b));for(var L=function(t){var r=new Float32Array(6150);function e(t){
if(0===t)return 1;if(Math.abs(t)>=3)return 0;var r=Math.PI*t;return 3*Math.sin(r)*Math.sin(r/3)/(r*r)}for(var a=0;a<=t;a++){for(var o=a/t,n=0,i=0;i<6;i++){
var s=e(o-(i-2));r[6*a+i]=s,n+=s}for(i=0;i<6;i++)r[6*a+i]/=n}return r}(1024),j=r.w,D=r.h,H=0;H<b;H++){!o||255&H||o(H/b)
;for(var U=H/A+1,V=Math.floor(U),E=U-V,N=0;N<M;N++){
var O=N/A+1,X=Math.floor(O),K=O-X,_=V*k+X,Y=_+k,Z=S[_]+K*(S[_+1]-S[_]),J=S[Y]+K*(S[Y+1]-S[Y]),Q=C[_]+K*(C[_+1]-C[_]),$=Z+E*(J-Z),tt=Q+E*(C[Y]+K*(C[Y+1]-C[Y])-Q),rt=Math.floor($+.5),et=Math.floor(tt+.5)
;if(!(rt<0||et<0||rt>=j||et>=D)&&a[et*j+rt]){var at=Math.floor($),ot=Math.floor(tt);if(!(at<2||ot<2||at>j-4||ot>D-4)){
var nt=6*Math.round(1024*($-at)),it=6*Math.round(1024*(tt-ot)),st=H*M+N,ht=L[nt],lt=L[nt+1],ft=L[nt+2],ut=L[nt+3],ct=L[nt+4],dt=L[nt+5];for(G[st]=1,
q=0;q<W;q++){
for(var pt=r.chans[q],vt=(ot-2)*j+at-2,mt=0,wt=0;wt<6;wt++,vt+=j)mt+=L[it+wt]*(ht*pt[vt]+lt*pt[vt+1]+ft*pt[vt+2]+ut*pt[vt+3]+ct*pt[vt+4]+dt*pt[vt+5])
;var gt=ot*j+at,yt=pt[gt],xt=pt[gt+1],Mt=pt[gt+j],bt=pt[gt+j+1],At=yt<xt?yt:xt,kt=yt<xt?xt:yt;Mt<At?At=Mt:Mt>kt&&(kt=Mt),bt<At?At=bt:bt>kt&&(kt=bt),
mt=mt<At?At:mt>kt?kt:mt,R[q][st]=mt<0?0:mt>1?1:mt}}}}}return{box:[m,w,g,x],w:M,h:b,chans:R,mask:G}}function z(t,e){
for(var a=(e=e||{}).log||function(){},n=t.length,i=void 0===e.order?2:e.order,s=0,l=1;l<n;l++)t[l].noise<t[s].noise&&(s=l);var f=function(t,r,e){
for(var a=t.length,o=[],n=[0,0,0],i=0;i<a;i++){for(var s=t[i].grid,h=[],l=0;l<s.nx*s.ny;l++)h.push(p(s.ra[l],s.dec[l]));o.push(h)
;var f=h[Math.floor(s.ny/2)*s.nx+Math.floor(s.nx/2)];n[0]+=f[0],n[1]+=f[1],n[2]+=f[2]}
var u=Math.sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]),c=new v([n[0]/u,n[1]/u,n[2]/u]),d=[],m=[];for(i=0;i<a;i++){h=o[i]
;var w=new Float64Array(h.length),x=new Float64Array(h.length);for(l=0;l<h.length;l++){var M=c.project(h[l]);w[l]=M[0],x[l]=M[1]}d.push(w),m.push(x)}
var b=[],A=[];for(i=0;i<a;i++){var k=new g(t[i],d[i],m[i]),F=((M=t[i]).w-1)/2,S=(M.h-1)/2,C=k.fwd(F+16,S),B=k.fwd(F-16,S),I=(f=k.fwd(F,S+16),
k.fwd(F,S-16)),z=[(C[0]-B[0])/32,(f[0]-I[0])/32,(C[1]-B[1])/32,(f[1]-I[1])/32];b.push(z),A.push(Math.sqrt(Math.abs(z[0]*z[3]-z[1]*z[2])))}var P=A[0]
;for(i=1;i<a;i++)A[i]<P&&(P=A[i]);var T=b[r],W=A[r],R=(z=[T[0]/W*P,T[1]/W*P,T[2]/W*P,T[3]/W*P])[0]*z[3]-z[1]*z[2],G=[z[3]/R,-z[1]/R,-z[2]/R,z[0]/R],q=null
;if(e&&e.cropAngle){var L=[];for(i=0;i<a;i++){w=d[i],x=m[i];var j=new Float64Array(w.length),D=new Float64Array(w.length)
;for(l=0;l<w.length;l++)j[l]=G[0]*w[l]+G[1]*x[l],D[l]=G[2]*w[l]+G[3]*x[l];k=new g(t[i],j,D);var H=.015*(M=t[i]).w,U=.015*M.h
;L.push([k.fwd(H,U),k.fwd(M.w-1-H,U),k.fwd(M.w-1-H,M.h-1-U),k.fwd(H,M.h-1-U)])}q=function(t){function r(r){
for(var e=r*Math.PI/180,a=Math.cos(e),o=Math.sin(e),n=[],i=1/0,s=1/0,h=-1/0,l=-1/0,f=0;f<t.length;f++){for(var u=[],c=0;c<4;c++){
var d=a*t[f][c][0]-o*t[f][c][1],p=o*t[f][c][0]+a*t[f][c][1];u.push([d,p]),d<i&&(i=d),d>h&&(h=d),p<s&&(s=p),p>l&&(l=p)}
(u[1][0]-u[0][0])*(u[2][1]-u[0][1])-(u[1][1]-u[0][1])*(u[2][0]-u[0][0])<0&&u.reverse(),n.push(u)}
var v=300/Math.max(h-i,l-s),m=Math.ceil((h-i)*v)+1,w=Math.ceil((l-s)*v)+1,g=new Uint8Array(m*w);for(f=0;f<n.length;f++){u=n[f];var y=m,x=w,M=0,b=0
;for(c=0;c<4;c++)y=Math.min(y,Math.floor((u[c][0]-i)*v)),M=Math.max(M,Math.ceil((u[c][0]-i)*v)),x=Math.min(x,Math.floor((u[c][1]-s)*v)),
b=Math.max(b,Math.ceil((u[c][1]-s)*v));for(var A=Math.max(x,0);A<Math.min(b,w);A++)for(var k=Math.max(y,0);k<Math.min(M,m);k++){
var F=i+(k+.5)/v,S=s+(A+.5)/v,C=!0;for(c=0;c<4&&C;c++){var B=u[c],I=u[(c+1)%4];(I[0]-B[0])*(S-B[1])-(I[1]-B[1])*(F-B[0])<0&&(C=!1)}C&&(g[A*m+k]=1)}}var z=Wt({
W:m,H:w,union:g});return(z[2]-z[0])*(z[3]-z[1])/(v*v)}for(var e=r(0),a=0,o=e,n=1;n<90;n++)(i=r(n))>o&&(o=i,a=n);for(n=a-1;n<=a+1.001;n+=.1){var i
;(i=r(n))>o&&(o=i,a=n)}return o<1.01*e?{angle:0,gain:1}:{angle:(a=Math.round(10*a)/10)>45?a-90:a,gain:o/e}}(L);var V=q.angle*Math.PI/180,E=(f=Math.cos(V),
Math.sin(V));G=[f*G[0]-E*G[2],f*G[1]-E*G[3],E*G[0]+f*G[2],E*G[1]+f*G[3]],z=[z[0]*f-z[1]*E,z[0]*E+z[1]*f,z[2]*f-z[3]*E,z[2]*E+z[3]*f]}
var N=[],O=[],X=1/0,K=1/0,_=-1/0,Y=-1/0;for(i=0;i<a;i++){for(w=d[i],x=m[i],j=new Float64Array(w.length),D=new Float64Array(w.length),
l=0;l<w.length;l++)j[l]=G[0]*w[l]+G[1]*x[l],D[l]=G[2]*w[l]+G[3]*x[l];N.push(j),O.push(D),k=new g(t[i],j,D);var Z=y(t[i].w,t[i].h,64);for(l=0;l<Z.length;l++){
var J=k.fwd(Z[l][0],Z[l][1]);J[0]<X&&(X=J[0]),J[0]>_&&(_=J[0]),J[1]<K&&(K=J[1]),J[1]>Y&&(Y=J[1])}}
var Q=Math.floor(X)-2,$=Math.floor(K)-2,tt=Math.ceil(_-Q)+3,rt=Math.ceil(Y-$)+3,et=[];for(i=0;i<a;i++){for(j=N[i],D=O[i],l=0;l<j.length;l++)j[l]-=Q,D[l]-=$
;et.push(new g(t[i],j,D))}return{W:tt,H:rt,tangent:c,J:z,origin:[Q,$],maps:et,crop:q,scaleArcsec:180*P/Math.PI*3600,panelScales:A,panelJac:b}}(t,s,{
cropAngle:e.crop}),u={W:f.W,H:f.H,ref:s,canvas:f,maps:f.maps,corrs:null,stars:[],report:[]},c=u.report
;for(c.push("Panels: "+n+", reference (lowest noise): "+t[s].id),
c.push("Projection TAN at RA "+f.tangent.ra0.toFixed(4)+" Dec "+f.tangent.dec0.toFixed(4)+", scale "+f.scaleArcsec.toFixed(4)+'"/px, canvas '+f.W+" x "+f.H+" px"),
f.crop&&c.push(f.crop.angle?"Canvas rotated by "+f.crop.angle.toFixed(1)+" deg from the reference orientation for the largest crop (+"+(100*(f.crop.gain-1)).toFixed(0)+"% area vs no rotation)":"Crop: the reference orientation is already the best"),
a("canvas "+f.W+"x"+f.H+", reference "+t[s].id),
u.trims=[],c.push(""),c.push('panel        rot,deg   scale" parity      noise  edge trim px (top/bottom/left/right)  stars'),l=0;l<n;l++){
var d=t[l],m=h(d.chans,d.w,d.h),w=Date.now();u.trims.push(b(m,d.w,d.h));var M=A(m,d.w,d.h);m=null;for(var F=[],B=[],I=0;I<M.x.length;I++){
var R=f.maps[l].fwd(M.x[I],M.y[I]);F.push(R[0]),B.push(R[1])}var G=M.flux.slice(0).sort(function(t,r){return t-r});u.stars.push({qx:F,qy:B,px:M.x,py:M.y,
flux:M.flux,sorted:G});var q=x(f.panelJac[l]),L=u.trims[l]
;c.push(T(d.id,10)+" "+W(q.rot.toFixed(2),8)+" "+W((648e3*f.panelScales[l]/Math.PI).toFixed(4),8)+" "+W(String(q.parity),6)+" "+W(d.noise.toExponential(3),10)+"  "+T(L.top+"/"+L.bottom+"/"+L.left+"/"+L.right,36)+" "+M.x.length),
a("  "+d.id+": "+M.x.length+" stars ("+((Date.now()-w)/1e3).toFixed(1)+" s)")}function j(r,e){for(var a={},o=0;o<n;o++)for(var i=o+1;i<n;i++){
var s=S(u,t,o,i,r,e);s&&(a[o+","+i]=s)}return a}function D(t,r,e){for(var a=r.split(","),o=+a[0],n=+a[1],i=[],s=[],h=0;h<t.ax.length;h++){
var l=e?e[o].apply(t.ax[h],t.ay[h]):[t.ax[h],t.ay[h]],f=e?e[n].apply(t.bx[h],t.by[h]):[t.bx[h],t.by[h]];i.push(f[0]-l[0]),s.push(f[1]-l[1])}return{dx:i,dy:s}}
var H=j(3,null),U={},V=function(t,r){for(var e=[],a=0;a<t;a++)e.push(a);function o(t){for(;e[t]!==t;)t=e[t]=e[e[t]];return t}for(var n in r){var i=n.split(",")
;e[o(+i[0])]=o(+i[1])}var s={},h=[];for(a=0;a<t;a++){var l=o(a);(s[l]||(s[l]=h[h.push([])-1])).push(a)}return h}(n,H);if(V.length>1){V.sort(function(t,r){
return r.length-t.length||(t.indexOf(s)>=0?-1:r.indexOf(s)>=0?1:0)});var E=V[0],N=[];for(l=0;l<n;l++)if(!(E.length>1&&E.indexOf(l)>=0)){var O=[]
;for(I=0;I<n;I++)I!==l&&P(u,t,l,I)>.005&&O.push(t[I].id);N.push({id:t[l].id,
reason:O.length?"overlaps "+O.join(", ")+" but no common stars were found there (overlap too small, too few stars, or a wrong plate solution)":"does not overlap any other panel"
})}if(E.length<2)throw new Error("No two panels could be joined by common stars: "+N.map(function(t){return t.id+" "+t.reason}).join("; ")+".")
;for(I=0;I<N.length;I++)a("** "+N[I].id+" left out: "+N[I].reason);var X=z(E.map(function(r){return t[r]}),e);return X.used=X.used.map(function(t){return E[t]
}),X.excluded=N.concat(X.excluded),X.report.unshift("Left out (not linked to the mosaic): "+N.map(function(t){return t.id+" - "+t.reason}).join("; "),""),X}
for(u.used=[],l=0;l<n;l++)u.used.push(l);for(var K in u.excluded=[],H){var _=D(H[K],K,null);U[K]=k(_.dx,_.dy)}var Y=null;if(i>=0){Y=C(u,t,H,s,i)
;for(var Z=0;Z<2;Z++)H=j(1.5,Y),Y=C(u,t,H,s,i)}for(u.corrs=Y,l=0;l<n;l++){var J=u.stars[l];for(J.x=[],J.y=[],
I=0;I<J.qx.length;I++)R=Y?Y[l].apply(J.qx[I],J.qy[I]):[J.qx[I],J.qy[I]],J.x.push(R[0]),J.y.push(R[1])}var Q=[],$=[];for(var K in u.pairs=[],H){
var tt=H[K],rt=D(tt,K,Y),et=(M=k(rt.dx,rt.dy),[]),at=[];for(R=0;R<tt.ax.length;R++)Q.push(o(rt.dx[R],rt.dy[R])),$.push(tt.bright[R]),
tt.bright[R]>=.5&&(et.push(rt.dx[R]),at.push(rt.dy[R]));var ot=et.length>=3?k(et,at):null,nt=K.split(",");u.pairs.push({i:+nt[0],j:+nt[1],before:U[K]||null,
after:M,bright:ot,check:ot?ot.med:M.med})}c.push(""),c.push("Residual vs star brightness (all pairs"+(Y?", refined":"")+"):")
;for(var it=[[0,.5],[.5,.8],[.8,1.01]],st=0;st<3;st++){var ht=[];for(R=0;R<Q.length;R++)$[R]>=it[st][0]&&$[R]<it[st][1]&&ht.push(Q[R]);if(ht.length){var lt=0
;for(R=0;R<ht.length;R++)lt+=ht[R]*ht[R]
;c.push("  flux rank "+it[st][0].toFixed(1)+"-"+Math.min(it[st][1],1).toFixed(1)+": n="+W(String(ht.length),4)+"  median "+r(ht).toFixed(3)+" px  rms "+Math.sqrt(lt/ht.length).toFixed(3)+" px")
}}c.push(""),c.push("Star pairs (canvas px). before = plate solutions only, after = refined; check = median of the brighter half:"),
c.push(T("pair",22)+"    n  before |    n   after     rms |  nbr  check");var ft=null;for(I=0;I<u.pairs.length;I++){
var ut=(pt=u.pairs[I]).before,ct=pt.check>.3?"  <-- above 0.3 px":""
;c.push(T(t[pt.i].id+"-"+t[pt.j].id,22)+" "+W(ut?String(ut.n):"-",4)+" "+W(ut?ut.med.toFixed(3):"-",7)+" | "+W(String(pt.after.n),4)+" "+W(pt.after.med.toFixed(3),7)+" "+W(pt.after.rms.toFixed(3),7)+" | "+W(pt.bright?String(pt.bright.n):"-",4)+" "+W(pt.check.toFixed(3),6)+ct),
(!ft||pt.check>ft.check)&&(ft=pt)}
ft&&(u.worstCheck=ft.check,c.push("Worst pair: "+t[ft.i].id+"-"+t[ft.j].id+" (check "+ft.check.toFixed(3)+" px)"+(ft.check>.3?"  - ABOVE TARGET":""))),
c.push(""),c.push("Overlap of the joined pairs (share of the smaller panel area):");var dt=1;for(I=0;I<u.pairs.length;I++){var pt=u.pairs[I]
;O=Math.max(P(u,t,pt.i,pt.j),P(u,t,pt.j,pt.i)),pt.overlap=O,c.push("  "+T(t[pt.i].id+"-"+t[pt.j].id,22)+" "+W((100*O).toFixed(0),3)+"%"),
O>.03&&(dt=Math.min(dt,O))}
if(u.minOverlap=dt,dt<.15&&c.push("Advice: the smallest real overlap is "+(100*dt).toFixed(0)+"%. Plan "+15..toFixed(0)+"% or more next time (e.g. in MosaicPlanner): wider overlaps give the seams more room around objects and a better photometric match."),
Y)for(c.push(""),c.push("Star refinement: polynomial order "+i+" per panel, reference fixed. Correction at centre / max over the border (px):"),l=0;l<n;l++){
for(var vt=y(t[l].w,t[l].h,16),mt=0,wt=0;wt<vt.length;wt++){R=f.maps[l].fwd(vt[wt][0],vt[wt][1]);var gt=Y[l].apply(R[0],R[1])
;mt=Math.max(mt,o(gt[0]-R[0],gt[1]-R[1]))}c.push("  "+T(t[l].id,10)+" "+o(Y[l].cx[0],Y[l].cy[0]).toFixed(3)+" / "+mt.toFixed(3))}return u}function P(t,r,e,a){
for(var o=r[e],n=r[a],i=0,s=0;s<17;s++)for(var h=0;h<17;h++){var l=t.maps[e].fwd(s*(o.w-1)/16,h*(o.h-1)/16),f=t.maps[a].inv(l[0],l[1])
;f[0]>=0&&f[1]>=0&&f[0]<=n.w-1&&f[1]<=n.h-1&&i++}return i/289}function T(t,r){for(t=String(t);t.length<r;)t+=" ";return t}function W(t,r){
for(t=String(t);t.length<r;)t=" "+t;return t}function R(t){var r=t.canvas,e=r.J,a=180/Math.PI
;return[["CTYPE1","'RA---TAN'","Gnomonic projection"],["CTYPE2","'DEC--TAN'","Gnomonic projection"],["CRVAL1",r.tangent.ra0,"RA of the tangent point (deg)"],["CRVAL2",r.tangent.dec0,"Dec of the tangent point (deg)"],["CRPIX1",1-r.origin[0],"Tangent point, x (1-based)"],["CRPIX2",t.H+r.origin[1],"Tangent point, y (1-based, y up)"],["CD1_1",e[0]*a,""],["CD1_2",-e[1]*a,""],["CD2_1",e[2]*a,""],["CD2_2",-e[3]*a,""],["RADESYS","'ICRS'",""],["EQUINOX",2e3,""]]
}function G(t,r,e){var a=(e=e||{}).triStars||45,n=e.scoreStars||250,i=e.tol||3,s=e.scale||1,h=e.minMatch||10;function l(t,r){
for(var e=[],a=0;a<t.x.length;a++)e.push(a);e.sort(function(r,e){return t.flux[e]-t.flux[r]}),e.length>r&&(e.length=r);var o=[],n=[]
;for(a=0;a<e.length;a++)o.push(t.x[e[a]]),n.push(t.y[e[a]]);return{x:o,y:n}}var f=l(t,a),u=l(r,a),c=l(t,n),d=l(r,n);if(f.x.length<4||u.x.length<4)return null
;function p(t,r){for(var e=[],a=t.x.length,n=0;n<a;n++)for(var i=n+1;i<a;i++)for(var s=i+1;s<a;s++){
var h=[n,i,s],l=[o(t.x[i]-t.x[s],t.y[i]-t.y[s]),o(t.x[n]-t.x[s],t.y[n]-t.y[s]),o(t.x[n]-t.x[i],t.y[n]-t.y[i])],f=[0,1,2].sort(function(t,r){return l[t]-l[r]
}),u=l[f[0]]*r,c=l[f[1]]*r,d=l[f[2]]*r;u<40||u/d<.15||e.push({s0:u,s1:c,s2:d,v:[h[f[0]],h[f[1]],h[f[2]]]})}return e}
for(var v=p(f,1),m=p(u,s),w={},g=0;g<m.length;g++){var y=Math.round(m[g].s2/4)+","+Math.round(m[g].s1/4);(w[y]||(w[y]=[])).push(g)}
for(var x={},M=0;M<c.x.length;M++){var b=Math.floor(c.x[M]/8)+","+Math.floor(c.y[M]/8);(x[b]||(x[b]=[])).push(M)}function A(t,r){
for(var e=Math.floor(t/8),a=Math.floor(r/8),n=-1,s=i,h=-1;h<=1;h++)for(var l=-1;l<=1;l++){var f=x[e+l+","+(a+h)];if(f)for(var u=0;u<f.length;u++){
var d=o(c.x[f[u]]-t,c.y[f[u]]-r);d<s&&(s=d,n=f[u])}}return{i:n,d:s}}function k(t,r){for(var e=0,a=0,o={},n=0;n<d.x.length;n++){
var i=A(t.a*d.x[n]+t.b*d.y[n]+t.tx,t.c*d.x[n]+t.d*d.y[n]+t.ty);i.i>=0&&!o[i.i]&&(o[i.i]=1,e++,a+=i.d*i.d,r&&r.push([n,i.i]))}return{n:e,rms:e?Math.sqrt(a/e):0}}
function F(t,r,e,a,n){for(var i=t.length,s=0,h=0,l=0,f=0,u=n?-1:1,c=0;c<i;c++)s+=t[c],h+=u*r[c],l+=e[c],f+=a[c];s/=i,h/=i,l/=i,f/=i;var d=0,p=0,v=0
;for(c=0;c<i;c++){var m=t[c]-s,w=u*r[c]-h,g=e[c]-l,y=a[c]-f;d+=m*g+w*y,p+=m*y-w*g,v+=m*m+w*w}var x=d/v,M=p/v,b={a:x,b:-M*u,c:M,d:x*u};b.tx=l-(x*s-M*h),
b.ty=f-(M*s+x*h);var A=0;for(c=0;c<i;c++)A=Math.max(A,o(b.a*t[c]+b.b*r[c]+b.tx-e[c],b.c*t[c]+b.d*r[c]+b.ty-a[c]));return b.res=A,b.scale=Math.sqrt(x*x+M*M),b}
var S=null;for(g=0;g<v.length;g++){for(var C=v[g],B=Math.round(C.s2/4),I=Math.round(C.s1/4),z=i+.01*C.s2,P=-1;P<=1;P++)for(var T=-1;T<=1;T++){
var W=w[B+P+","+(I+T)];if(W)for(var R=0;R<W.length;R++){var G=m[W[R]];if(!(Math.abs(G.s0-C.s0)>z||Math.abs(G.s1-C.s1)>z||Math.abs(G.s2-C.s2)>z)){
for(var q=[],L=[],j=[],D=[],H=0;H<3;H++)q.push(u.x[G.v[H]]),L.push(u.y[G.v[H]]),j.push(f.x[C.v[H]]),D.push(f.y[C.v[H]]);for(var U=0;U<2;U++){
var V=F(q,L,j,D,1===U);if(!(V.res>2*i||Math.abs(V.scale/s-1)>.05)){var E=k(V);(!S||E.n>S.n||E.n===S.n&&E.rms<S.rms)&&((S=V).n=E.n,S.rms=E.rms,S.mirror=1===U)}}}
}}if(S&&S.n>=3*h)break}if(!S||S.n<h)return null;var N=[];for(k(S,N),q=[],L=[],j=[],D=[],M=0;M<N.length;M++)q.push(d.x[N[M][0]]),L.push(d.y[N[M][0]]),
j.push(c.x[N[M][1]]),D.push(c.y[N[M][1]]);var O=F(q,L,j,D,S.mirror);return E=k(O),O.n=E.n,O.rms=E.rms,O.mirrored=S.mirror,O.n>=h?O:null}
v.prototype.project=function(t){var r=t[0]*this.t[0]+t[1]*this.t[1]+t[2]*this.t[2]
;return[(t[0]*this.e[0]+t[1]*this.e[1]+t[2]*this.e[2])/r,(t[0]*this.n[0]+t[1]*this.n[1]+t[2]*this.n[2])/r]},g.prototype.fwd=function(t,r){
return w(this.cx,this.cy,this.nx,this.ny,t/this.step+1,r/this.step+1,[0,0],this.wx,this.wy)},g.prototype.inv=function(t,r,e){var a,o;if(e)a=e[0],o=e[1];else{
var n=t-this.centre[0],i=r-this.centre[1];a=this.xc+this.k11*n+this.k12*i,o=this.yc+this.k21*n+this.k22*i}for(var s=0;s<12;s++){
var h=w(this.cx,this.cy,this.nx,this.ny,a/this.step+1,o/this.step+1,this.tmp,this.wx,this.wy),l=t-h[0],f=r-h[1];if(a+=this.k11*l+this.k12*f,
o+=this.k21*l+this.k22*f,l*l+f*f<1e-12)break}return[a,o]},M.prototype.phi=function(t,r,e){e=e||this.phiBuf
;var a=(t-this.c0[0])/this.s,o=(r-this.c0[1])/this.s,n=0;return e[n++]=1,this.order>=1&&(e[n++]=a,e[n++]=o),this.order>=2&&(e[n++]=a*a,e[n++]=a*o,e[n++]=o*o),
this.order>=3&&(e[n++]=a*a*a,e[n++]=a*a*o,e[n++]=a*o*o,e[n++]=o*o*o),e},M.prototype.apply=function(t,r){
for(var e=this.phi(t,r),a=0,o=0,n=0;n<this.nb;n++)a+=e[n]*this.cx[n],o+=e[n]*this.cy[n];return[t+a,r+o]},M.prototype.invert=function(t,r){
for(var e=t,a=r,o=0;o<20;o++){for(var n=this.phi(e,a),i=0,s=0,h=0;h<this.nb;h++)i+=n[h]*this.cx[h],s+=n[h]*this.cy[h];e=t-i,a=r-s}return[e,a]};var q={bin:16,
minClean:.5,bgDeg:2,structWarn:.3,apR:9,anR0:14,anR1:20,vigMin:.01,knot:128,smooth:1};function L(t,r,e){
var a=1e20,o=new Float64Array(r*e),n=Math.max(r,e),i=new Float64Array(n),s=new Float64Array(n+1),h=new Int32Array(n),l=new Float64Array(n),f=new Float64Array(32*e)
;function u(t){var r=0;h[0]=0,s[0]=-a,s[1]=a;for(var e=1;e<t;e++){for(var o=(i[e]+e*e-(i[h[r]]+h[r]*h[r]))/(2*e-2*h[r]);o<=s[r];)r--,
o=(i[e]+e*e-(i[h[r]]+h[r]*h[r]))/(2*e-2*h[r]);r++,h[r]=e,s[r]=o,s[r+1]=a}for(r=0,e=0;e<t;e++){for(;s[r+1]<e;)r++;var n=e-h[r];l[e]=n*n+i[h[r]]}}
for(var c=0;c<r;c+=32){for(var d=Math.min(32,r-c),p=0;p<e;p++)for(var v=p*r+c,m=0;m<d;m++)f[m*e+p]=t[v+m]?0:a;for(m=0;m<d;m++){var w=m*e
;for(p=0;p<e;p++)i[p]=f[w+p];for(u(e),p=0;p<e;p++)f[w+p]=l[p]}for(p=0;p<e;p++)for(v=p*r+c,m=0;m<d;m++)o[v+m]=f[m*e+p]}for(p=0;p<e;p++){v=p*r
;for(var g=0;g<r;g++)i[g]=o[v+g];for(u(r),g=0;g<r;g++)o[v+g]=l[g]}return o}function j(t,r,e,a){
for(var o=L(t,r,e),n=new Uint8Array(r*e),i=a*a+.5,s=0;s<n.length;s++)n[s]=o[s]<=i?1:0;return n}function D(t,r,e){
for(var a=new Uint8Array(r*e),o=new Uint8Array(r*e),n=0;n+1<e;n++)for(var i=0;i+1<r;i++)a[s=n*r+i]=t[s]&t[s+1]&t[s+r]&t[s+r+1];for(n=0;n<e;n++)for(i=0;i<r;i++){
var s;o[s=n*r+i]=a[s]|(i>0?a[s-1]:0)|(n>0?a[s-r]:0)|(i>0&&n>0?a[s-r-1]:0)}return o}function H(t,a,o,n,i){
for(var s=i?Math.round(32/i):32,h=Math.floor(o/s),l=Math.floor(n/s),d=new Float32Array(h*l),p=[],v=0;v<o*n;v+=5)a[v]&&p.push(t[v])
;for(var m=r(p),w=0;w<l;w++)for(var g=0;g<h;g++){for(var y=0,x=!1,M=0;M<s&&!x;M++)for(var b=(w*s+M)*o+g*s,A=0;A<s;A++){if(!a[b+A]){x=!0;break}y+=t[b+A]}
d[w*h+g]=x?m:y/(s*s)}var k=f(u(d,h,l,5),h,l,o,n),F=new Float32Array(o*n);for(v=0;v<o*n;v++)F[v]=t[v]-k[v];k=null;var S=i?tt(F,o,n,1.5/i):c(F,o,n,1.5),C=[]
;for(v=0;v<o*n;v+=3)a[v]&&C.push(S[v]);y=e(C).sigma;var B=new Uint8Array(o*n);for(v=0;v<o*n;v++)B[v]=S[v]>2.5*y?1:0;S=null,B=j(i?B:D(B,o,n),o,n,i?6/i:6)
;var I=i?tt(F,o,n,8/i):c(F,o,n,8),z=new Uint8Array(o*n);for(v=0;v<o*n;v++)z[v]=I[v]>y?1:0;for(I=null,z=j(z,o,n,i?30/i:30),v=0;v<o*n;v++)B[v]|=z[v];return B}
function U(t,e,a,o){for(var n=q.bin,i=t.box[0],s=t.box[1],h=t.w,l=t.h,f=t.chans.length,u=[],c=0;c<f;c++){
for(var d=new Float32Array(a*o),p=0;p<d.length;p++)d[p]=NaN;u.push(d)}
for(var v=Math.floor(i/n),m=Math.floor(s/n),w=Math.ceil((i+h)/n),g=Math.ceil((s+l)/n),y=new Float64Array(n*n),x=new Int32Array(n*n),M=q.minClean*n*n,b=m;b<g;b++)for(var A=v;A<w;A++){
for(var k=0,F=b*n;F<(b+1)*n;F++){var S=F-s;if(!(S<0||S>=l))for(var C=A*n;C<(A+1)*n;C++){var B=C-i;B<0||B>=h||e[p=S*h+B]&&(x[k++]=p)}}if(!(k<M))for(c=0;c<f;c++){
d=t.chans[c];for(var I=0;I<k;I++)y[I]=d[x[I]];u[c][b*a+A]=r(y,k)}}return u}function V(t,r){for(var a=t.w,o=t.h,n=[],i=0;i<t.chans.length;i++){
for(var s=t.chans[i],h=[],l=0;l+1<o;l+=2)for(var f=0;f+1<a;f+=2){var u=l*a+f;r[u]&&r[u+1]&&r[u+a]&&r[u+a+1]&&h.push((s[u]-s[u+a]-s[u+1]+s[u+a+1])/2)}
n.push(e(h).sigma)}return n}function E(t,e){
for(var a=q,o=a.anR1,n=t.box[0],i=t.box[1],s=t.w,h=t.h,l=t.chans.length,f=[],u=[],c=-o;c<=o;c++)for(var d=-o;d<=o;d++){var p=Math.sqrt(d*d+c*c)
;p<=a.apR?f.push(c*s+d):p>=a.anR0&&p<=o&&u.push(c*s+d)}for(var v=[],m=[],w=new Float64Array(u.length),g=0;g<e.length;g++){
for(var y=Math.round(e[g][0]-n),x=Math.round(e[g][1]-i),M=[],b=NaN,A=0;A<l;A++)M.push(NaN);if(y>=o&&x>=o&&y<s-o&&x<h-o){var k=!0,F=x*s+y
;for(c=-o;c<=o&&k;c++)for(d=-o;d<=o;d++)if(!t.mask[F+c*s+d]){k=!1;break}if(k)for(b=-1/0,A=0;A<l;A++){for(var S=t.chans[A],C=0,B=0;B<f.length;B++){
var I=S[F+f[B]];C+=I,I>b&&(b=I)}for(B=0;B<u.length;B++)w[B]=S[F+u[B]];M[A]=C-r(w,u.length)*f.length}}v.push(M),m.push(b)}return{flux:v,peak:m}}
function N(t,r,a,o,n,i){i=i||6,o=o||3,n=n||3;for(var h=t.length,l=t[0].length,f=new Uint8Array(h),u=null,c=0;c<h;c++)f[c]=isFinite(r[c])?1:0
;for(var d=new Float64Array(l),p=0;p<i;p++){var v=new s(l,1);for(c=0;c<h;c++)if(f[c]){for(var m=0;m<l;m++)d[m]=t[c][m];v.add(d,[r[c]],a?a[c]:1)}u=v.solve(0)[0]
;var w=new Float64Array(h),g=[];for(c=0;c<h;c++){var y=0;for(m=0;m<l;m++)y+=t[c][m]*u[m];w[c]=r[c]-y,f[c]&&g.push(w[c])}var x=e(g);if(0===x.sigma)break;var M=!1
;for(c=0;c<h;c++){var b=isFinite(r[c])&&w[c]<n*x.sigma&&w[c]>-o*x.sigma?1:0;b!==f[c]&&(M=!0,f[c]=b)}if(!M)break}return{coef:u,keep:f}}function O(t,r){
for(var e=[],a=0;a<r;a++){var o=new Float64Array(r);o[a]=1,e.push(o)}return i(new Float64Array(t),r,e),e}function X(t,r){this.ox=t[0],this.oy=t[1],this.k=r,
this.nx=Math.ceil((t[2]-t[0])/r)+3,this.ny=Math.ceil((t[3]-t[1])/r)+3,this.n=this.nx*this.ny,this.wx=new Float64Array(4),this.wy=new Float64Array(4)}
function K(t,r,e,a,o,n,i,s,h,l,f,u,c){
for(var d=r.length-1,p=f?new Float64Array(f):new Float64Array(t),v=new Float64Array(t),m=new Float64Array(t),w=new Float64Array(d),g=0;g<d;g++)for(var y=r[g];y<r[g+1];y++)v[e[y]]+=o[g]*a[y]*n[g],
m[e[y]]+=o[g]*a[y]*a[y];for(var x=0;x<i.length;x++)m[i[x]]+=h,m[s[x]]+=h;for(var M=0;M<t;M++)m[M]+=l;function b(n,f){for(var u=0;u<d;u++){
for(var c=0,p=r[u];p<r[u+1];p++)c+=a[p]*n[e[p]];w[u]=o[u]*c}for(var v=0;v<t;v++)f[v]=l*n[v]
;for(u=0;u<d;u++)if(0!==(c=w[u]))for(p=r[u];p<r[u+1];p++)f[e[p]]+=a[p]*c;for(var m=0;m<i.length;m++){var g=h*(n[i[m]]-n[s[m]]);f[i[m]]+=g,f[s[m]]-=g}}
g=new Float64Array(t);var A=new Float64Array(t),k=new Float64Array(t),F=new Float64Array(t);b(p,F);var S=0;for(M=0;M<t;M++)g[M]=v[M]-F[M],A[M]=g[M]/m[M],
k[M]=A[M],S+=v[M]*v[M];S=Math.sqrt(S)||1;var C=0;for(M=0;M<t;M++)C+=g[M]*A[M];for(var B=0;B<c;B++){b(k,F);var I=0;for(M=0;M<t;M++)I+=k[M]*F[M];var z=C/I,P=0
;for(M=0;M<t;M++)p[M]+=z*k[M],g[M]-=z*F[M],P+=g[M]*g[M];if(Math.sqrt(P)/S<u)break;var T=0;for(M=0;M<t;M++)A[M]=g[M]/m[M],T+=g[M]*A[M];var W=T/C;for(C=T,
M=0;M<t;M++)k[M]=A[M]+W*k[M]}return p.iterations=B,p}function _(t,r,e){for(var a=[1],o=1;o<=e;o++)for(var n=0;n<=o;n++)a.push(Math.pow(t,o-n)*Math.pow(r,n))
;return a}function Y(t,r,e,a){for(var o=[],n=0;n<e;n+=a)for(var i=0;i<r;i+=a){for(var s=0,h=0,l=n;l<n+a;l++)for(var f=i;f<i+a;f++)if(!(l>=e||f>=r)){
var u=t[l*r+f];u==u&&(s+=u,h++)}h>=a*a/2&&o.push(s/h)}return o}function Z(t,r){for(var e=new Float64Array(t.length),a=0;a<t.length;a++)e[a]=t[a];e.sort()
;var o=(e.length-1)*r/100,n=Math.floor(o),i=Math.min(n+1,e.length-1);return e[n]+(o-n)*(e[i]-e[n])}X.w=function(t,r){var e=t*t,a=e*t;r[0]=(1-t)*(1-t)*(1-t)/6,
r[1]=(3*a-6*e+4)/6,r[2]=(-3*a+3*e+3*t+1)/6,r[3]=a/6},X.prototype.basis=function(t,r,e,a){
var o=(t-this.ox)/this.k,n=(r-this.oy)/this.k,i=Math.floor(o),s=Math.floor(n);i<0?i=0:i>this.nx-4&&(i=this.nx-4),s<0?s=0:s>this.ny-4&&(s=this.ny-4),
X.w(o-i,this.wx),X.w(n-s,this.wy);for(var h=0,l=0;l<4;l++)for(var f=0;f<4;f++)e[h]=(s+l)*this.nx+i+f,a[h++]=this.wy[l]*this.wx[f]},
X.prototype.eval=function(t,r,e){var a=(t-this.ox)/this.k,o=(r-this.oy)/this.k,n=Math.floor(a),i=Math.floor(o);n<0?n=0:n>this.nx-4&&(n=this.nx-4),
i<0?i=0:i>this.ny-4&&(i=this.ny-4),X.w(a-n,this.wx),X.w(o-i,this.wy);for(var s=0,h=0;h<4;h++){for(var l=(i+h)*this.nx+n,f=0,u=0;u<4;u++)f+=this.wx[u]*e[l+u]
;s+=this.wy[h]*f}return s};var J={G:8,levels:7,noiseW:4,edgeW:2,edgeR:400,edgeMin:48,seamW:1,objW:30,sweeps:2,blendPad:512,blendK:1800,blendMin:300,visEps:.1,
psdT:128,kernR:16,small:8};function Q(t,r,e,a,o,n){
for(var i=-1,s=-3,h=1<<30,l=2*n,f=new Int32Array(l),u=new Float64Array(l),c=new Int32Array(t+1),d=new Int32Array(l),p=0;p<n;p++)f[2*p]=a[p],f[2*p+1]=e[p],
u[2*p]=o[p],c[e[p]+1]++,c[a[p]+1]++;for(var v=0;v<t;v++)c[v+1]+=c[v];var m=new Int32Array(t);for(p=0;p<n;p++){var w=e[p],g=a[p];d[c[w]+m[w]++]=2*p,
d[c[g]+m[g]++]=2*p+1}m=null
;var y=new Int32Array(t),x=new Uint8Array(t),M=new Int32Array(t),b=new Int32Array(t),A=new Int32Array(t+1),k=new Uint8Array(t),F=0,S=0,C=0,B=t+1;function I(t){
k[t]||(k[t]=1,A[S]=t,S=S+1===B?0:S+1,C++)}function z(){for(;C>0;){var t=A[F];if(F=F+1===B?0:F+1,C--,k[t]=0,y[t]!==s)return t}return-1}
for(v=0;v<t;v++)r[v]>0?(y[v]=i,x[v]=0,b[v]=1,I(v)):r[v]<0?(y[v]=i,x[v]=1,b[v]=1,I(v)):y[v]=s;var P=[],T=0,W=0;function R(t){y[t]=-2,P.push(t)}function G(t){
var e,a,o=u[t];for(a=f[1^t];(e=y[a])!==i;a=f[e])u[1^e]<o&&(o=u[1^e]);for(r[a]<o&&(o=r[a]),a=f[t];(e=y[a])!==i;a=f[e])u[e]<o&&(o=u[e]);for(-r[a]<o&&(o=-r[a]),
u[1^t]+=o,u[t]-=o,a=f[1^t];(e=y[a])!==i;a=f[e])u[e]+=o,u[1^e]-=o,0===u[1^e]&&R(a);for(r[a]-=o,0===r[a]&&R(a),a=f[t];(e=y[a])!==i;a=f[e])u[1^e]+=o,u[e]-=o,
0===u[e]&&R(a);r[a]+=o,0===r[a]&&R(a)}function q(t){for(var r=x[t],e=h,a=-1,o=c[t];o<c[t+1];o++){var n=d[o];if(r?u[n]>0:u[1^n]>0){var l=f[n]
;if(x[l]===r&&y[l]!==s){for(var p=0;;){if(M[l]===W){p+=b[l];break}if(p++,(v=y[l])===i){M[l]=W,b[l]=1;break}if(-2===v){p=h;break}l=f[v]}if(p<h)for(p<e&&(a=n,
e=p),l=f[n];M[l]!==W;l=f[y[l]])M[l]=W,b[l]=p--}}}if(a>=0)return y[t]=a,M[t]=W,void(b[t]=e+1);for(y[t]=s,o=c[t];o<c[t+1];o++){n=d[o],l=f[n];var v=y[l]
;x[l]===r&&v!==s&&((r?u[n]>0:u[1^n]>0)&&I(l),v!==i&&-2!==v&&f[v]===t&&R(l))}}for(var L=-1;!((L<0||y[L]===s)&&(L=z())<0);){var j=-1;if(x[v=L]){
for(D=c[v];D<c[v+1];D++)if(H=d[D],!(u[1^H]<=0))if(U=f[H],y[U]===s)x[U]=1,y[U]=1^H,M[U]=M[v],b[U]=b[v]+1,I(U);else{if(!x[U]){j=1^H;break}
M[U]<=M[v]&&b[U]>b[v]&&(y[U]=1^H,M[U]=M[v],b[U]=b[v]+1)}}else for(var D=c[v];D<c[v+1];D++){var H=d[D];if(!(u[H]<=0)){var U=f[H];if(y[U]===s)x[U]=0,y[U]=1^H,
M[U]=M[v],b[U]=b[v]+1,I(U);else{if(x[U]){j=H;break}M[U]<=M[v]&&b[U]>b[v]&&(y[U]=1^H,M[U]=M[v],b[U]=b[v]+1)}}}if(W++,j<0)L=-1;else{for(G(j);T<P.length;){
var V=P[T++];T>65536&&(P=P.slice(T),T=0),q(V)}P.length=0,T=0}}var E=new Uint8Array(t);for(v=0;v<t;v++)E[v]=y[v]===s||x[v]?0:1;return E}
function $(t,r,e,a,o,n,i,s){var h=t.length,l=o*n;function f(a){for(var i=0,s=0;s<l;s++)a[s]>=0&&(i+=t[a[s]][s]);for(var h=0;h<n;h++)for(var f=0;f+1<o;f++){
var u=a[h*o+f],c=a[h*o+f+1];u>=0&&c>=0&&u!==c&&(i+=r[h*(o-1)+f])}for(h=0;h+1<n;h++)for(f=0;f<o;f++)u=a[h*o+f],c=a[(h+1)*o+f],u>=0&&c>=0&&u!==c&&(i+=e[h*o+f])
;return i}for(var u=[f(a)],c=new Int32Array(l),d=0;d<i;d++){for(var p=0,v=0;v<h;v++){for(var m=t[v],w=0,g=0;g<l;g++)c[g]=isFinite(m[g])?w++:-1;if(0!==w){
var y=new Float64Array(w);for(g=0;g<l;g++)c[g]>=0&&(y[c[g]]=(a[g]>=0?t[a[g]][g]:0)-m[g])
;for(var x=new Int32Array(2*w),M=new Int32Array(2*w),b=new Float64Array(2*w),A=0,k=function(t,r,e){var o=a[t],n=a[r],i=c[t],s=c[r];if(i>=0&&s>=0){
var h=n!==v?e:0,l=o!==v?e:0,f=o!==n?e:0;y[i]+=l,y[s]+=f-l;var u=h+l-f;u>0&&(x[A]=i,M[A]=s,b[A]=Math.round(1e3*u),A++)
}else i>=0&&n>=0?y[i]+=(o!==n?e:0)-(n!==v?e:0):s>=0&&o>=0&&(y[s]+=(n!==o?e:0)-(o!==v?e:0))},F=0;F<n;F++)for(var S=0;S+1<o;S++)k(F*o+S,F*o+S+1,r[F*(o-1)+S])
;for(F=0;F+1<n;F++)for(S=0;S<o;S++)k(F*o+S,(F+1)*o+S,e[F*o+S]);for(var C=new Float64Array(w),B=0;B<w;B++)C[B]=Math.round(1e3*y[B])
;var I=Q(w,C,x,M,b,A),z=new Int32Array(a),P=0;for(g=0;g<l;g++)c[g]>=0&&I[c[g]]&&z[g]!==v&&(z[g]=v,P++);var T=f(z);T<u[u.length-1]-1e-9&&(p+=P,a=z,u.push(T))}}
if(s&&s("  graph cut sweep "+(d+1)+": energy "+u[u.length-1].toFixed(1)+", "+p+" cells changed"),0===p)break}return{label:a,hist:u}}function tt(t,r,e,a){
if(a<=.25)return new Float32Array(t);if(a<=2)return c(t,r,e,a);var o=Math.sqrt(12*a*a/3+1),n=Math.floor(o);n%2==0&&n--
;for(var i=n+2,s=Math.round((12*a*a-3*n*n-12*n-9)/(-4*n-4)),h=t,l=0;l<3;l++)h=rt(h,r,e,(l<s?n:i)-1>>1);return h}function rt(t,r,e,a){
var o=new Float32Array(r*e),n=new Float32Array(r*e),i=1/(2*a+1),s=new Float64Array(r+2*a+1),h=new Float64Array(r);function l(t,r){if(1===r)return 0
;for(;t<0||t>=r;)t=t<0?-t:2*r-2-t;return t}for(var f=0;f<e;f++){for(var u=f*r,c=-a;c<r+a;c++)s[c+a]=t[u+l(c,r)];s[r+2*a]=0;for(var d=0,p=0;p<2*a+1;p++)d+=s[p]
;for(var v=0;v<r;v++)o[u+v]=d*i,d+=s[v+2*a+1]-s[v]}for(v=0;v<r;v++)h[v]=0;for(p=-a;p<=a;p++){var m=l(p,e)*r;for(v=0;v<r;v++)h[v]+=o[m+v]}for(f=0;f<e;f++){
for(u=f*r,v=0;v<r;v++)n[u+v]=h[v]*i;if(f+1===e)break;var w=l(f+a+1,e)*r,g=l(f-a,e)*r;for(v=0;v<r;v++)h[v]+=o[w+v]-o[g+v]}return n}function et(t,r,e,a){
var o=r*e,n=new Uint8Array(o);if(!(a>0)){for(var i=0;i<o;i++)n[i]=t[i]?1:0;return n}if(a>8){
for(var s=Math.max(2,Math.floor(a/6)),h=Math.ceil(r/s),l=Math.ceil(e/s),f=new Uint8Array(h*l),u=0;u<e;u++)for(var c=u*r,d=Math.floor(u/s)*h,p=0;p<r;p++)t[c+p]&&(f[d+Math.floor(p/s)]=1)
;var v=j(f,h,l,a/s+.5);for(u=0;u<e;u++)for(c=u*r,d=Math.floor(u/s)*h,p=0;p<r;p++)n[c+p]=v[d+Math.floor(p/s)];return n}
var m=a*a+.5,w=Math.floor(Math.sqrt(m)),g=w+1,y=new Uint8Array(o);for(u=0;u<e;u++){c=u*r;var x=g;for(p=0;p<r;p++)x=t[c+p]?0:Math.min(x+1,g),y[c+p]=x;for(x=g,
p=r-1;p>=0;p--)(x=t[c+p]?0:Math.min(x+1,g))<y[c+p]&&(y[c+p]=x)}for(var M=-w;M<=w;M++){var b=m-M*M;if(!(b<0)){var A=Math.floor(Math.sqrt(b))
;for(u=Math.max(0,-M);u<Math.min(e,e-M);u++){c=u*r;var k=(u+M)*r;for(p=0;p<r;p++)y[k+p]<=A&&(n[c+p]=1)}}}return n}function at(t,r,e,a){
for(var o=r*e,n=new Uint8Array(o),i=0;i<o;i++)n[i]=t[i]?0:1;var s=et(n,r,e,a);for(i=0;i<o;i++)s[i]=s[i]?0:1;return s}function ot(t,r,e,a){
return a>0?et(at(t,r,e,a),r,e,a):t}function nt(t,r,e,a){return a>0?at(et(t,r,e,a),r,e,a):t}function it(t,r,e,a){
for(var o=r*e,n=new Int32Array(o),i=new Int32Array(o),s=new Uint8Array(o),h=0,l=0;l<o;l++)if(t[l]&&!n[l]){h++;var f=0,u=0;i[f++]=l,n[l]=h;for(var c=[];f>0;){
var d=i[--f],p=d%r,v=(d-p)/r;c.push(d),u++;for(var m=-1;m<=1;m++){var w=v+m;if(!(w<0||w>=e))for(var g=-1;g<=1;g++){var y=p+g;if(!(y<0||y>=r)){var x=w*r+y
;t[x]&&!n[x]&&(n[x]=h,i[f++]=x)}}}}if(u>a)for(var M=0;M<c.length;M++)s[c[M]]=1}return s}function st(t,r,e){
for(var a=r*e,o=new Uint8Array(a),n=new Int32Array(a),i=0,s=0;s<a;s++)o[s]=1;function h(r){!t[r]&&o[r]&&(o[r]=0,n[i++]=r)}for(var l=0;l<r;l++)h(l),h((e-1)*r+l)
;for(var f=0;f<e;f++)h(f*r),h(f*r+r-1);for(;i>0;)(l=(s=n[--i])%r)>0&&h(s-1),l<r-1&&h(s+1),s>=r&&h(s-r),s<a-r&&h(s+r);return o}function ht(t,r,e){
for(var a=L(t,r,e),o=new Float32Array(r*e),n=0;n<o.length;n++)o[n]=Math.sqrt(a[n]);return o}function lt(t,r,e){
var a=r+1>>1,o=e+1>>1,n=new Float32Array(a*e),i=new Float32Array(a*o);function s(t,r){return 1===r?0:t<0?-t:t>=r?2*r-2-t:t}
for(var h=0;h<e;h++)for(var l=h*r,f=h*a,u=0;u<a;u++){var c=2*u
;n[f+u]=c>=2&&c+2<r?.0625*(t[l+c-2]+t[l+c+2]+4*(t[l+c-1]+t[l+c+1])+6*t[l+c]):.0625*(t[l+s(c-2,r)]+t[l+s(c+2,r)]+4*(t[l+s(c-1,r)]+t[l+s(c+1,r)])+6*t[l+c])}
for(h=0;h<o;h++){l=h*a;var d=s((c=2*h)-2,e)*a,p=s(c-1,e)*a,v=c*a,m=s(c+1,e)*a,w=s(c+2,e)*a
;for(u=0;u<a;u++)i[l+u]=.0625*(n[d+u]+n[w+u]+4*(n[p+u]+n[m+u])+6*n[v+u])}return i}function ft(t,r,e,a,o){
for(var n=new Float32Array(a*e),i=new Float32Array(a*o),s=0;s<e;s++){for(var h=s*r,l=s*a,f=2;f<a-2;f++){var u=f>>1
;n[l+f]=1&f?.5*(t[h+u]+t[h+u+1]):.125*(t[h+u-1]+6*t[h+u]+t[h+u+1])}for(f=0;f<a;f++)if(!(f>=2&&f<a-2)){
for(var c=0,d=-2;d<=2;d++)(w=f+d)<0?w=-w:w>=a&&(w=2*a-2-w),1&w||(c+=(0===d?6:1===d||-1===d?4:1)*t[h+Math.min(w>>1,r-1)]);n[l+f]=.125*c}}
for(s=0;s<o;s++)if(h=s*a,s>=2&&s<o-2){var p=(u=s>>1)*a,v=(u+1)*a,m=(u-1)*a
;if(1&s)for(f=0;f<a;f++)i[h+f]=.5*(n[p+f]+n[v+f]);else for(f=0;f<a;f++)i[h+f]=.125*(n[m+f]+6*n[p+f]+n[v+f])}else{for(f=0;f<a;f++)i[h+f]=0;for(d=-2;d<=2;d++){
var w;if((w=s+d)<0?w=-w:w>=o&&(w=2*o-2-w),!(1&w)){var g=.125*(0===d?6:1===d||-1===d?4:1),y=Math.min(w>>1,e-1)*a;for(f=0;f<a;f++)i[h+f]+=g*n[y+f]}}}return i}
function ut(t,r,e,a){for(var o=e*a,n=new Float32Array(o),i=0;i<o;i++)n[i]=t[i]*r[i];for(var s=[n],h=[r],l=[e],f=[a];Math.min(l[l.length-1],f[f.length-1])>8;){
var u=s.length-1;s.push(lt(s[u],l[u],f[u])),h.push(lt(h[u],l[u],f[u])),l.push(l[u]+1>>1),f.push(f[u]+1>>1)}var c=s.length-1,d=s[c]
;for(i=0;i<d.length;i++)d[i]=d[i]/Math.max(h[c][i],1e-6);for(u=c-1;u>=0;u--){var p=ft(d,l[u+1],f[u+1],l[u],f[u]),v=s[u],m=h[u],w=l[u]*f[u]
;for(d=new Float32Array(w),i=0;i<w;i++){var g=m[i],y=u?Math.min(Math.max(2*g,0),1):r[i];d[i]=y>0?y*(v[i]/Math.max(g,1e-6))+(1-y)*p[i]:p[i]}s[u+1]=null,
h[u+1]=null}return d}function ct(t,r,e){if(!e)return-1;if(r>=0&&e>>>r&1)return r;for(var a=0;a<t.order.length;a++)if(e>>>t.order[a]&1)return t.order[a];return-1
}function dt(t,r,e){for(var a=J.G,o=t.cells.Wc,n=t.W,i=e[1];i<e[3];i++)for(var s=(i/a|0)*o,h=e[0];h<e[2];h++){var l=i*n+h;t.labf[l]=ct(t,r[s+(h/a|0)],t.cov[l])}
}function pt(t,r,e){for(var a=J.levels,o=t.fill.length,n=t.nc,i=t.W,s=t.H,h=t.labf,l=[[r[2]-r[0],r[3]-r[1]]],f=0;f<a;f++)l.push([l[f][0]+1>>1,l[f][1]+1>>1])
;for(var u=null,c=[],d=0;d<n;d++){var p=l.map(function(t){return new Float32Array(t[0]*t[1])}),v=null===u;v&&(u=l.map(function(t){
return new Float32Array(t[0]*t[1])}));for(var m=0;m<o;m++){
var w=t.fbox[m],g=w[2]-w[0],y=[Math.max(w[0],r[0]),Math.max(w[1],r[1]),Math.min(w[2],r[2]),Math.min(w[3],r[3])];if(!(y[2]<=y[0]||y[3]<=y[1])){
e&&e("  blend "+t.names[m]+(n>1?", channel "+d:""))
;for(var x=y[2]-y[0],M=y[3]-y[1],b=new Float32Array(x*M),A=new Float32Array(x*M),k=t.fill[m][d],F=!1,S=0;S<M;S++){
for(var C=y[1]+S,B=(C-w[1])*g+y[0]-w[0],I=0;I<x;I++)b[S*x+I]=k[B+I];if(!(C>=s))for(I=0;I<x;I++){var z=y[0]+I;z<i&&h[C*i+z]===m&&(A[S*x+I]=1,F=!0)}}if(F){
var P=A,T=b,W=x,R=M;for(f=0;f<=a;f++){var G,q=1<<f,L=(y[0]-r[0])/q,j=(y[1]-r[1])/q,D=l[f][0],H=null,U=W+1>>1,V=R+1>>1;if(f<a){var E=ft(H=lt(T,W,R),U,V,W,R);G=T
;for(var N=0;N<G.length;N++)G[N]-=E[N];E=null}else G=T;var O=p[f],X=u[f];for(S=0;S<R;S++){var K=(j+S)*D+L,_=S*W;if(j+S>=l[f][1])break;for(I=0;I<W;I++){
var Y=P[_+I];0===Y||L+I>=D||(O[K+I]+=G[_+I]*Y,v&&(X[K+I]+=Y))}}f<a&&(P=lt(P,W,R),T=H,W=U,R=V)}b=A=P=T=null}}}var Z=null;for(f=a;f>=0;f--){O=p[f],X=u[f]
;var Q=O.length;for(N=0;N<Q;N++)O[N]=X[N]>1e-6?O[N]/X[N]:0;if(null===Z)Z=O;else{for(E=ft(Z,l[f+1][0],l[f+1][1],l[f][0],l[f][1]),N=0;N<Q;N++)E[N]+=O[N];Z=E}
p[f]=null}c.push(Z)}return c}var vt={};function mt(t,r,e,a,o,n){o=o||0,n=n||1;for(var i=function(t){if(vt[t])return vt[t]
;for(var r=Math.round(Math.log(t)/Math.LN2),e=new Int32Array(t),a=new Float64Array(t/2),o=new Float64Array(t/2),n=0;n<t;n++){
for(var i=0,s=0;s<r;s++)i|=(n>>s&1)<<r-1-s;e[n]=i}for(n=0;n<t/2;n++)a[n]=Math.cos(2*Math.PI*n/t),o[n]=Math.sin(2*Math.PI*n/t);return vt[t]={rev:e,cs:a,sn:o}
}(e),s=i.rev,h=a?1:-1,l=0;l<e;l++)if((v=s[l])>l){var f=o+v*n,u=t[m=o+l*n];t[m]=t[f],t[f]=u,u=r[m],r[m]=r[f],r[f]=u}for(var c=2;c<=e;c<<=1){var d=c>>1,p=e/c
;for(l=0;l<e;l+=c)for(var v=0;v<d;v++){var m,w=i.cs[v*p],g=h*i.sn[v*p],y=t[f=(m=o+(l+v)*n)+d*n]*w-r[f]*g,x=t[f]*g+r[f]*w;t[f]=t[m]-y,r[f]=r[m]-x,t[m]+=y,r[m]+=x
}}}function wt(t,r,e,a){for(var o=0;o<e;o++)mt(t,r,e,a,o*e,1);for(var n=0;n<e;n++)mt(t,r,e,a,n,e);if(a)for(var i=1/(e*e),s=0;s<e*e;s++)t[s]*=i,r[s]*=i}
function gt(t,r){for(var e=new Float64Array(r*r),a=0;a<r;a++)e[a*r+a]=1;for(var o=0;o<30;o++){for(var n=0,i=0,s=0;s<r;s++){i+=t[s*r+s]*t[s*r+s]
;for(var h=s+1;h<r;h++)n+=t[s*r+h]*t[s*r+h]}if(n<=1e-24*i||0===n)break;for(s=0;s<r;s++)for(h=s+1;h<r;h++){var l=t[s*r+h];if(0!==l){
for(var f=(t[h*r+h]-t[s*r+s])/(2*l),u=(f>=0?1:-1)/(Math.abs(f)+Math.sqrt(f*f+1)),c=1/Math.sqrt(u*u+1),d=u*c,p=0;p<r;p++){var v=t[p*r+s],m=t[p*r+h]
;t[p*r+s]=c*v-d*m,t[p*r+h]=d*v+c*m}for(p=0;p<r;p++){var w=t[s*r+p],g=t[h*r+p];t[s*r+p]=c*w-d*g,t[h*r+p]=d*w+c*g}for(p=0;p<r;p++){var y=e[p*r+s],x=e[p*r+h]
;e[p*r+s]=c*y-d*x,e[p*r+h]=d*y+c*x}}}}var M=new Float64Array(r);for(a=0;a<r;a++)M[a]=t[a*r+a];return{ev:M,V:e}}function yt(t,e,a){a=a||{}
;for(var o=J,n=o.small,i=t.W,s=t.H,h=Math.floor(i/n),l=Math.floor(s/n),f=h*l,u=e.length,c=new Int32Array(f),d=new Uint8Array(f),p=new Float32Array(f),v=0;v<l;v++)for(var m=0;m<h;m++){
var w=t.labf[Math.floor(v*s/l)*i+Math.floor(m*i/h)];c[C=v*h+m]=w,d[C]=w>=0?1:0,p[C]=w>=0?e[w]:0}for(var g=r(e),y=[],x=void 0===a.blend?1:a.blend,M=0;M<u;M++){
var b=a.zoneWidth>0?a.zoneWidth:Math.min(Math.max(o.blendK*Math.log(Math.max(e[M]/g,1)),o.blendMin),.35*Math.min(i,s));y.push(b*x)}
var A=new Float32Array(p),k=new Int32Array(c);for(M=0;M<u;M++){for(var F=new Uint8Array(f),S=!1,C=0;C<f;C++)c[C]===M&&(F[C]=1,S=!0);if(S){var B=ht(F,h,l)
;for(C=0;C<f;C++)if(d[C]&&e[M]>p[C]){var I=1-(m=Math.min(B[C]*n/y[M],1))*m*(3-2*m),z=p[C]*Math.pow(e[M]/Math.max(p[C],1e-30),I);z>A[C]&&(A[C]=z,k[C]=M)}}}
var P=function(t,r,e,a){for(var o=e*a,n=new Float32Array(o),i=new Float32Array(o),s=0;s<o;s++)i[s]=r[s]?1:0,n[s]=r[s]?t[s]:0;var h=tt(n,e,a,3),l=tt(i,e,a,3)
;for(s=0;s<o;s++)h[s]=h[s]/Math.max(l[s],1e-6);return h}(A,d,h,l);for(C=0;C<f;C++)d[C]||(A[C]=P[C]);return{f:n,ws:h,hs:l,tg:A,src:k,sc:p,widths:y}}
function xt(t,r,e,a,o){a=a||1
;for(var n=(o=o||[0,0,Math.floor(t.W/a),Math.floor(t.H/a)])[2]-o[0],i=o[3]-o[1],s=n*i,h=new Float32Array(s),l=new Float32Array(s),f=new Int8Array(s),u=new Int8Array(s),c=r.ws/t.W,d=r.hs/t.H,p=new Float64Array(n),v=new Int32Array(n),m=new Float64Array(n),w=new Int32Array(n),g=0;g<n;g++){
var y=(o[0]+g)*a+(a-1)/2,x=Math.min(Math.max((y+.5)*c-.5,0),r.ws-1);v[g]=Math.min(Math.floor(x),r.ws-2),m[g]=x-v[g],
w[g]=Math.min(Math.floor((o[0]+g)*a+a/2),t.W-1),p[g]=Math.min(Math.floor(w[g]/r.f),r.ws-1)}for(var M=0;M<i;M++){
var b=(o[1]+M)*a+(a-1)/2,A=Math.min(Math.max((b+.5)*d-.5,0),r.hs-1),k=Math.min(Math.floor(A),r.hs-2),F=A-k,S=k*r.ws,C=S+r.ws,B=Math.min(Math.floor((o[1]+M)*a+a/2),t.H-1),I=Math.min(Math.floor(B/r.f),r.hs-1)
;for(g=0;g<n;g++){var z=M*n+g,P=t.labf[B*t.W+w[g]];if(u[z]=P,P<0)f[z]=-1;else{
var T=r.tg[S+v[g]]+m[g]*(r.tg[S+v[g]+1]-r.tg[S+v[g]]),W=r.tg[C+v[g]]+m[g]*(r.tg[C+v[g]+1]-r.tg[C+v[g]]);h[z]=T+F*(W-T),l[z]=e[P],f[z]=r.src[I*r.ws+p[g]]}}}
return{w:n,h:i,tgt:h,cur:l,src:f,lab:u}}function Mt(t,r,e,a,o,n){
var i=Math.min(Math.max((o+.5)/a-.5,0),r-1),s=Math.min(Math.max((n+.5)/a-.5,0),e-1),h=Math.min(Math.floor(i),r-2),l=Math.min(Math.floor(s),e-2),f=i-h,u=s-l,c=l*r+h,d=t[c]+f*(t[c+1]-t[c])
;return d+u*(t[c+r]+f*(t[c+r+1]-t[c+r])-d)}function bt(t,r){
for(var e=Math.floor(t.W/r),a=Math.floor(t.H/r),o=e*a,n=new Float32Array(o),i=new Uint8Array(o),s=new Int8Array(o),h=1/(r*r*t.nc),l=0;l<a;l++)for(var f=0;f<e;f++){
for(var u=0,c=1,d=0;d<r;d++)for(var p=(l*r+d)*t.W+f*r,v=0;v<r;v++){t.union[p+v]||(c=0);for(var m=0;m<t.nc;m++)u+=t.chans[m][p+v]}var w=l*e+f;n[w]=u*h,i[w]=c,
s[w]=c?t.labf[Math.min(l*r+(r>>1),t.H-1)*t.W+Math.min(f*r+(r>>1),t.W-1)]:-1}return{w:e,h:a,lum:n,union:i,lab:s}}function At(t,o,n,i,s){s=s||1
;var l=void 0===(i=i||{}).maskStrength?1:i.maskStrength,c=void 0===i.maskFeather?12:i.maskFeather,d=s+"|"+l+"|"+c,p=i.cache&&i.cache.key===d?i.cache:null,v=p?p.L:1===s?{
w:t.W,h:t.H,lum:h(t.chans,t.W,t.H),union:t.union,lab:t.labf}:bt(t,s),m=v.w,w=v.h,g=m*w;if(!(l>0))return{prot:new Float32Array(g),w:m,h:w,b:s,full:0,part:0}
;if(p)return kt(t,o,n,s,v,p.M,l);for(var y=tt(v.lum,m,w,6/s),x=[],M=0;M<n.length;M++){for(var b=[],A=0;A<g;A+=11)v.lab[A]===M&&b.push(v.lum[A]-y[A])
;x.push(b.length?e(b).sigma:1)}y=null;var k=function(t,o,n,i,s,h,l,c,d){d=d||1
;for(var p=i*s,v=1/Math.max(l,.05),m=n,w=new Float32Array(p),g=0;g<p;g++)w[g]=n[g]?1:0
;for(var y=Math.max(2,Math.round(32/d)),x=Math.floor(i/y),M=Math.floor(s/y),b=new Float32Array(x*M),A=[],k=0;k<M;k++)for(var F=0;F<x;F++){
for(var S=0,C=!1,B=0;B<y&&!C;B++)for(var I=(k*y+B)*i+F*y,z=0;z<y;z++){if(!m[I+z]){C=!0;break}S+=t[I+z]}b[k*x+F]=C?NaN:S/(y*y),C||A.push(b[k*x+F])}var P=r(A)
;for(g=0;g<b.length;g++)b[g]!=b[g]&&(b[g]=P);var T=f(u(b,x,M,9),x,M,i,s);b=null;var W=new Float32Array(p),R=new Float32Array(p)
;for(g=0;g<p;g++)m[g]&&(R[g]=t[g]-T[g],W[g]=R[g]/(o[g]>=0?h[o[g]]:1));var G=tt(R,i,s,3/d);function q(t){return e(a(t,m,17))}R=null
;var L=tt(W,i,s,1.5/d),j=tt(W,i,s,8/d),H=new Float32Array(p);for(g=0;g<p;g++)H[g]=L[g]-j[g];j=null;var U=q(H),V=new Uint8Array(p),E=U.med+5*v*U.sigma
;for(g=0;g<p;g++)V[g]=H[g]>E?1:0;H=null,d<2&&(V=D(V,i,s));var N=new Uint8Array(p);for(g=0;g<p;g++)N[g]=L[g]>80&&V[g]?1:0;L=null,N=et(N,i,s,12/d)
;var O=et(V,i,s,3/d);for(g=0;g<p;g++)O[g]|=N[g];N=V=null;var X=et(O,i,s,4/d),K=new Float32Array(p),_=new Float32Array(p);for(g=0;g<p;g++)K[g]=X[g]?0:w[g],
_[g]=W[g]*K[g];var Y=tt(_,i,s,10/d),Z=tt(K,i,s,10/d),J=_;for(g=0;g<p;g++)J[g]=K[g]>0?W[g]:Y[g]/Math.max(Z[g],.001);Y=Z=K=W=null
;for(var Q=new Float32Array(p),$=[4,10,25],rt=0;rt<$.length;rt++){var at=$[rt],ht=tt(J,i,s,at/d),lt=q(ht),ft=new Uint8Array(p),ut=ht;for(g=0;g<p;g++){
var ct=ht[g]-lt.med;ft[g]=ct>3.5*v*lt.sigma?1:0,ut[g]=Math.min(Math.max((ct-2.5*v*lt.sigma)/(6*v*lt.sigma),0),1)}
var dt=et(ft=st(nt(ft=it(ft=ot(ft,i,s,2/d),i,s,Math.max(60,4*at*at)/(d*d)),i,s,Math.floor(at)/d),i,s),i,s,(Math.floor(2*at*c/12)+1)/d);for(g=0;g<p;g++){
var pt=dt[g]?ut[g]:0;ft[g]&&(pt=1),pt>Q[g]&&(Q[g]=pt)}ht=ut=ft=dt=null}for(J=null,Q=tt(Q,i,s,Math.max(c,1)/d),g=0;g<p;g++)Q[g]=Math.min(1.2*Q[g],1)
;var vt=new Float32Array(p);for(g=0;g<p;g++)vt[g]=O[g];vt=tt(vt,i,s,2/d);var mt=new Float32Array(p)
;for(g=0;g<p;g++)m[g]?mt[g]=Math.max(Math.min(1.3*vt[g],1),Q[g]):Q[g]=0;return{prot:mt,sigObj:G,ext:Q,starz:X,bg:T}}(v.lum,v.lab,v.union,m,w,x,l,c,s)
;return k.lumS=tt(v.lum,m,w,2/s),k.sigObj=k.ext=k.starz=null,i.cache&&(i.cache.key=d,i.cache.L=v,i.cache.M=k),kt(t,o,n,s,v,k,l)}function kt(t,r,a,o,n,i,s){
for(var h=n.w,l=n.h,f=h*l,u=function(t){if(t.lumStf)return t.lumStf;for(var r=bt(t,4),a=[],o=0;o<r.lum.length;o+=7)r.union[o]&&a.push(r.lum[o])
;var n=e(a),i=Math.max(n.med-2.8*n.sigma,0),s=(n.med-i)/(1-i);return t.lumStf={c0:i,m:-.75*s/(-.5*s-.25)}
}(t),c=u.c0,d=u.m,p=2*d-1,v=J.visEps*s,m=xt(t,r,a,o),w=new Float32Array(f),g=0,y=0,x=0,M=0;M<f;M++)if(n.union[M]){
var b=i.prot[M],A=m.tgt[M],k=m.cur[M],F=A*A-k*k;if(b>0&&F>0){
var S=p*Math.min(Math.max((i.lumS[M]-c)/(1-c),0),1)-d,C=p*Math.min(Math.max((i.bg[M]-c)/(1-c),0),1)-d,B=C*C/Math.max(S*S,1e-30);B>1&&(B=1);var I=A*(1-v/B),z=1
;I>k&&(z=1-Math.sqrt(I*I-k*k)/Math.sqrt(F)),b*=z<0?0:z}w[M]=b,x++,b>.99?g++:b>.01&&y++}return{prot:w,w:h,h:l,b:o,full:g/Math.max(x,1),part:y/Math.max(x,1)}}
function Ft(t,r,e,a){var o=Math.imul(r,2654435761)^Math.imul(e+1663821227,2246822519)^Math.imul(t+a,3266489917);o=Math.imul(o^o>>>16,2146121005),
o=Math.imul(o^o>>>15,2221713035),o^=o>>>16;var n=Math.imul(668265263^o,374761393);n=Math.imul(n^n>>>15,2246822519)
;var i=((o>>>0)+1)/4294967297,s=((n^=n>>>13)>>>0)/4294967296;return Math.sqrt(-2*Math.log(i))*Math.cos(2*Math.PI*s)}function St(t,r,e,a,o){
for(var n=(o=o||{}).log||function(){},i=t.nc,s=J.kernR,h=2*s+1,l=o.cache||{tiles:{},bytes:0,kern:{},kept:1
},f=o.rect||[0,0,t.W,t.H],u=f[0],c=f[1],d=f[2]-f[0],p=f[3]-f[1],v=e.map(function(t){return t.sigma}),m=o.out||[],w=0;w<i;w++){
var g=m[w]||new Float32Array(d*p),y=t.chans[w];if(o.rect)for(var x=0;x<p;x++)for(var M=(c+x)*t.W+u,b=0;b<d;b++)g[x*d+b]=y[M+b];else g.set(y);m[w]=g}
var A=256,k=A-2*s,F=65536;var S=null,C=null,B=null,I=null,z=0;function P(t,r,a,o,n){var f=t+"|"+r,u=l.tiles[f]||(l.tiles[f]={}),c=a+"|"+o;if(u[c])return u[c]
;if(!S){S=[],C=[],B=new Float64Array(F),I=new Float64Array(F);for(var d=0;d<i;d++)S.push(new Float64Array(F)),C.push(new Float64Array(F))}if(!n.done){
var p=t*k,v=r*k;for(d=0;d<i;d++){for(var m=S[d],w=C[d],g=0;g<A;g++)for(var y=0;y<A;y++)m[g*A+y]=Ft(d,p-s+y,v-s+g,7),w[g*A+y]=0;wt(m,w,A,!1)}n.done=!0}
for(var x=function(t,r){var a=t+"|"+r;if(l.kern[a])return l.kern[a];var o=function(t,r,e){
for(var a=J.psdT,o=a*a,n=J.kernR,i=2*n+1,s=[],h=[],l=0;l<e*e;l++)s.push(new Float64Array(o)),h.push(new Float64Array(o))
;for(var f=2*e,u=new Float64Array(f*f),c=0;c<o;c++)if(1!==e){for(var d=0;d<e;d++)for(var p=0;p<e;p++){
var v=d*e+p,m=p*e+d,w=.5*(t.re[v][c]-r.re[v][c]+(t.re[m][c]-r.re[m][c])),g=.5*(t.im[v][c]-r.im[v][c]-(t.im[m][c]-r.im[m][c]));u[d*f+p]=w,u[(d+e)*f+p+e]=w,
u[(d+e)*f+p]=g,u[d*f+p+e]=-g}var y=gt(u,f),x=y.V;for(d=0;d<e;d++)for(p=0;p<e;p++){for(var M=0,b=0,A=0;A<f;A++){var k=y.ev[A];if(!(k<=0)){var F=Math.sqrt(k)
;M+=x[d*f+A]*F*x[p*f+A],b+=x[(d+e)*f+A]*F*x[p*f+A]}}s[d*e+p][c]=M,h[d*e+p][c]=b}}else s[0][c]=Math.sqrt(Math.max(t.re[0][c]-r.re[0][c],0))
;var S=[],C=new Float64Array(e),B=new Float64Array(e),I=a/2;for(d=0;d<e;d++)for(p=0;p<e;p++){var z=s[d*e+p];wt(z,h[d*e+p],a,!0)
;for(var P=new Float64Array(i*i),T=0;T<a;T++)for(var W=0;W<a;W++){var R=z[T*a+W];C[d]+=R*R;var G=(T+I)%a-I,q=(W+I)%a-I
;Math.abs(G)<=n&&Math.abs(q)<=n&&(P[(G+n)*i+q+n]=R,B[d]+=R*R)}S.push(P)}var L=1;for(d=0;d<e;d++){var j=Math.sqrt(C[d]/Math.max(B[d],1e-30))
;for(L=Math.min(L,B[d]/Math.max(C[d],1e-30)),p=0;p<e;p++)for(P=S[d*e+p],A=0;A<P.length;A++)P[A]*=j}return{h:S,kept:L}}(e[t],e[r],i),n=[]
;l.kept=Math.min(l.kept,o.kept);for(var f=0;f<i*i;f++){
for(var u=new Float64Array(F),c=new Float64Array(F),d=o.h[f],p=-s;p<=s;p++)for(var v=-s;v<=s;v++)u[(p+A)%A*A+(v+A)%A]=d[(p+s)*h+v+s];wt(u,c,A,!1),n.push({re:u,
im:c})}return l.kern[a]=n}(a,o),M=[],b=0;b<i;b++){for(var P=0;P<F;P++)B[P]=0,I[P]=0;for(var T=0;T<i;T++){var W=x[b*i+T].re,R=x[b*i+T].im;for(m=S[T],w=C[T],
P=0;P<F;P++)B[P]+=W[P]*m[P]-R[P]*w[P],I[P]+=W[P]*w[P]+R[P]*m[P]}wt(B,I,A,!0);var G=new Float32Array(k*k);for(g=0;g<k;g++)for(y=0;y<k;y++)G[g*k+y]=B[(g+s)*A+y+s]
;M.push(G)}return l.bytes+=i*k*k*4,z++,u[c]=M}for(var T=new Float32Array(k*k),W=0,R=Math.floor(c/k);R*k<f[3];R++)for(var G=Math.floor(u/k);G*k<f[2];G++){
var q=Math.max(G*k,u),L=Math.max(R*k,c),j=Math.min((G+1)*k,f[2],t.W),D=Math.min((R+1)*k,f[3],t.H);if(!(j<=q||D<=L)){
for(var H=xt(t,r,v,1,[q,L,j,D]),U=j-q,V={},E=0,N=0;N<H.lab.length;N++){var O=H.lab[N],X=H.src[N]
;!(O<0||X<0||X===O)&&H.tgt[N]>1.0001*H.cur[N]&&(V[_=64*X+O]||(V[_]=!0,E++))}if(E){for(31&++W||n("  noise tiles: "+W),
x=L;x<D;x++)for(b=q;b<j;b++)T[(x-L)*U+b-q]=a?1-Mt(a.prot,a.w,a.h,a.b,b,x):1;var K={done:!1};for(var _ in V){
var Y=P(G,R,X=Math.floor(_/64),O=_%64,K),Z=Math.max(v[X]*v[X]-v[O]*v[O],1e-30),Q=v[O]*v[O];for(x=L;x<D;x++)for(b=q;b<j;b++)if(N=(x-L)*U+b-q,
H.lab[N]===O&&H.src[N]===X&&H.tgt[N]>1.0001*H.cur[N])for(var $=Math.sqrt(Math.min(Math.max((H.tgt[N]*H.tgt[N]-Q)/Z,0),1))*T[N],tt=(x-R*k)*k+b-G*k,rt=(x-c)*d+b-u,et=0;et<i;et++)m[et][rt]+=Y[et][tt]*$
}}}}return{chans:m,w:d,h:p,tiles:W,made:z,kept:l.kept,cacheMB:l.bytes/1048576}}function Ct(t,r){
for(var a=Math.floor(t.W/r),o=Math.floor(t.H/r),n=a*o,i=[],s=[],h=0;h<t.nc;h++){for(var f=l(t.chans[h],t.W,t.H,r).data,u=[],c=0;c<n;c+=7)0!==f[c]&&u.push(f[c])
;var d=e(u),p=Math.max(d.med-2.8*d.sigma,0),v=(d.med-p)/(1-p);s.push({c0:p,m:-.75*v/(-.5*v-.25)}),Bt(f,s[h]),i.push(f)}for(;i.length<3;)i.push(i[0]),
s.push(s[0]);return{w:a,h:o,b:r,rgb:i,stf:s}}function Bt(t,r){for(var e=r.c0,a=r.m,o=0;o<t.length;o++)if(0!==t[o]){var n=Math.min(Math.max((t[o]-e)/(1-e),0),1)
;t[o]=(a-1)*n/((2*a-1)*n-a)}return t}function It(t,r,e,a,o,n,i,s,h){
for(var l=Math.floor((e[2]-e[0])/a),f=Math.floor((e[3]-e[1])/a),u=l*f,c=1/(a*a),d=[],p=0;p<3;p++){var v=r[Math.min(p,t.nc-1)],m=new Float32Array(u)
;if(p>=t.nc)m.set(d[0]),d.push(m);else{for(var w=0;w<f;w++)for(var g=w*l,y=0;y<a;y++)for(var x=(e[1]+w*a+y)*t.W+e[0],M=0;M<l;M++){
for(var b=x+M*a,A=0,k=0;k<a;k++)A+=v[b+k];m[g+M]+=A}if(a>1)for(var F=0;F<u;F++)m[F]*=c;d.push(Bt(m,o[p]))}}var S=null,C=null;if(n)for(S=new Float32Array(u),
w=0;w<f;w++)for(M=0;M<l;M++)S[w*l+M]=Mt(n.prot,n.w,n.h,n.b,e[0]+M*a+(a-1)/2,e[1]+w*a+(a-1)/2);return i&&(C=xt(t,i,s,a,[e[0]/a,e[1]/a,e[0]/a+l,e[1]/a+f])),
(S||C)&&(d=function(t,r,e,a,o){
for(var n=Math.log(Math.max(o/a,1.0001)),i=t.w*t.h,s=[new Float32Array(i),new Float32Array(i),new Float32Array(i)],h=t.rgb,l=0;l<i;l++){
var f=h[0][l],u=h[1][l],c=h[2][l];if(e&&e.cur[l]>0){var d=Math.min(Math.max(Math.log(e.tgt[l]/a)/n,0),1),p=d<.5?.6-.6*d:.3-.6*(d-.5)
;f=.4*f+.6*(d<.5?.1:.1+1.8*(d-.5)),u=.4*u+.6*(.25+.7*d),c=.4*c+.6*Math.max(p,0)}r&&(f=.5*f+.65*r[l],u*=.5,c*=.5),s[0][l]=f>1?1:f,s[1][l]=u>1?1:u,s[2][l]=c>1?1:c
}return s}({w:l,h:f,rgb:d},S,C,Math.min.apply(null,s),Math.max.apply(null,s))),h&&function(t,r,e,a){
for(var o=r.w,n=Math.max(1,Math.round(a||1)),i=6*n,s=4*n,h=0;h<r.lab.length;h++){var l=r.lab[h];if(!(l<0)){
var f=e[l],u=r.edge[h],c=h%o,d=h/o|0,p=r.fo?r.fo[h]:-1,v=p>=0&&((c+d)/s|0)%2==0?.6:.3;p>=0&&(f=e[p]);for(var m=0;m<3;m++)t[m][h]=(1-v)*t[m][h]+v*f[m]
;if(r.ac&&!r.ac[h])for(m=0;m<3;m++)t[m][h]*=.35
;if(r.seam[h])for(m=0;m<3;m++)t[m][h]=.92;else if(u>=0&&((c+d)/i|0)%2==0)for(m=0;m<3;m++)t[m][h]=.25*t[m][h]+.75*e[u][m]}}}(d,function(t,r,e,a,o,n,i){
var s=Math.floor((r[2]-r[0])/e),h=Math.floor((r[3]-r[1])/e),l=s*h,f=e>>1,u=new Int8Array(l),c=new Uint32Array(l),d=new Uint8Array(l),p=new Int8Array(l),v=null,m=null,w=J.G,g=t.cells.Wc
;if(n){v=new Int8Array(l);for(var y=0;y<l;y++)v[y]=-1}null!=i&&i>=0&&(m=new Uint8Array(l));for(var x=0;x<h;x++){
for(var M=(r[1]+x*e+f)*t.W+r[0]+f,b=0;b<s;b++)u[x*s+b]=t.labf[M+b*e],c[x*s+b]=t.cov[M+b*e];var A=((r[1]+x*e+f)/w|0)*g
;if(o)for(b=0;b<s;b++)u[x*s+b]=ct(t,o[A+((r[0]+b*e+f)/w|0)],c[x*s+b]);if(v)for(b=0;b<s;b++)v[x*s+b]=n[A+((r[0]+b*e+f)/w|0)]
;if(m)for(b=0;b<s;b++)m[x*s+b]=c[x*s+b]>>>i&1}var k=Math.max(1,Math.round(a||1)),F=t.sig.length;for(x=0;x<h;x++)for(b=0;b<s;b++){var S=u[y=x*s+b],C=c[y]
;if(p[y]=-1,!(S<0)){var B=b+k<s?u[y+k]:-1,I=x+k<h?u[y+k*s]:-1;(B>=0&&B!==S||I>=0&&I!==S)&&(d[y]=1);var z=0;if(b>=k&&(z|=C&~c[y-k]),b+k<s&&(z|=C&~c[y+k]),
x>=k&&(z|=C&~c[y-k*s]),x+k<h&&(z|=C&~c[y+k*s]),z)for(var P=0;P<F;P++)if(z&1<<P){p[y]=P;break}}}return{w:s,h,lab:u,seam:d,edge:p,fo:v,ac:m}
}(t,e,a,h.lw,h.label,h.forced,h.active),h.colors,h.lw),{w:l,h:f,rgb:d}}function zt(t,r){
for(var e=r||t.cells.label,a=t.cells.Wc,o=t.cells.Hc,n=J.G,i=a+2,s=o+2,h=[],l=0,f=0;f<a*o;f++)e[f]>=0&&l++;for(var u=0;u<t.sig.length;u++){
for(var c=new Uint8Array(i*s),d=0,p=0;p<s;p++)for(var v=0;v<i;v++){var m=v>0&&p>0&&v<i-1&&p<s-1&&e[(p-1)*a+v-1]===u;c[p*i+v]=m?0:1,m&&d++}if(d){
var w=ht(c,i,s),g=0;for(f=1;f<w.length;f++)w[f]>w[g]&&(g=f);h.push({k:u,x:(g%i-1+.5)*n,y:((g/i|0)-1+.5)*n,area:d/Math.max(l,1)})}}return h}function Pt(t,r){
for(var e=J.G,a=t.cells.Wc,o=t.cells.Hc,n=new Int8Array(a*o),i=t.cut.valid,s=0;s<n.length;s++)n[s]=-1;for(var h=0;h<r.length;h++){var l=r[h]
;if(void 0===l.clear){var f=l.erase?0:l.k+1,u=l.r,c=u*u,d=l.pts,p=function(t,r){
for(var s=Math.max(0,Math.floor((t-u)/e)),h=Math.min(a-1,Math.floor((t+u)/e)),l=Math.max(0,Math.floor((r-u)/e)),d=Math.min(o-1,Math.floor((r+u)/e)),p=l;p<=d;p++)for(var v=s;v<=h;v++){
var m=(v+.5)*e-t,w=(p+.5)*e-r,g=p*a+v;m*m+w*w>c||(0===f?n[g]=-1:i[f-1][g]&&(n[g]=f-1))}};p(d[0],d[1])
;for(var v=2;v+1<d.length;v+=2)for(var m=d[v-2],w=d[v-1],g=d[v]-m,y=d[v+1]-w,x=Math.max(1,Math.ceil(Math.sqrt(g*g+y*y)/Math.max(u/3,e/2))),M=1;M<=x;M++)p(m+g*M/x,w+y*M/x)
}else for(s=0;s<n.length;s++)n[s]===l.clear&&(n[s]=-1)}return n}function Tt(t,r,e){
for(var a=t.cut,o=a.D,n=o.length,i=r.length,s=[],h=new Int32Array(a.auto),l=0,f=0;f<i;f++){var u=r[f];if(!(u<0||h[f]<0)){
for(var c=0;c<n;c++)s.push(c,f,o[c][f]),o[c][f]=c===u?0:1/0;h[f]=u,l++}}if(!l)return h;try{return $(o,a.wh,a.wv,h,t.cells.Wc,t.cells.Hc,J.sweeps,e).label
}finally{for(var d=0;d<s.length;d+=3)o[s[d]][s[d+1]]=s[d+2]}}function Wt(t){
for(var r=t.W,e=t.H,a=t.union,o=new Int32Array(r),n=new Int32Array(r+1),i=0,s=[0,0,r,e],h=0;h<e;h++){for(var l=h*r,f=0,u=0;u<r;u++)o[u]=a[l+u]?o[u]+1:0
;for(u=0;u<=r;u++){for(var c=u<r?o[u]:0;f>0&&o[n[f-1]]>=c;){var d=o[n[--f]],p=f>0?n[f-1]+1:0,v=d*(u-p);v>i&&(i=v,s=[p,h-d+1,u,h+1])}n[f++]=u}}return s}
var Rt="AutoPano",Gt="1.0.0",qt="AutoPano",Lt=[[1,"https://api.bepaid.by/products/prd_e9ae5ef19bddc47d/pay"],[3,"https://api.bepaid.by/products/prd_29731c50851f55a8/pay"],[5,"https://api.bepaid.by/products/prd_f2c63d66f7cfe15b/pay"],[10,"https://api.bepaid.by/products/prd_424196484db864d0/pay"]]
;class jt extends Error{}function Dt(){if(CoreApplication.processEvents(),console.abortRequested)throw new jt("Aborted by the user.")}function Ht(t,r){
let e=t.keywords;for(let t=0;t<e.length;++t)if(e[t].name===r){let r=e[t].strippedValue.trim(),a=parseFloat(r);return isFinite(a)?a:r}return null}
function Ut(t,r){let e=new ImageSolver;e.initialize(t,!1);let a=e.solverCfg;if(a.showStars=!1,a.showStarMatches=!1,a.showSimplifiedSurfaces=!1,
a.showDistortion=!1,a.generateErrorImg=!1,a.generateDistortModel=!1,a.distortionCorrection=!0,r&&(e.metadata.ra=r.ra,e.metadata.dec=r.dec),
!(e.metadata.resolution||e.metadata.focal&&e.metadata.xpixsz))throw new Error(t.mainView.id+" has no astrometric solution, and its header has no focal length / pixel size for plate solving. Solve it with ImageSolver first.")
;try{e.solveImage(t)}catch(t){return console.warningln("   ImageSolver: "+String(t&&t.message?t.message:t)),!1}return t.hasAstrometricSolution}function Vt(t,r){
let e=t.mainView.image,a=e.width,o=e.height,n=Math.ceil((a-1)/r)+3,i=Math.ceil((o-1)/r)+3,s=n*i,h=new Float64Array(s),l=new Float64Array(s)
;for(let t=0;t<i;++t)for(let e=0;e<n;++e)h[t*n+e]=(e-1)*r+.5,l[t*n+e]=(t-1)*r+.5;let f=new Float64Array(s),u=new Float64Array(s),c=0,d=null;try{
d=t.imageToCelestial(h,l,!0)}catch(t){d=null}for(let r=0;r<s;++r){if(d&&d.length===2*s)f[r]=d[2*r],u[r]=d[2*r+1];else{let e=null;try{
e=t.imageToCelestial(h[r],l[r])}catch(t){e=null}f[r]=e?e.x:NaN,u[r]=e?e.y:NaN}isFinite(f[r])&&isFinite(u[r])||++c}if(c>0){
for(let t=0;t<2;++t)for(let t=0;t<i;++t)for(let r=0;r<n;++r){let e=t*n+r;if(isFinite(f[e])&&isFinite(u[e]))continue
;let a=0===r?1:r===n-1?-1:0,o=0===t?1:t===i-1?-1:0,s=e+o*n+a,h=e+2*(o*n+a);if((a||o)&&isFinite(f[s])&&isFinite(f[h])){let t=f[s]-f[h]
;t>180?t-=360:t<-180&&(t+=360),f[e]=f[s]+t,u[e]=2*u[s]-u[h]}}
for(let r=0;r<s;++r)if(!isFinite(f[r])||!isFinite(u[r]))throw new Error("Cannot evaluate the astrometric solution of "+t.mainView.id+" near its borders.")}
return{step:r,nx:n,ny:i,ra:f,dec:u}}function Et(t){let r=t.mainView.image,a=r.width,o=r.height,n=[]
;for(let t=0;t<r.numberOfChannels;++t)n.push(r.toFloat32Array(new Rect(0,0,a,o),t));let i=0,s=0;for(let r=0;r<n.length;++r){let e=Ht(t,format("NOISE%02d",r))
;"number"==typeof e&&e>0&&(i+=e,++s)}return i=s===n.length?i/s:function(t,r,a){for(var o=0,n=0;n<t.length;n++){
for(var i=t[n],s=[],h=0;h+1<a;h+=2)for(var l=0;l+1<r;l+=2){var f=h*r+l,u=i[f],c=i[f+1],d=i[f+r],p=i[f+r+1];0!==u&&0!==c&&0!==d&&0!==p&&s.push((u-c-d+p)/2)}
o+=e(s).sigma}return o/t.length}(n,a,o),{id:t.mainView.id,w:a,h:o,chans:n,noise:i,grid:Vt(t,32)}}function Nt(t,r,e){
let a=File.systemTempDirectory+"/AutoPano_gx_"+r.mainView.id,o=a+".xisf",n=a+"_bg.xisf";for(let t of[o,n])File.exists(t)&&File.remove(t)
;let i=r.mainView.image,s=new ImageWindow(i.width,i.height,i.numberOfChannels,32,!0,i.isColor,"AutoPano_gx_tmp");try{
if(s.mainView.beginProcess(UndoFlag.NoSwapFile),s.mainView.image.assign(i),s.mainView.endProcess(),
!s.saveAs(o,!1,!1,!1,!1))throw new Error("could not write "+o)}finally{s.forceClose()}
let h='"'+File.unixPathToWindows(t)+'" -cli -cmd background-extraction -correction Subtraction -smoothing 0.046 -output "'+File.unixPathToWindows(a+"_bg")+'" "'+File.unixPathToWindows(o)+'"'
;console.writeln("   "+h);let l=new ExternalProcess,f="";for(l.onStandardErrorDataAvailable=function(){f+=String(this.stderr)},
l.start(h);l.isStarting;)CoreApplication.processEvents();for(;l.isRunning;)if(CoreApplication.processEvents(),console.abortRequested)throw l.kill(),
new jt("aborted")
;if(File.exists(o)&&File.remove(o),!File.exists(n))throw new Error("GraXpert failed on "+r.mainView.id+(f?": "+f.slice(-400):"")+". Untick 'Use GraXpert' to build without it.")
;let u=ImageWindow.open(n);try{let t=u[0].mainView.image
;if(t.width!==e.w||t.height!==e.h||t.numberOfChannels!==e.chans.length)throw new Error("GraXpert returned a different image size for "+r.mainView.id)
;for(let r=0;r<e.chans.length;++r)e.chans[r]=t.toFloat32Array(new Rect(0,0,e.w,e.h),r)}finally{for(let t of u)t.forceClose();File.remove(n)}}function Ot(t,i){
i=i||{};let f=new ElapsedTime,u=t=>{console.writeln(format("%7.1f s  ",f.value)+t),Dt()};!function(t){if(t.length<2)throw new Error("Tick at least two panels.")
;if(t.length>32)throw new Error("At most 32 panels per mosaic ("+t.length+" ticked).");let r=t[0].mainView.image.numberOfChannels,e=[];for(let a of t){
let t=a.mainView.image
;if(t.numberOfChannels!==r)throw new Error("All panels must be either colour or mono ("+a.mainView.id+" differs). Build mono filters one at a time.")
;t.median()>.25&&e.push(a.mainView.id+format(" (median %.3f)",t.median()))}if(e.length&&(console.warningln("** Not linear? "+e.join(", ")),
new MessageBox("<p>These panels do not look linear (unstretched): "+e.join(", ")+".</p><p>AutoPano is made for linear masters: photometry and noise matching assume linear data, so a stretched mosaic may show seams. Continue anyway?</p>",Rt,StdIcon.Warning,StdButton.Yes,StdButton.No).execute()!==StdButton.Yes))throw new jt("cancelled: non-linear panels")
}(t);let d=function(t){let r=t.filter(t=>!t.hasAstrometricSolution);if(0===r.length)return[]
;console.noteln("<end><cbr>Plate solving "+r.length+" panel(s) without an astrometric solution");let e=[];for(let t of r)Dt(),
console.writeln("   "+t.mainView.id+" ..."),Ut(t,null)?console.noteln("   "+t.mainView.id+": solved"):e.push(t);if(0===e.length)return[]
;if(e.length===t.length)throw new Error("ImageSolver could not solve any panel from the header coordinates. Solve at least one panel with ImageSolver (with corrected coordinates) and run AutoPano again: the others are then placed on it by their stars.")
;console.noteln("<end><cbr>Placing "+e.length+" unsolved panel(s) on solved neighbours by star patterns");let a=new Map,o=t=>(a.has(t)||a.set(t,function(t){
let r=t.mainView.image,e=r.width,a=r.height,o=[];for(let t=0;t<r.numberOfChannels;++t)o.push(r.toFloat32Array(new Rect(0,0,e,a),t));return A(h(o,e,a),e,a)}(t)),
a.get(t)),n=new Set;for(let r=!0;r&&e.length>0;){r=!1;for(let a of e.slice()){let i=a.mainView.image,s=!1;for(let r of t.filter(t=>t.hasAstrometricSolution)){
let t=a.mainView.id+"|"+r.mainView.id;if(n.has(t))continue;n.add(t),Dt();let e=G(o(r),o(a));if(!e)continue
;let h=(i.width-1)/2,l=(i.height-1)/2,f=r.imageToCelestial(e.a*h+e.b*l+e.tx+.5,e.c*h+e.d*l+e.ty+.5)
;if(f&&(console.writeln(format("   %s: %d stars matched with %s, centre RA %.4f Dec %.4f - solving",a.mainView.id,e.n,r.mainView.id,f.x,f.y)),Ut(a,{ra:f.x,
dec:f.y}))){s=!0;break}}s&&(console.noteln("   "+a.mainView.id+": solved"),e.splice(e.indexOf(a),1),r=!0)}}
if(t.length-e.length<2)throw new Error("Only one panel could be plate-solved. Solve the others with ImageSolver (with corrected coordinates) and run AutoPano again.")
;for(let t of e)console.warningln("** "+t.mainView.id+": could not be plate-solved - left out of the mosaic");return e.map(t=>({win:t,
reason:"could not be plate-solved (no star match with a solved panel, or ImageSolver failed): solve it with ImageSolver and build again"}))}(t).map(t=>({
id:t.win.mainView.id,reason:t.reason}));t=t.filter(t=>t.hasAstrometricSolution),console.noteln("<end><cbr>Reading "+t.length+" panels");let p=[]
;for(let r of t)p.push(Et(r)),Dt();if(i.graxpert){let r=function(){let t=File.homeDirectory+"/AppData/Local/GraXpertScript",r=t+"/GraXpertPath.txt";try{
if(File.exists(r)){let t=File.readTextFile(r).trim();if(t.length&&File.exists(t))return t}}catch(t){}
let e=File.homeDirectory+"/AppData/Local/Programs/GraXpert/GraXpert.exe";if(File.exists(e))return e
;new MessageBox("<p>GraXpert was not found. Select GraXpert.exe (it is remembered for AutoPano and PixInsight's GraXpert scripts).</p>",Rt,StdIcon.Information,StdButton.Ok).execute()
;let a=new OpenFileDialog;if(a.caption=Rt+": select GraXpert",a.filters=[["GraXpert","GraXpert*.exe"],["All files","*"]],
!a.execute())throw new jt("GraXpert not selected");try{File.directoryExists(t)||File.createDirectory(t,!0),File.writeTextFile(r,a.fileName)}catch(t){}
return a.fileName}();console.noteln("<end><cbr>GraXpert background extraction (subtraction) on "+p.length+" panels");for(let e=0;e<p.length;++e)Nt(r,t[e],p[e]),
u("  GraXpert: "+p[e].id)}let v=p.map(t=>t.id),m=t[0].mainView.image.isColor;console.noteln("Geometry");let w=z(p,{log:u,crop:!0});d=d.concat(w.excluded),
p=w.used.map(t=>p[t]),v=p.map(t=>t.id);let g=0;!function(t,r,e){var a=(e=e||{}).log||function(){};t.rep=[];for(var o=0;o<r.length;o++){
var n=Date.now(),i=B(r[o],t.trims[o],3),s=I(t,r[o],o,i,e.progress?function(t){e.progress(r[o].id,t)}:null);t.rep.push(s),e.keep||(r[o].chans=null),
a("  reprojected "+r[o].id+" -> box "+s.box.join(",")+" ("+((Date.now()-n)/1e3).toFixed(1)+" s)")}t.rep}(w,p,{log:u,progress:(t,r)=>{f.value-g>.5&&(g=f.value,
Dt())}}),console.noteln("Photometry");let y=function(t,e,a){
var i=(a=a||{}).log||function(){},l=q,f=l.bin,u=e.length,c=t.ref,d=t.W,p=t.H,v=Math.ceil(d/f),m=Math.ceil(p/f),w=v*m,g=t.rep[0].chans.length,y=[],x=a.vignetting||"auto"
;function M(r,a,n){var i=t.corrs?t.corrs[r].invert(a,n):[a,n],s=t.maps[r].inv(i[0],i[1]),h=(e[r].w-1)/2,l=(e[r].h-1)/2;return o(s[0]-h,s[1]-l)/o(h,l)}
y.push("Panels: "+u+", reference: "+e[c].id+"; mode: "+(a.keepGradients?"keep gradients":"flatten")+"; bins "+f+" px"),y.push("")
;for(var b={},A=0;A<u;A++)for(var k=A+1;k<u;k++){
for(var F=t.stars[A],S=t.stars[k],C={},B=[],I=0;I<S.x.length;I++)(C[ut=Math.floor(S.x[I]/2)+","+Math.floor(S.y[I]/2)]||(C[ut]=[])).push(I)
;for(I=0;I<F.x.length;I++){for(var z=Math.floor(F.x[I]/2),P=Math.floor(F.y[I]/2),R=-1,G=1.5,L=-1;L<=1;L++)for(var j=-1;j<=1;j++){var D=C[z+j+","+(P+L)]
;if(D)for(var J=0;J<D.length;J++){var Q=o(S.x[D[J]]-F.x[I],S.y[D[J]]-F.y[I]);Q<G&&(G=Q,R=D[J])}}R>=0&&B.push([(F.x[I]+S.x[R])/2,(F.y[I]+S.y[R])/2])}
B.length>=3&&(b[A+","+k]=B)}for(var $=[],tt=[],rt={},et=0;et<u;et++){var at=t.rep[et],ot=Date.now(),nt=H(cr=h(at.chans,at.w,at.h),at.mask,at.w,at.h);cr=null
;var it=new Uint8Array(at.w*at.h);for(A=0;A<it.length;A++)it[A]=at.mask[A]&&!nt[A]?1:0;nt=null,$.push(U(at,it,v,m))
;for(var st=V(at,it),ht=0,lt=0;lt<g;lt++)ht+=st[lt]/g;var ft=[];for(lt=0;lt<g;lt++)ft.push(st[lt]/ht*e[et].noise);for(var ut in tt.push(ft),
b)+(vt=ut.split(","))[0]!==et&&+vt[1]!==et||(rt[ut+"|"+et]=E(at,b[ut]));i("  photometry pass 1: "+e[et].id+" ("+((Date.now()-ot)/1e3).toFixed(1)+" s)")}
for(y.push(T("panel",10)+" "+function(){for(var t=[],r=0;r<g;r++)t.push(T("noise_"+r,10));return t.join("  ")}()),
et=0;et<u;et++)y.push(T(e[et].id,10)+" "+tt[et].map(function(t){return T(t.toExponential(3),10)}).join("  "));y.push("");var ct=[],dt={}
;for(et=0;et<u;et++)et!==c&&(dt[et]=ct.length,ct.push(et));var pt=[];for(var ut in b){A=+(vt=ut.split(","))[0],k=+vt[1];var vt,mt=rt[ut+"|"+A],wt=rt[ut+"|"+k]
;for(B=b[ut],I=0;I<B.length;I++){var gt=mt.flux[I],yt=wt.flux[I],xt=Math.max(mt.peak[I],wt.peak[I])<.5,Mt=1/0;for(lt=0;lt<g&&xt;lt++){if(!(gt[lt]>0&&yt[lt]>0)){
xt=!1;break}var bt=Math.sqrt(Math.PI*l.apR*l.apR)*Math.max(tt[A][lt],tt[k][lt]);Math.min(gt[lt],yt[lt])<=30*bt&&(xt=!1),
Mt=Math.min(Mt,Math.min(gt[lt],yt[lt])/bt)}if(xt){var At=[];for(lt=0;lt<g;lt++)At.push(Math.log(gt[lt])-Math.log(yt[lt]));pt.push({i:A,j:k,
ri:M(A,B[I][0],B[I][1]),rj:M(k,B[I][0],B[I][1]),lr:At,snr:Mt})}}}var kt=0;for(var ut in b)kt++
;if(y.push("Scale from "+pt.length+" star measurements in "+kt+" pairs (aperture r="+l.apR+" px, SNR > 30)."),
pt.length<3*ct.length)throw new Error("Too few stars shared by the overlaps for photometry ("+pt.length+").");function Ft(t){
for(var r=ct.length+(t?2:0),e=[],a=[],o=0;o<pt.length;o++){var i=pt[o],h=n(r);void 0!==dt[i.i]&&(h[dt[i.i]]+=1),void 0!==dt[i.j]&&(h[dt[i.j]]-=1),
t&&(h[r-2]=i.ri*i.ri-i.rj*i.rj,h[r-1]=Math.pow(i.ri,4)-Math.pow(i.rj,4)),e.push(h);var l=Math.min(i.snr,300);a.push(l*l/100)}for(var f=[],u=0;u<g;u++){
var c=pt.map(function(t){return t.lr[u]}),d=N(e,c,a,3,3),p=0,v=0,m=0,w=new s(r,1);for(o=0;o<pt.length;o++)if(d.keep[o]){l=0
;for(var y=0;y<r;y++)l+=e[o][y]*d.coef[y];var x=c[o]-l;p+=x*x,v+=a[o]*x*x,m++,w.add(new Float64Array(e[o]),[0],a[o])}v/=Math.max(m-r,1);var M=O(w.M,r);f.push({
coef:d.coef,rms:Math.sqrt(p/Math.max(m,1)),inv:M,chi:v})}return f}var St=Ft(!1),Ct=Ft(!0),Bt=ct.length+2,It=[],zt=[],Pt=!0;for(lt=0;lt<g;lt++){
var Tt=Ct[lt].coef[Bt-2],Wt=Ct[lt].coef[Bt-1],Rt=Ct[lt].inv,Gt=Ct[lt].chi,qt=Math.sqrt((Rt[Bt-2][Bt-2]+Rt[Bt-1][Bt-1]+2*Rt[Bt-1][Bt-2])*Gt)
;It.push(Math.exp(Tt+Wt)-1),zt.push(qt),Math.abs(It[lt])>l.vigMin&&Math.abs(It[lt])>3*qt||(Pt=!1)}var Lt="on"===x||"auto"===x&&Pt,jt=Lt?Ct:St,Dt=[],Ht=[]
;for(et=0;et<u;et++){var Ut=[];for(lt=0;lt<g;lt++)Ut.push(1);Dt.push(Ut)}for(lt=0;lt<g;lt++){for(I=0;I<ct.length;I++)Dt[ct[I]][lt]=Math.exp(jt[lt].coef[I])
;Ht.push(Lt?[jt[lt].coef[Bt-2],jt[lt].coef[Bt-1]]:[0,0])}for(y.push("  log-ratio rms: no vignetting "+St.map(function(t){return t.rms.toFixed(4)
}).join(" ")+" | with vignetting "+Ct.map(function(t){return t.rms.toFixed(4)}).join(" ")),
y.push("  vignetting model at the sensor corner: "+It.map(function(t,r){return(t>=0?"+":"")+(100*t).toFixed(2)+"+-"+(100*zt[r]).toFixed(2)+"%"
}).join(" ")+" -> "+(Lt?"APPLIED":"not applied (not significant in all channels)")),lt=0;lt<g;lt++)y.push("  ch"+lt+" scale errors: "+ct.map(function(t,r){
return e[t].id+" "+(100*Math.sqrt(jt[lt].inv[r][r]*jt[lt].chi)).toFixed(2)+"%"}).join(" "))
;for(et=0;et<u;et++)y.push("  "+T(e[et].id,10)+" "+Dt[et].map(function(t){return t.toFixed(4)}).join(" ")+(et===c?"   (reference)":""));function Vt(t,r){
return Math.exp(Ht[r][0]*t*t+Ht[r][1]*t*t*t*t)}y.push("");var Et=[];for(et=0;et<u;et++){var Nt=null;if(Lt){Nt=new Float32Array(w)
;for(var Ot=0;Ot<w;Ot++)$[et][0][Ot]==$[et][0][Ot]&&(Nt[Ot]=M(et,Ot%v*f+f/2,Math.floor(Ot/v)*f+f/2))}Et.push(Nt)}var Xt=[];for(et=0;et<u;et++){var Kt=[]
;for(lt=0;lt<g;lt++){Ut=new Float32Array(w);var _t=$[et][lt];for(Ot=0;Ot<w;Ot++)Ut[Ot]=_t[Ot]/(Dt[et][lt]*(Lt?Vt(Et[et][Ot],lt):1));Kt.push(Ut)}Xt.push(Kt)}
function Yt(t,r){return tt[t][r]/Dt[t][r]}function Zt(t,a){y.push(a);for(var o=T("  pair",24)+" "+W("bins",5)+" |",n=0;n<g;n++)o+=" ch"+n+" med  p90   b95  |"
;y.push(o);for(var i=[],s=0;s<u;s++)for(var h=s+1;h<u;h++){for(var l=0,f=0;f<w;f++)t[s][0][f]==t[s][0][f]&&t[h][0][f]==t[h][0][f]&&l++;if(!(l<20)){
var c=T("  "+e[s].id+"-"+e[h].id,24)+" "+W(String(l),5)+" |";for(n=0;n<g;n++){var d=[],p=[],x=Math.max(Yt(s,n),Yt(h,n)),M=new Float64Array(w);for(f=0;f<w;f++){
var b=t[s][n][f],A=t[h][n][f];b==b&&A==A&&t[s][0][f]==t[s][0][f]&&t[h][0][f]==t[h][0][f]?(d.push(b-A),p.push(Math.abs(b-A)),M[f]=b-A):M[f]=NaN}
for(var k=Y(M,v,m,8),F=0;F<k.length;F++)k[F]=Math.abs(k[F]);var S=Math.abs(r(d))/x
;c+=" "+W(S.toFixed(2),5)+" "+W((Z(p,90)/x).toFixed(2),5)+" "+W(k.length?(Z(k,95)/x).toFixed(2):"nan",5)+" |",i.push(S)}y.push(c)}}var C=0
;for(F=0;F<i.length;F++)C+=i[F]/i.length;return y.push("  mean |median step| = "+C.toFixed(3)+" sigma"),y.push(""),C}
y.push("Overlap sky difference in units of pixel noise (sigma): |median|, 90th pct of |diff| per "+f+"x"+f+" bin; b95 = 95th pct of |mean diff| over "+8*f+" px blocks (local steps)."),
y.push(""),Zt($,"A. raw:"),Zt(Xt,"B. after scale"+(Lt?" + vignetting":"")+":");var Jt=(l.bgDeg+1)*(l.bgDeg+2)/2,Qt=[],$t=[],tr=[],rr=[];for(et=0;et<u;et++){
var er=t.rep[et].box;$t.push([(er[0]+er[2])/2,(er[1]+er[3])/2,Math.max(er[2]-er[0],er[3]-er[1])/2]);var ar=[]
;for(lt=0;lt<g;lt++)ar.push(new Float32Array(Xt[et][lt]));tr.push(ar);var or=[];for(lt=0;lt<g;lt++)or.push(n(Jt));Qt.push(or)}for(lt=0;lt<g;lt++){var nr=[]
;for(Ot=0;Ot<w;Ot++)Xt[c][lt][Ot]==Xt[c][lt][Ot]&&nr.push(Xt[c][lt][Ot]);rr.push(r(nr))}var ir=[];if(!a.keepGradients){for(et=0;et<u;et++){var sr=[],hr=[]
;for(Ot=0;Ot<w;Ot++)Xt[et][0][Ot]==Xt[et][0][Ot]&&(sr.push(Ot),
hr.push(_((Ot%v*f+f/2-$t[et][0])/$t[et][2],(Math.floor(Ot/v)*f+f/2-$t[et][1])/$t[et][2],l.bgDeg)));for(lt=0;lt<g;lt++){var lr=sr.map(function(t){
return Xt[et][lt][t]}),fr=N(hr,lr,null,3,2);for(Qt[et][lt]=Array.prototype.slice.call(fr.coef),I=0;I<sr.length;I++){for(Kt=0,
J=0;J<Jt;J++)Kt+=hr[I][J]*fr.coef[J];tr[et][lt][sr[I]]=Xt[et][lt][sr[I]]-Kt+rr[lt]}}}Zt(tr,"C. after per-panel background flattening (degree "+l.bgDeg+"):"),
y.push("Background structure left after the polynomial (p95 of |mean| over "+8*f+" px blocks, sigma):");var ur=0;for(lt=0;lt<g;lt++)ur+=rr[lt]/g
;for(et=0;et<u;et++){var cr=new Float64Array(w),dr=0;for(lt=0;lt<g;lt++)dr+=Yt(et,lt)/g;for(Ot=0;Ot<w;Ot++){for(Kt=0,lt=0;lt<g;lt++)Kt+=tr[et][lt][Ot]
;cr[Ot]=Kt/g-ur}var pr=Y(cr,v,m,8),vr=r(pr);for(J=0;J<pr.length;J++)pr[J]=Math.abs(pr[J]-vr);ir.push(pr.length?Z(pr,95)/dr:0),
y.push("  "+T(e[et].id,10)+" "+ir[et].toFixed(3))}var mr=[];for(et=0;et<u;et++)ir[et]>l.structWarn&&mr.push(e[et].id)
;a.graxpert?y.push("  (GraXpert was applied to the panels)"+(mr.length?" -> it left background structure in: "+mr.join(", ")+"; the joint overlap fit corrects it where panels overlap.":"")):mr.length?y.push("  -> strong / complex gradient in "+mr.join(", ")+': recommend "Use GraXpert".'):y.push("  -> below "+l.structWarn.toFixed(2)+" sigma: GraXpert not needed."),
y.push("")}ot=Date.now();var wr=[],gr={},yr=0;for(et=0;et<u;et++)wr.push(new X(t.rep[et].box,l.knot));for(I=0;I<ct.length;I++)gr[ct[I]]=yr,yr+=wr[ct[I]].n
;var xr=[];for(A=0;A<u;A++)for(k=A+1;k<u;k++){var Mr=[];for(Ot=0;Ot<w;Ot++)tr[A][0][Ot]==tr[A][0][Ot]&&tr[k][0][Ot]==tr[k][0][Ot]&&Mr.push(Ot)
;Mr.length>=20&&xr.push({i:A,j:k,g:Mr})}var br=0;for(qt=0;qt<xr.length;qt++)br+=xr[qt].g.length
;var Ar=new Int32Array(br+1),kr=new Int32Array(32*br),Fr=new Float64Array(32*br),Sr=0,Cr=0,Br=new Int32Array(16),Ir=new Float64Array(16)
;for(qt=0;qt<xr.length;qt++){var zr=xr[qt];for(I=0;I<zr.g.length;I++){var Pr=(Ot=zr.g[I])%v*f+f/2;if(lr=Math.floor(Ot/v)*f+f/2,
void 0!==gr[zr.i])for(wr[zr.i].basis(Pr,lr,Br,Ir),J=0;J<16;J++)kr[Cr]=Br[J]+gr[zr.i],Fr[Cr++]=Ir[J];if(void 0!==gr[zr.j])for(wr[zr.j].basis(Pr,lr,Br,Ir),
J=0;J<16;J++)kr[Cr]=Br[J]+gr[zr.j],Fr[Cr++]=-Ir[J];Ar[++Sr]=Cr}}var Tr=[],Wr=[];for(I=0;I<ct.length;I++){var Rr=wr[ct[I]],Gr=gr[ct[I]]
;for(lr=0;lr<Rr.ny;lr++)for(Pr=0;Pr<Rr.nx;Pr++)Pr+1<Rr.nx&&(Tr.push(Gr+lr*Rr.nx+Pr),Wr.push(Gr+lr*Rr.nx+Pr+1)),lr+1<Rr.ny&&(Tr.push(Gr+lr*Rr.nx+Pr),
Wr.push(Gr+(lr+1)*Rr.nx+Pr))}var qr=l.smooth*(l.knot/f)*(l.knot/f),Lr=[];for(et=0;et<u;et++){for(or=[],lt=0;lt<g;lt++)or.push(new Float64Array(wr[et].n))
;Lr.push(or)}var jr=0;for(lt=0;lt<g;lt++){lr=new Float64Array(br);var Dr=new Float64Array(br),Hr=(J=0,0);for(qt=0;qt<xr.length;qt++){
var Ur=1/(Yt((zr=xr[qt]).i,lt)*Yt(zr.i,lt)+Yt(zr.j,lt)*Yt(zr.j,lt));for(I=0;I<zr.g.length;I++,J++)lr[J]=tr[zr.i][lt][zr.g[I]]-tr[zr.j][lt][zr.g[I]],Dr[J]=Ur,
Hr+=Ur}Hr/=br;var Vr=new Uint8Array(br),Er=new Float64Array(br);for(Pr=null,Nt=new Float64Array(br),J=0;J<br;J++)Dr[J]/=Hr,Vr[J]=1;for(var Nr=0;Nr<6;Nr++){
for(J=0;J<br;J++)Er[J]=Vr[J]?Dr[J]:0;jr+=(Pr=K(yr,Ar,kr,Fr,Er,lr,Tr,Wr,qr,1e-6,Pr,1e-7,3e3)).iterations;var Or=[];for(J=0;J<br;J++){for(Kt=0,
Wt=Ar[J];Wt<Ar[J+1];Wt++)Kt+=Fr[Wt]*Pr[kr[Wt]];Nt[J]=lr[J]-Kt,Vr[J]&&Or.push(Math.abs(Nt[J]))}var Xr=1.4826*r(Or),Kr=!1;for(J=0;J<br;J++){
var _r=Math.abs(Nt[J])<3*Xr?1:0;_r!==Vr[J]&&(Vr[J]=_r,Kr=!0)}if(!Kr)break}for(I=0;I<ct.length;I++)Lr[ct[I]][lt]=Pr.subarray(gr[ct[I]],gr[ct[I]]+wr[ct[I]].n)}
i("  joint surfaces: "+yr+" unknowns, "+br+" overlap bins, "+jr+" CG iterations ("+((Date.now()-ot)/1e3).toFixed(1)+" s)");var Yr=[];for(et=0;et<u;et++){
for(ar=[],lt=0;lt<g;lt++){for(Ut=new Float32Array(tr[et][lt]),Ot=0;Ot<w;Ot++)Ut[Ot]==Ut[Ot]&&(Ut[Ot]-=wr[et].eval(Ot%v*f+f/2,Math.floor(Ot/v)*f+f/2,Lr[et][lt]))
;ar.push(Ut)}Yr.push(ar)}for(Zt(Yr,"D. after joint residual surfaces (B-spline, knots "+l.knot+" px, smooth "+l.smooth.toFixed(1)+", reference fixed):"),
et=0;et<u;et++){var Zr=(at=t.rep[et]).box[0],Jr=at.box[1],Qr=Math.ceil((at.w-1)/4)+2,$r=Math.ceil((at.h-1)/4)+2;for(lt=0;lt<g;lt++){
var te=new Float32Array(Qr*$r),re=new Float32Array(Qr*$r);for(k=0;k<$r;k++)for(A=0;A<Qr;A++){var ee=Zr+4*A,ae=Jr+4*k
;if(te[Gr=k*Qr+A]=Dt[et][lt]*(Lt?Vt(M(et,ee,ae),lt):1),Ut=wr[et].eval(ee,ae,Lr[et][lt]),!a.keepGradients){
var oe=_((ee-$t[et][0])/$t[et][2],(ae-$t[et][1])/$t[et][2],l.bgDeg);for(Kt=0,J=0;J<Jt;J++)Kt+=oe[J]*Qt[et][lt][J];Ut+=Kt-rr[lt]}re[Gr]=Ut}var ne=at.chans[lt]
;for(lr=0;lr<at.h;lr++){P=lr/4;var ie=Math.floor(P),se=P-ie;for(Pr=0;Pr<at.w;Pr++)if(Gr=lr*at.w+Pr,at.mask[Gr]){z=Pr/4
;var he=Math.floor(z),le=z-he,fe=ie*Qr+he,ue=fe+Qr,ce=te[fe]+le*(te[fe+1]-te[fe]),de=te[ue]+le*(te[ue+1]-te[ue]),pe=re[fe]+le*(re[fe+1]-re[fe]),ve=re[ue]+le*(re[ue+1]-re[ue])
;ne[Gr]=ne[Gr]/(ce+se*(de-ce))-(pe+se*(ve-pe))}else ne[Gr]=0}}}var me=[];for(et=0;et<u;et++){for(Kt=[],lt=0;lt<g;lt++)Kt.push(Yt(et,lt));me.push(Kt)}return{
report:y,scale:Dt,vignetting:Ht,useVig:Lt,bg:Qt,pedestal:rr,noise:tt,sigma:me,struct:ir,recommendGraXpert:ir.some(function(t){return t>l.structWarn})}}(w,p,{
log:u});console.noteln("Seams and blending");let x=function(t,r,o){
for(var n=J,i=(o=o||{}).log||function(){},s=t.rep.length,h=t.W,l=t.H,f=t.rep[0].chans.length,u=n.G,d=1<<n.levels,p=Math.ceil(h/d)*d,v=Math.ceil(l/d)*d,m=p/u,w=v/u,g=m*w,y=[],x=0;x<s;x++){
for(var M=0,b=0;b<f;b++)M+=r[x][b]/f;y.push(M)}var A=o.names||t.rep.map(function(t,r){return"panel "+(r+1)}),k=[],F=[],S=[];for(x=0;x<s;x++){
for(var C=(Lt=t.rep[x]).box[0],B=Lt.box[1],I=new Uint8Array(g),z=new Float32Array(g),P=Math.floor(C/u),R=Math.floor(B/u),G=Math.floor((C+Lt.w)/u),q=Math.floor((B+Lt.h)/u),L=R;L<q;L++)for(var j=P;j<G;j++){
var D=j*u-C,H=L*u-B;if(!(D<0||H<0||D+u>Lt.w||H+u>Lt.h)){for(var U=1,V=(M=0,0);V<u&&U;V++)for(var E=(H+V)*Lt.w+D,N=0;N<u;N++){if(!Lt.mask[E+N]){U=0;break}
for(b=0;b<f;b++)M+=Lt.chans[b][E+N]}U&&(I[L*m+j]=1,z[L*m+j]=M/(u*u*f))}}F.push(I),S.push(z)}
for(var O=new Uint8Array(g),X=new Float32Array(g),K=new Uint8Array(g),_=0;_<g;_++){M=0;var Y=0;for(x=0;x<s;x++)F[x][_]&&(M+=S[x][_],Y++);K[_]=Y,O[_]=Y?1:0,
X[_]=Y?M/Y:0}S=null;var Z=e(a(X,O)),Q=new Float32Array(g);for(_=0;_<g;_++)Q[_]=O[_]?Math.min(Math.max((X[_]-Z.med)/(5*Z.sigma),0),1):0;Q=c(function(t,r,e){
for(var a=new Float32Array(r*e),o=new Float32Array(r*e),n=0;n<e;n++)for(var i=0;i<r;i++){
for(var s=-1/0,h=n*r,l=Math.max(0,i-2);l<=Math.min(r-1,i+2);l++)t[h+l]>s&&(s=t[h+l]);a[h+i]=s}for(i=0;i<r;i++)for(n=0;n<e;n++){for(s=-1/0,
l=Math.max(0,n-2);l<=Math.min(e-1,n+2);l++)a[l*r+i]>s&&(s=a[l*r+i]);o[n*r+i]=s}return o}(Q,m,w),m,w,1)
;for(var tt=new Float64Array(w*(m-1)),rt=new Float64Array((w-1)*m),et=0;et<w;et++)for(var at=0;at+1<m;at++)tt[et*(m-1)+at]=n.seamW+n.objW*Math.max(Q[et*m+at],Q[et*m+at+1])
;for(et=0;et+1<w;et++)for(at=0;at<m;at++)rt[et*m+at]=n.seamW+n.objW*Math.max(Q[et*m+at],Q[(et+1)*m+at]);var ot=[],nt=[],it=m+2,st=w+2;for(x=0;x<s;x++){
var lt=new Uint8Array(it*st);for(et=0;et<st;et++)for(at=0;at<it;at++)lt[et*it+at]=0!==at&&0!==et&&at!==it-1&&et!==st-1&&F[x][(et-1)*m+at-1]?0:1
;var ft=ht(lt,it,st),ct=new Float32Array(g);for(et=0;et<w;et++)for(at=0;at<m;at++)ct[et*m+at]=ft[(et+1)*it+at+1]*u;nt.push(ct)}var vt=new Float64Array(g)
;for(_=0;_<g;_++){var mt=1/0;for(x=0;x<s;x++)F[x][_]&&y[x]<mt&&(mt=y[x]);vt[_]=mt}for(x=0;x<s;x++){var wt=new Float64Array(g);for(_=0;_<g;_++)if(wt[_]=1/0,
F[x][_]&&!((ct=nt[x][_])<n.edgeMin&&1!==K[_])){var gt=n.edgeW*Math.max(n.edgeR/Math.max(ct,1)-1,0);wt[_]=n.noiseW*Math.log(y[x]/vt[_])+Math.min(gt,50)}
ot.push(wt)}var yt=new Int32Array(g);for(_=0;_<g;_++)if(O[_]){var xt=!1;for(x=0;x<s;x++)isFinite(ot[x][_])&&(xt=!0)
;if(!xt)for(x=0;x<s;x++)F[x][_]&&(ot[x][_]=50+n.noiseW*Math.log(y[x]/vt[_]));var Mt=-1,bt=1/0;for(x=0;x<s;x++)ot[x][_]<bt&&(bt=ot[x][_],Mt=x);yt[_]=Mt
}else yt[_]=-1;nt=null,i("graph cut on "+m+" x "+w+" cells");var At=$(ot,tt,rt,yt,m,w,n.sweeps,i);yt=At.label,
k.push("Labels: graph cut "+m+" x "+w+" cells of "+u+" px, energy "+At.hist[0].toFixed(0)+" -> "+At.hist[At.hist.length-1].toFixed(0)+" ("+(At.hist.length-1)+" expansions accepted).")
;var kt=0,Ft=0;for(et=0;et<w;et++)for(at=0;at<m;at++){var St=yt[_=et*m+at];St<0||(at+1<m&&yt[_+1]>=0&&yt[_+1]!==St&&(kt++,Q[_]>.3&&Ft++),
et+1<w&&yt[_+m]>=0&&yt[_+m]!==St&&(kt++,Q[_]>.3&&Ft++))}k.push("Seams: "+kt*u+" px total, "+(kt?100*Ft/kt:0).toFixed(1)+"% on stars/galaxies.")
;var Ct=Math.min.apply(null,y),Bt=0;for(_=0;_<g;_++)Bt+=O[_];for(k.push("",T("panel",12)+W("sigma",10)+W("rel",7)+W("area%",8)+W("cover%",8)),x=0;x<s;x++){
var It=0,zt=0;for(_=0;_<g;_++)yt[_]===x&&It++,F[x][_]&&zt++
;k.push(T(A[x],12)+W(y[x].toExponential(3),10)+W((y[x]/Ct).toFixed(2),7)+W((100*It/Bt).toFixed(1),8)+W((100*zt/Bt).toFixed(1),8))}
var Pt=h*l,Tt=new Uint8Array(Pt),Wt=s<=8?new Uint8Array(Pt):s<=16?new Uint16Array(Pt):new Uint32Array(Pt);for(x=0;x<s;x++){C=(Lt=t.rep[x]).box[0],B=Lt.box[1]
;var Rt=1<<x;for(et=0;et<Lt.h;et++)for(E=(B+et)*h+C,M=et*Lt.w,at=0;at<Lt.w;at++)Lt.mask[M+at]&&(Tt[E+at]=1,Wt[E+at]|=Rt)}var Gt=y.map(function(t,r){return r
}).sort(function(t,r){return y[t]-y[r]}),qt={W:h,H:l,nc:f,chans:null,labf:new Int8Array(Pt),union:Tt,cov:Wt,sig:y,order:Gt,names:A,report:k,cells:{label:yt,
Wc:m,Hc:w},cut:{D:ot,wh:tt,wv:rt,valid:F,auto:new Int32Array(yt)},fill:[],fbox:[]};for(dt(qt,yt,[0,0,h,l]),x=0;x<s;x++){mt=(Lt=t.rep[x]).box
;var Lt,jt=[Math.max(Math.floor(mt[0]/d)*d-d,0),Math.max(Math.floor(mt[1]/d)*d-d,0),Math.min(Math.ceil(mt[2]/d)*d+d,p),Math.min(Math.ceil(mt[3]/d)*d+d,v)],Dt=jt[2]-jt[0],Ht=jt[3]-jt[1],Ut=(It=Dt*Ht,
Lt.box[0]-jt[0]),Vt=Lt.box[1]-jt[1],Et=[];for(i("  extend "+A[x]),b=0;b<f;b++){var Nt=new Float32Array(It),Ot=new Float32Array(It)
;for(et=0;et<Lt.h;et++)for(at=0;at<Lt.w;at++)M=et*Lt.w+at,Lt.mask[M]&&(Nt[ct=(et+Vt)*Dt+at+Ut]=Lt.chans[b][M],Ot[ct]=1);Et.push(ut(Nt,Ot,Dt,Ht))}
qt.fill.push(Et),qt.fbox.push(jt)}var Xt=pt(qt,[0,0,p,v],i);for(qt.chans=[],b=0;b<f;b++){var Kt=new Float32Array(Pt),_t=Xt[b]
;for(et=0;et<l;et++)for(at=0;at<h;at++)Kt[_=et*h+at]=Tt[_]?_t[et*p+at]:0;qt.chans.push(Kt)}return qt}(w,y.sigma,{log:u,names:v});console.noteln("Noise spectra")
;let M=function(t,e){
for(var a=(e=e||{}).log||function(){},o=J.psdT,n=o*o,i=[],s=new Float64Array(o),f=new Float64Array(n),u=0,c=0;c<o;c++)s[c]=.5-.5*Math.cos(2*Math.PI*c/(o-1))
;for(var d=0;d<o;d++)for(var p=0;p<o;p++)f[d*o+p]=s[d]*s[p],u+=f[d*o+p]*f[d*o+p];for(var v=0;v<t.rep.length;v++){
var m=t.rep[v],w=m.w,g=m.h,y=m.chans.length,x=l(h(m.chans,w,g),w,g,2),M=new Uint8Array(x.w*x.h);for(d=0;d<x.h;d++)for(p=0;p<x.w;p++){var b=2*d*w+2*p
;M[d*x.w+p]=m.mask[b]&m.mask[b+1]&m.mask[b+w]&m.mask[b+w+1]}var A=H(x.data,M,x.w,x.h,2),k=new Uint8Array(w*g)
;for(d=0;d<g;d++)for(p=0;p<w;p++)k[d*w+p]=A[Math.min(d>>1,x.h-1)*x.w+Math.min(p>>1,x.w-1)];x=M=A=null
;for(var F=[],S=[],C=0;C<y*y;C++)F.push(new Float64Array(n)),S.push(new Float64Array(n))
;for(var B=[],I=[],z=new Uint8Array(n),P=new Float64Array(n),T=0,W=0;W<y;W++)B.push(new Float64Array(n)),I.push(new Float64Array(n))
;for(var R=0;R<g-o;R+=o/2)for(var G=0;G<w-o;G+=o/2){var q=!0,L=0,j=0;for(d=0;d<o&&q;d++)for(p=0;p<o;p++){if(c=(R+d)*w+G+p,!m.mask[c]){q=!1;break}var D=k[c]?0:1
;z[d*o+p]=D,L+=D,D&&(j+=f[d*o+p]*f[d*o+p])}if(q&&!(L<.85*n)){var U=1/Math.sqrt(j/u);for(W=0;W<y;W++){var V=m.chans[W],E=0
;for(d=0;d<o;d++)for(p=0;p<o;p++)z[d*o+p]&&(P[E++]=V[(R+d)*w+G+p]);var N=r(P,E),O=B[W],X=I[W]
;for(d=0;d<o;d++)for(p=0;p<o;p++)O[et=d*o+p]=z[et]?(V[(R+d)*w+G+p]-N)*f[et]*U:0,X[et]=0;wt(O,X,o,!1)}
for(var K=0;K<y;K++)for(var _=K;_<y;_++)for(var Y=F[K*y+_],Z=S[K*y+_],Q=B[K],$=I[K],tt=B[_],rt=I[_],et=0;et<n;et++)Y[et]+=Q[et]*tt[et]+$[et]*rt[et],
Z[et]+=$[et]*tt[et]-Q[et]*rt[et];T++}}for(K=0;K<y;K++)for(_=0;_<K;_++){Y=F[K*y+_],Z=S[K*y+_];var at=F[_*y+K],ot=S[_*y+K];for(et=0;et<n;et++)Y[et]=at[et],
Z[et]=-ot[et]}var nt=1/(Math.max(T,1)*u),it=0;for(C=0;C<y*y;C++)for(et=0;et<n;et++)F[C][et]*=nt,S[C][et]*=nt;for(W=0;W<y;W++)for(et=0;et<n;et++)it+=F[W*y+W][et]
;i.push({re:F,im:S,n:T,sigma:Math.sqrt(it/n/y)}),a("  noise spectrum "+(e.names?e.names[v]:v)+": "+T+" sky patches, sigma "+i[v].sigma.toExponential(3))}
return i}(w,{log:u,names:v});return w.rep=null,console.writeln("<end><cbr><br>"+w.report.join("\n")),
console.writeln("<end><cbr><br>Photometry<br>"+y.report.join("\n")),console.writeln("<end><cbr><br>Seams<br>"+x.report.join("\n")),
y.recommendGraXpert&&!i.graxpert&&console.warningln("** Strong / complex background gradients detected: tick 'Use GraXpert' and build again."),
console.noteln(format("<end><cbr>AutoPano: %d x %d px mosaic analysed in %.1f s",x.W,x.H,f.value)),
d.length&&console.warningln("<end><cbr>** Left out of the mosaic: "+d.map(t=>t.id+" - "+t.reason).join("; ")),{S:x,spectra:M,sig:M.map(t=>t.sigma),names:v,
wcs:R(w),isColor:m,nPanels:p.length,excluded:d,gxSuggest:y.recommendGraXpert&&!i.graxpert,crop:Wt(x),cropAngle:w.canvas.crop?w.canvas.crop.angle:0,NC:{tiles:{},
bytes:0,kern:{},kept:1},mcache:{},R:null}}class Xt extends Dialog{constructor(){super();let t=t=>()=>{Dialog.openBrowser(t),this.ok()}
;this.textLabel=new Label(this),this.textLabel.wordWrapping=!0,this.textLabel.useRichText=!0,
this.textLabel.text="<p>Thank you for using AutoPano! If it saved you time, you can support its development \u2014 any amount via PayPal, or by card with one of the buttons below.</p>",
this.textLabel.setScaledFixedWidth(380),this.paypalButton=new PushButton(this),this.paypalButton.text="PayPal (any amount)",
this.paypalButton.onClick=t("https://www.paypal.com/donate/?business=contact%40bluebelleweddings.com&no_recurring=0&item_name=AutoPano"),
this.cardLabel=new Label(this),this.cardLabel.text="By card:",this.cardSizer=new HorizontalSizer,this.cardSizer.spacing=4;for(let r of Lt){
let e=new PushButton(this);e.text="$"+r[0],e.onClick=t(r[1]),this.cardSizer.add(e,100)}this.sizer=new VerticalSizer,this.sizer.margin=12,this.sizer.spacing=8,
this.sizer.add(this.textLabel),this.sizer.add(this.paypalButton),this.sizer.addSpacing(4),this.sizer.add(this.cardLabel),this.sizer.add(this.cardSizer),
this.windowTitle="Support the author",this.adjustToContents(),this.setFixedSize()}}class Kt extends Control{constructor(t){super(t),this.bitmap=null,
this.pxScale=1,this.detail=null,this.zoom=1,this.ox=0,this.oy=0,this.drag=null,this.onViewChanged=null,this.cropRect=null,this.labels=null,this.editor=null,
this.stroke=null,this.cursorPos=null,this.mouseTracking=!0,this.message="Build the mosaic to see the preview",this.setScaledMinSize(520,520),
this.toolTip="<p>Mouse wheel: zoom (from 1:2 on, the visible part is shown in full resolution with the added noise) &nbsp; Drag: pan &nbsp; Double click: fit</p>",
this.wheelTimer=new Timer,this.wheelTimer.interval=.35,this.wheelTimer.singleShot=!0,this.wheelTimer.onTimeout=()=>this.viewChanged(),this.onPaint=()=>{
let t=new Graphics(this);if(t.fillRect(0,0,this.width,this.height,new Brush(4280295456)),this.bitmap){let r=this.view();t.translateTransformation(r.tx,r.ty),
t.scaleTransformation(r.k),t.drawBitmap(0,0,this.bitmap);let e=this.detail;if(e&&(t.resetTransformation(),
t.translateTransformation(r.tx+r.k*e.x0/this.pxScale,r.ty+r.k*e.y0/this.pxScale),t.scaleTransformation(r.k*e.s/this.pxScale),t.drawBitmap(0,0,e.bitmap)),
this.cropRect){t.resetTransformation();let e=r.k/this.pxScale,a=this.cropRect;t.pen=new Pen(3221225472,3),
t.drawRect(r.tx+a[0]*e,r.ty+a[1]*e,r.tx+a[2]*e,r.ty+a[3]*e),t.pen=new Pen(4294955072,1),t.drawRect(r.tx+a[0]*e,r.ty+a[1]*e,r.tx+a[2]*e,r.ty+a[3]*e)}
if(this.labels){t.resetTransformation();let e=this.font.ascent;for(let a of this.labels){
let o=Math.round(r.tx+r.k*a.x/this.pxScale-this.font.width(a.text)/2),n=Math.round(r.ty+r.k*a.y/this.pxScale+e/2);t.pen=new Pen(4278190080)
;for(let r of[[-1,0],[1,0],[0,-1],[0,1],[1,1]])t.drawText(o+r[0],n+r[1],a.text);t.pen=new Pen(a.color),t.drawText(o,n,a.text)}}if(this.editor){
t.resetTransformation(),t.antialiasing=!0;let e=r.k/this.pxScale,a=this.editor.radius()*e;if(this.stroke){
let o=(this.stroke.erase?2164260863:16777215&this.editor.color()|2147483648)>>>0,n=this.stroke.pts,i=[]
;for(let t=0;t+1<n.length;t+=2)i.push(new Point(r.tx+n[t]*e,r.ty+n[t+1]*e));1===i.length?t.fillCircle(i[0],a,new Brush(o)):(t.pen=new Pen(o,2*a),
t.drawPolyline(i))}this.cursorPos&&(t.strokeCircle(this.cursorPos.x,this.cursorPos.y,a+1,new Pen(3221225472,1)),
t.strokeCircle(this.cursorPos.x,this.cursorPos.y,a,new Pen(4294967295,1)))}}else t.pen=new Pen(4288716960),
t.drawTextRect(0,0,this.width,this.height,this.message,TextAlignment.Center|TextAlignment.VertCenter);t.end()},this.onMouseWheel=(t,r,e)=>{
if(!this.bitmap)return;let a=this.view(),o=(t-a.tx)/a.k,n=(r-a.ty)/a.k;if(this.zoom=Math.max(1,Math.min(64,this.zoom*(e>0?1.25:.8))),
1===this.zoom)this.ox=this.oy=0;else{let e=this.view();this.ox+=t-(e.tx+o*e.k),this.oy+=r-(e.ty+n*e.k)}this.detail=null,this.update(),this.wheelTimer.stop(),
this.wheelTimer.start()},this.onMousePress=(t,r,e,a,o)=>{if(this.editor&&this.bitmap&&e===MouseButton.Left&&!(o&KeyModifier.SpaceBar)){let e=this.toMosaic(t,r)
;return o&KeyModifier.Control?void this.editor.pick(e[0],e[1]):(this.stroke={erase:0!==(o&KeyModifier.Alt),pts:e},void this.update())}this.drag={x:t,y:r,
ox:this.ox,oy:this.oy}},this.onMouseMove=(t,r)=>{if(this.editor&&(this.cursorPos={x:t,y:r}),this.stroke){
let e=this.toMosaic(t,r),a=this.stroke.pts,o=a.length,n=Math.max(this.editor.radius()/4,2*this.pxScale/this.view().k)
;return Math.hypot(e[0]-a[o-2],e[1]-a[o-1])>=n&&a.push(e[0],e[1]),void this.update()}this.drag?(this.ox=this.drag.ox+t-this.drag.x,
this.oy=this.drag.oy+r-this.drag.y,this.update()):this.editor&&this.update()},this.onLeave=()=>{this.cursorPos&&(this.cursorPos=null,this.update())},
this.onMouseRelease=()=>{if(this.stroke){let t=this.stroke;return this.stroke=null,void this.editor.strokeDone(t)}
let t=this.drag&&(this.ox!==this.drag.ox||this.oy!==this.drag.oy);this.drag=null,t&&(this.detail=null,this.viewChanged())},this.onMouseDoubleClick=()=>{
this.zoom=1,this.ox=this.oy=0,this.detail=null,this.update()},this.onResize=()=>{this.detail=null,this.update()}}viewChanged(){
this.onViewChanged&&this.onViewChanged()}toMosaic(t,r){let e=this.view();return[(t-e.tx)/e.k*this.pxScale,(r-e.ty)/e.k*this.pxScale]}view(){
let t=this.bitmap.width,r=this.bitmap.height,e=Math.min(this.width/t,this.height/r)*this.zoom;return{k:e,tx:(this.width-t*e)/2+this.ox,
ty:(this.height-r*e)/2+this.oy}}mosaicViewport(t,r){if(!this.bitmap)return null
;let e=this.view(),a=this.pxScale,o=Math.max(0,Math.floor(-e.tx/e.k*a)),n=Math.max(0,Math.floor(-e.ty/e.k*a)),i=Math.min(t,Math.ceil((this.width-e.tx)/e.k*a)),s=Math.min(r,Math.ceil((this.height-e.ty)/e.k*a))
;return{k:e.k/a,rect:[o,n,i,s]}}static bitmapOf(t,r,e){let a=new Image(r,e,3,ColorSpace.RGB);for(let o=0;o<3;++o)a.setSamples(t[o],new Rect(0,0,r,e),o)
;let o=a.render();return a.free(),o}setImage(t,r,e,a,o){this.bitmap=Kt.bitmapOf(t,r,e),this.pxScale=a,o||(this.zoom=1,this.ox=this.oy=0,this.detail=null),
this.update()}setDetail(t,r,e,a,o,n){this.detail=t?{bitmap:Kt.bitmapOf(t,r,e),x0:a,y0:o,s:n}:null,this.update()}}function _t(t,r,e,a,o,n,i,s){
let h=new NumericControl(t);return h.label.text=r,h.label.setScaledFixedWidth(130),h.setRange(e,a),h.setPrecision(o),h.slider.setRange(0,n),
h.slider.setScaledMinWidth(160),h.setValue(i),h.toolTip=s,h}class Yt extends Dialog{constructor(){super(),this.ctx=null,this.pv=null,this.sliding=!1,
this.info="",this.strokes=[],this.edit=null,this.lastKey={key:0,t:0},this.helpLabel=new Label(this),this.helpLabel.frameStyle=FrameStyle.Box,
this.helpLabel.margin=6,this.helpLabel.wordWrapping=!0,this.helpLabel.useRichText=!0,
this.helpLabel.text="<b>"+Rt+" v"+Gt+"</b> &mdash; tick the <i>linear</i> panels of the mosaic (colour or one mono filter) and press <i>Build mosaic</i>. Every panel keeps its own signal-to-noise ratio; the grain of a noisier panel fades gradually into its neighbours, bright parts of stars / galaxies are protected from the added noise. Zoom into the preview to check the result, adjust the sliders, then <i>Create image</i> (the image appears behind this dialog).",
this.tree=new TreeBox(this),this.tree.numberOfColumns=5,this.tree.headerVisible=!0,this.tree.setHeaderText(0,"Panel"),this.tree.setHeaderText(1,"Noise"),
this.tree.setHeaderText(2,"Size"),this.tree.setHeaderText(3,"Channels"),this.tree.setHeaderText(4,"Astrometry"),this.tree.rootDecoration=!1,
this.tree.alternateRowColor=!0,this.tree.setScaledMinSize(420,160);for(let t of ImageWindow.openWindows){if(t.isNull||!t.visible&&!t.iconic)continue
;let r=t.mainView;if(r.isNull||0===r.id.indexOf("AutoPano"))continue;let e=new TreeBoxNode(this.tree);e.checkable=!0,e.checked=!0,e.setText(0,r.id),
e.setText(2,r.image.width+" x "+r.image.height),e.setText(3,r.image.isColor?"RGB":"Gray"),e.setText(4,t.hasAstrometricSolution?"solved":"will be solved"),
e.viewId=r.id}for(let t=0;t<5;++t)this.tree.adjustColumnWidthToContents(t);this.allButton=new PushButton(this),this.allButton.text="Select all",
this.allButton.onClick=()=>this.setAll(!0),this.noneButton=new PushButton(this),this.noneButton.text="Select none",this.noneButton.onClick=()=>this.setAll(!1),
this.listButtons=new HorizontalSizer,this.listButtons.spacing=6,this.listButtons.add(this.allButton),this.listButtons.add(this.noneButton),
this.listButtons.addStretch(),this.editButton=new PushButton(this),this.editButton.enabled=!1,this.editButton.onClick=()=>{
this.edit?this.leaveEdit(!1):this.enterEdit()},this.editButtonMode(!1),this.listButtons.add(this.editButton),this.gxCheck=new CheckBox(this),
this.gxCheck.text="Use GraXpert (strong gradients only)",
this.gxCheck.toolTip="<p>Run GraXpert background extraction (subtraction) on every panel before building. Only for strong or complex gradients (light pollution domes, Moon): AutoPano's own background matching handles normal gradients better, and GraXpert alone may leave blotches, which AutoPano then evens out across the panels. Needs GraXpert installed (as for PixInsight's GraXpert script). AutoPano suggests it when it sees such gradients. Applies to the next Build.</p>",
this.gxSizer=new HorizontalSizer,this.gxSizer.add(this.gxCheck),this.gxSizer.addStretch(),this.tree.onCurrentNodeUpdated=()=>{
if(!this.edit||!this.tree.currentNode)return;let t=this.ctx.names.indexOf(this.tree.currentNode.viewId);t>=0&&t!==this.edit.active&&(this.edit.active=t,
this.showActive(),this.redraw(!0))
},this.blendControl=_t(this,"Noise transition:",.25,3,2,275,1,"<p>Width of the gradual noise transition around a noisier panel, relative to the automatic width (1.00 = auto: wider for a bigger noise difference). Larger = gentler change of the grain, but more of the cleaner neighbours gets extra noise.</p>"),
this.strengthControl=_t(this,"Object protection:",0,3,2,300,1,"<p>How much the bright parts of stars and galaxies are spared the added noise. Protection follows the screen stretch: only where the missing grain stays invisible (bright cores), so faint halos and outskirts get the same grain as the sky around them. Higher = more protection (and fainter objects detected); 0 = off.</p>"),
this.featherControl=_t(this,"Mask softness (px):",2,60,0,58,12,"<p>Feather of the object mask edges, px.</p>")
;for(let t of[this.blendControl,this.strengthControl,this.featherControl])t.slider.onMousePress=()=>{this.sliding=!0},t.slider.onMouseRelease=()=>{
this.sliding=!1,this.slidersChanged()},t.onValueUpdated=()=>{this.sliding||this.slidersChanged()};this.maskCheck=new CheckBox(this),
this.maskCheck.text="Object mask (red)",this.maskCheck.toolTip="<p>Overlay the object protection on the preview: red = no added noise.</p>",
this.maskCheck.onCheck=()=>this.redraw(!0),this.noiseCheck=new CheckBox(this),this.noiseCheck.text="Noise map",
this.noiseCheck.toolTip="<p>Overlay the final noise level relative to the cleanest panel (log scale): dark blue = as the cleanest panel .. yellow = as the noisiest. Shows how the grain of a noisier panel fades into its neighbours (Noise transition).</p>",
this.noiseCheck.onCheck=()=>this.redraw(!0),this.seamCheck=new CheckBox(this),this.seamCheck.text="Seam map",
this.seamCheck.toolTip="<p>Which panel gives which part of the mosaic: each area is tinted in its panel colour (the colour squares in the panel list) and labelled with the panel and its noise relative to the cleanest panel. Solid light lines = seams; dashed lines = where each panel really ends, i.e. how much spare image a panel has beyond its seam.</p>",
this.seamCheck.onCheck=()=>this.redraw(!0),this.showLabel=new Label(this),this.showLabel.text="Show:",
this.showLabel.textAlignment=TextAlignment.Right|TextAlignment.VertCenter,this.showLabel.setScaledFixedWidth(130),this.checkSizer=new HorizontalSizer,
this.checkSizer.spacing=12,this.checkSizer.add(this.showLabel),this.checkSizer.add(this.maskCheck),this.checkSizer.add(this.noiseCheck),
this.checkSizer.add(this.seamCheck),this.cropCheck=new CheckBox(this),this.cropCheck.text="Crop to the filled area",
this.cropCheck.toolTip="<p>Cut the mosaic to the largest rectangle without empty corners (the frame on the preview). The mosaic is always built at the angle that makes this rectangle largest - the panels are resampled only once, and the astrometric solution stays exact.</p>",
this.cropCheck.onCheck=()=>this.redraw(!0),this.cropSizer=new HorizontalSizer,this.cropSizer.addScaledSpacing(134),this.cropSizer.add(this.cropCheck),
this.cropSizer.addStretch(),this.checkSizer.addStretch(),this.infoLabel=new Label(this),this.infoLabel.wordWrapping=!0,this.infoLabel.setScaledMinHeight(48),
this.infoLabel.text="",this.noiseGroup=new GroupBox(this),this.noiseGroup.title="Noise and seams",this.noiseGroup.sizer=new VerticalSizer,
this.noiseGroup.sizer.margin=6,this.noiseGroup.sizer.spacing=4,this.noiseGroup.sizer.add(this.blendControl),this.noiseGroup.sizer.add(this.strengthControl),
this.noiseGroup.sizer.add(this.featherControl),this.noiseGroup.sizer.add(this.checkSizer),this.noiseGroup.sizer.add(this.cropSizer),
this.qualityLabel=new Label(this),this.qualityLabel.text="Preview quality:",this.qualityLabel.textAlignment=TextAlignment.Right|TextAlignment.VertCenter,
this.qualityLabel.setScaledFixedWidth(130),this.qualityCombo=new ComboBox(this)
;for(let t of["Full (1:1)","Half (1:2)","Quarter (1:4)","Eighth (1:8)"])this.qualityCombo.addItem(t);this.qualityCombo.currentItem=2,
this.qualityCombo.toolTip="<p>Resolution of the preview, as in video editors: the preview always shows the final result (with the added noise), reduced to this quality. Lower = faster slider updates. The object mask is also computed at this resolution: Half and Full give exactly the mask of the final image, Quarter / Eighth a close approximation (the final image always uses the exact one).</p>",
this.qualityCombo.onItemSelected=()=>this.recompute(),this.qualitySizer=new HorizontalSizer,this.qualitySizer.spacing=4,
this.qualitySizer.add(this.qualityLabel),this.qualitySizer.add(this.qualityCombo),this.qualitySizer.addStretch(),this.noiseGroup.sizer.add(this.qualitySizer),
this.noiseGroup.sizer.add(this.infoLabel),this.activeLabel=new Label(this),this.activeLabel.useRichText=!0,this.activeLabel.text="",
this.sizeControl=_t(this,"Brush size (px):",20,2e3,0,1980,300,"<p>Brush radius in mosaic pixels.</p>"),
this.sizeControl.onValueUpdated=()=>this.preview.update(),this.editHelp=new Label(this),this.editHelp.useRichText=!0,this.editHelp.wordWrapping=!0,
this.editHelp.text="<p>Pick the panel in the list or <b>Ctrl+click</b> it on the preview, then paint where this panel should be used (e.g. over a galaxy): the seams go around your strokes through the background. <b>Alt</b>+paint: erase strokes. <b>Ctrl+Z</b> / <b>Ctrl+Shift+Z</b>: undo / redo. Wheel: zoom; right or middle button (or Space) + drag: pan. Dimmed = the active panel has no data there.</p>",
this.undoButton=new PushButton(this),this.undoButton.text="Undo",this.undoButton.onClick=()=>this.undo(),this.redoButton=new PushButton(this),
this.redoButton.text="Redo",this.redoButton.onClick=()=>this.redo(),this.clearButton=new PushButton(this),this.clearButton.text="Clear panel",
this.clearButton.toolTip="<p>Remove the strokes of the active panel (other panels keep theirs).</p>",this.clearButton.onClick=()=>{this.edit&&this.addAction({
clear:this.edit.active})},this.applyButton=new PushButton(this),this.applyButton.text="Apply",this.applyButton.icon=this.scaledResource(":/icons/ok.png"),
this.applyButton.toolTip="<p>Re-blend the mosaic with the edited seams, recompute the noise and leave seam editing.</p>",
this.applyButton.onClick=()=>this.leaveEdit(!0),this.editButtons=new HorizontalSizer,this.editButtons.spacing=6,this.editButtons.add(this.undoButton),
this.editButtons.add(this.redoButton),this.editButtons.add(this.clearButton),this.editButtons.addStretch(),this.editButtons.add(this.applyButton),
this.editInfo=new Label(this),this.editInfo.wordWrapping=!0,this.editInfo.text="",this.editGroup=new GroupBox(this),this.editGroup.title="Seam editing",
this.editGroup.sizer=new VerticalSizer,this.editGroup.sizer.margin=6,this.editGroup.sizer.spacing=6,this.editGroup.sizer.add(this.activeLabel),
this.editGroup.sizer.add(this.sizeControl),this.editGroup.sizer.add(this.editHelp),this.editGroup.sizer.add(this.editButtons),
this.editGroup.sizer.add(this.editInfo),this.editGroup.visible=!1,this.preview=new Kt(this),this.preview.onKeyPress=(t,r)=>this.editKey(t,r),
this.onKeyPress=(t,r)=>this.editKey(t,r),this.preview.onViewChanged=()=>this.updateDetail(),this.buildButton=new PushButton(this),
this.buildButton.text="Build mosaic",this.buildButton.icon=this.scaledResource(":/icons/ok.png"),
this.buildButton.toolTip="<p>Analyse the ticked panels (geometry, photometry, seams, noise) and show the preview.</p>",
this.buildButton.onClick=()=>this.build(),this.imageButton=new PushButton(this),this.imageButton.text="Create image",
this.imageButton.icon=this.scaledResource(":/icons/add.png"),
this.imageButton.toolTip="<p>Create the mosaic image with the current settings (no rebuild). It opens behind this dialog; settings can be changed and another image created.</p>",
this.imageButton.enabled=!1,this.imageButton.onClick=()=>this.makeImage(),this.closeButton=new PushButton(this),this.closeButton.text="Close",
this.closeButton.icon=this.scaledResource(":/icons/close.png"),this.closeButton.onClick=()=>this.cancel(),this.heartLabel=new Label(this),
this.heartLabel.useRichText=!0,this.heartLabel.text='<span style="color:#e0245e; font-size:15pt;">&#9829;</span>',
this.heartLabel.toolTip="<p>Like AutoPano? Support its development with a donation (PayPal or card).</p>",
this.heartLabel.cursor=new Cursor(StdCursor.PointingHand),this.heartLabel.onMousePress=()=>(new Xt).execute(),this.buttons=new HorizontalSizer,
this.buttons.spacing=6,this.buttons.add(this.heartLabel),this.buttons.addStretch(),this.buttons.add(this.buildButton),this.buttons.add(this.imageButton),
this.buttons.add(this.closeButton),this.leftSizer=new VerticalSizer,this.leftSizer.spacing=6,this.leftSizer.add(this.helpLabel),
this.leftSizer.add(this.tree,100),this.leftSizer.add(this.listButtons),this.leftSizer.add(this.gxSizer),this.leftSizer.add(this.noiseGroup),
this.leftSizer.add(this.editGroup),this.mainSizer=new HorizontalSizer,this.mainSizer.spacing=8,this.mainSizer.add(this.leftSizer,40),
this.mainSizer.add(this.preview,100),this.sizer=new VerticalSizer,this.sizer.margin=8,this.sizer.spacing=6,this.sizer.add(this.mainSizer,100),
this.sizer.add(this.buttons),this.loadSettings(),this.windowTitle=Rt+" v"+Gt,this.adjustToContents(),this.setScaledMinSize(1100,700)}settingsList(){
return[["blend",DataType.Double,this.blendControl],["maskStrength",DataType.Double,this.strengthControl],["maskFeather",DataType.Double,this.featherControl],["brushSize",DataType.Double,this.sizeControl],["showMask",DataType.Boolean,this.maskCheck],["showNoise",DataType.Boolean,this.noiseCheck],["showSeams",DataType.Boolean,this.seamCheck],["quality",DataType.Int32,this.qualityCombo],["crop",DataType.Boolean,this.cropCheck],["graxpert",DataType.Boolean,this.gxCheck]]
}loadSettings(){for(let[t,r,e]of this.settingsList()){let a=Settings.read(qt+"/"+t,r)
;Settings.lastReadOK&&null!=a&&(r===DataType.Boolean?e.checked=a:r===DataType.Int32?a>=0&&a<e.numberOfItems&&(e.currentItem=a):e.setValue(a))}}saveSettings(){
for(let[t,r,e]of this.settingsList())Settings.write(qt+"/"+t,r,r===DataType.Boolean?e.checked:r===DataType.Int32?e.currentItem:e.value)}setAll(t){
for(let r=0;r<this.tree.numberOfChildren;++r)this.tree.child(r).checked=t}selectedWindows(){let t=[];for(let r=0;r<this.tree.numberOfChildren;++r){
let e=this.tree.child(r);if(!e.checked)continue;let a=View.viewById(e.viewId);a&&!a.isNull&&t.push(a.window)}return t}options(){return{
blend:this.blendControl.value,maskStrength:this.strengthControl.value,maskFeather:this.featherControl.value,crop:this.cropCheck.checked}}quality(){
return[1,2,4,8][this.qualityCombo.currentItem]}seamMap(t){if(!this.ctx)return null;let r=this.edit;return r?{colors:this.ctx.colors,lw:t,label:r.draft,
forced:r.forced,active:r.active}:this.seamCheck.checked?{colors:this.ctx.colors,lw:t}:null}showPanels(){
let t=this.ctx,r=Math.min.apply(null,t.sig),e=Math.round(12*this.displayPixelRatio);for(let a=0;a<this.tree.numberOfChildren;++a){
let o=this.tree.child(a),n=t.names.indexOf(o.viewId);if(n<0){let r=new Bitmap(e,e);r.fill(0),o.setIcon(0,r),
o.setText(1,t.excluded.some(t=>t.id===o.viewId)?"left out":"");continue}let i=new Bitmap(e,e);i.fill(t.argb[n]),o.setIcon(0,i),
o.setText(1,format("%.2fx",t.sig[n]/r))}for(let t=0;t<5;++t)this.tree.adjustColumnWidthToContents(t)}busy(t,r){
this.cursor=new Cursor(t?StdCursor.Wait:StdCursor.Arrow),t&&r&&(this.infoLabel.text=r),CoreApplication.processEvents()}slidersChanged(){this.recompute()}
recompute(){if(!this.ctx||!this.pv)return;let t=this.ctx,r=this.pv,e=this.options(),a=this.quality(),o=Math.max(2,a);this.busy(!0,"Updating the preview...")
;let n=new ElapsedTime;try{r.tg=yt(t.S,t.sig,e),t.mcache[o]||(t.mcache[o]={}),r.prot=At(t.S,r.tg,t.sig,{maskStrength:e.maskStrength,maskFeather:e.maskFeather,
cache:t.mcache[o]},o);let a=St(t.S,r.tg,t.spectra,r.prot,{cache:t.NC,out:t.R});t.R=a.chans;let i=0;for(let r=1;r<t.sig.length;++r)t.sig[r]>t.sig[i]&&(i=r)
;this.info=format("Transition around the noisiest panel (%s, %.2fx the cleanest): %.0f px. Protected: %.1f%% of the mosaic fully, %.1f%% partly (mask at 1:%d). Updated in %.1f s.",t.names[i],t.sig[i]/Math.min.apply(null,t.sig),r.tg.widths[i],100*r.prot.full,100*r.prot.part,o,n.value),
this.redraw(!0)}catch(t){console.criticalln(t.toString())}finally{this.busy(!1)}}redraw(t){if(!this.ctx||!this.pv||!this.ctx.R)return
;let r=this.ctx,e=this.pv,a=Math.max(e.b,this.quality()),o=r.S,n=Math.floor(o.W/a),i=Math.floor(o.H/a),s=Math.max(1,Math.round(1/Math.min(this.preview.width/n,this.preview.height/i))),h=It(o,r.R,[0,0,n*a,i*a],a,e.stf,this.maskCheck.checked?e.prot:null,this.noiseCheck.checked?e.tg:null,r.sig,this.seamMap(s)),l=Math.min.apply(null,r.sig)
;this.preview.cropRect=this.cropCheck.checked&&!this.edit?r.crop:null,
this.preview.labels=this.seamCheck.checked||this.edit?(this.edit?this.edit.labels:r.labels).map(t=>({x:t.x,y:t.y,color:r.argb[t.k],
text:r.names[t.k]+"  "+format("%.2fx",r.sig[t.k]/l)})):null,this.preview.setImage(h.rgb,h.w,h.h,a,t),this.updateDetail()}updateDetail(){
if(!this.ctx||!this.pv||!this.ctx.R)return
;let t=this.ctx,r=this.pv,e=this.preview.mosaicViewport(t.S.W,t.S.H),a=this.quality(),o=Math.max(r.b,a),n=e?Math.max(a,Math.min(o,Math.floor(1/e.k)||1)):o
;if(!e||n>=o)return this.preview.setDetail(null),void(this.infoLabel.text=this.info);let i=e.rect.slice();if(i[0]=Math.floor(i[0]/n)*n,
i[1]=Math.floor(i[1]/n)*n,i[2]=i[0]+Math.floor((i[2]-i[0])/n)*n,i[3]=i[1]+Math.floor((i[3]-i[1])/n)*n,!(i[2]-i[0]<2*n||i[3]-i[1]<2*n))try{
let e=It(t.S,t.R,i,n,r.stf,this.maskCheck.checked?r.prot:null,this.noiseCheck.checked?r.tg:null,t.sig,this.seamMap(1))
;this.preview.setDetail(e.rgb,e.w,e.h,i[0],i[1],n),this.infoLabel.text=this.info+" View 1:"+n+"."}catch(t){console.criticalln(t.toString())}}editButtonMode(t){
let r=this.editButton;r.text=t?"Cancel":"Edit seams",r.icon=this.scaledResource(t?":/icons/cancel.png":":/icons/brush.png"),
r.toolTip=t?"<p>Leave seam editing without applying the changes made since entering it.</p>":"<p>Seam editing: choose with a brush which panel gives which part of the mosaic. Seams around your strokes are routed automatically through the background; Apply re-blends the mosaic.</p>"
}enterEdit(){if(!this.ctx||this.edit)return;let t=this.ctx,r=0;this.tree.currentNode&&(r=Math.max(0,t.names.indexOf(this.tree.currentNode.viewId))),this.edit={
strokes:this.strokes.slice(),redo:null,active:r,draft:null,forced:null,labels:t.labels},this.preview.editor={radius:()=>this.sizeControl.value,
color:()=>t.argb[this.edit.active],pick:(t,r)=>this.pickPanel(t,r),strokeDone:t=>this.addAction({k:this.edit.active,r:this.sizeControl.value,erase:t.erase,
pts:t.pts})},this.noiseGroup.visible=!1,this.editGroup.visible=!0,this.editButtonMode(!0),this.buildButton.enabled=this.imageButton.enabled=!1,
this.showActive(),this.recut()}leaveEdit(t){let r=this.edit,e=this.ctx;if(!r)return;if(!t)return this.closeEdit(),void this.redraw(!0)
;this.busy(!0,"Re-blending the mosaic...");let a=null;try{let t=new ElapsedTime,o=r.draft||Tt(e.S,Pt(e.S,r.strokes));if(a=function(t,r){
for(var e=J,a=e.G,o=1<<e.levels,n=t.cells.Wc,i=t.cells.Hc,s=t.cells.label,h=n,l=i,f=-1,u=-1,c=0,d=0;d<i;d++)for(var p=0;p<n;p++)s[B=d*n+p]!==r[B]&&(c++,
p<h&&(h=p),p>f&&(f=p),d<l&&(l=d),d>u&&(u=d));if(!c)return null;t.cells.label=new Int32Array(r);var v=[h*a,l*a,Math.min((f+1)*a,t.W),Math.min((u+1)*a,t.H)]
;dt(t,r,v)
;for(var m=n*a,w=i*a,g=e.blendPad,y=[Math.max(v[0]-g,0),Math.max(v[1]-g,0),Math.min(v[2]+g,t.W),Math.min(v[3]+g,t.H)],x=[Math.max(Math.floor((y[0]-g)/o)*o,0),Math.max(Math.floor((y[1]-g)/o)*o,0),Math.min(Math.ceil((y[2]+g)/o)*o,m),Math.min(Math.ceil((y[3]+g)/o)*o,w)],M=pt(t,x,void 0),b=x[2]-x[0],A=0;A<t.nc;A++)for(var k=t.chans[A],F=M[A],S=y[1];S<y[3];S++)for(var C=y[0];C<y[2];C++){
var B;k[B=S*t.W+C]=t.union[B]?F[(S-x[1])*b+C-x[0]]:0}return{rect:y,win:x,changed:c}}(e.S,o),this.strokes=r.strokes,a){e.labels=zt(e.S),e.mcache={}
;let o=format("Seam edits: %d brush action(s), %d label cells changed, re-blended %d x %d px in %.1f s",r.strokes.length,a.changed,a.win[2]-a.win[0],a.win[3]-a.win[1],t.value)
;console.writeln(o)}}catch(t){console.criticalln(t.toString())}finally{this.busy(!1)}this.closeEdit(),a?this.recompute():this.redraw(!0)}closeEdit(){
this.edit=null,this.preview.editor=null,this.preview.stroke=null,this.preview.cursorPos=null,this.editGroup.visible=!1,this.noiseGroup.visible=!0,
this.editButtonMode(!1),this.buildButton.enabled=!0,this.imageButton.enabled=null!==this.ctx}showActive(){let t=this.edit,r=this.ctx;if(!t)return
;let e=16777215&r.argb[t.active]
;this.activeLabel.text="Active panel: <span style='color:#"+(16777216+e).toString(16).slice(1)+"; font-size:14pt;'>&#9632;</span> <b>"+r.names[t.active]+"</b>"
;for(let e=0;e<this.tree.numberOfChildren;++e){let a=this.tree.child(e);a.viewId===r.names[t.active]&&this.tree.currentNode!==a&&(this.tree.currentNode=a)}}
pickPanel(t,r){let e=this.edit,a=this.ctx.S;if(t=Math.floor(t),r=Math.floor(r),!e||t<0||r<0||t>=a.W||r>=a.H)return
;let o=r*a.W+t,n=J.G,i=e.draft?ct(a,e.draft[Math.floor(r/n)*a.cells.Wc+Math.floor(t/n)],a.cov[o]):a.labf[o];i<0||i===e.active||(e.active=i,this.showActive(),
this.redraw(!0))}addAction(t){this.edit&&(this.edit.strokes.push(t),this.edit.redo=null,this.recut())}undo(){let t=this.edit
;t&&t.strokes.length&&(t.redo=t.strokes.pop(),this.recut())}redo(){let t=this.edit;t&&t.redo&&(t.strokes.push(t.redo),t.redo=null,this.recut())}recut(){
let t=this.edit,r=this.ctx.S;if(t){this.busy(!0);try{let e=new ElapsedTime;t.forced=Pt(r,t.strokes),t.draft=Tt(r,t.forced),t.labels=zt(r,t.draft)
;let a=0,o=0,n=r.cells.label;for(let r=0;r<t.forced.length;++r)t.forced[r]>=0&&++a,t.draft[r]!==n[r]&&++o
;this.editInfo.text=format("%d action(s); %.1f%% of the mosaic painted; seams moved over %.1f%% (%.1f s). Apply to re-blend.",t.strokes.length,100*a/t.forced.length,100*o/t.forced.length,e.value),
this.undoButton.enabled=t.strokes.length>0,this.redoButton.enabled=null!==t.redo,this.redraw(!0)}catch(t){console.criticalln(t.toString())}finally{this.busy(!1)
}}}editKey(t,r){if(!this.edit)return!1;let e=Date.now();if(t===this.lastKey.key&&e-this.lastKey.t<40)return!0;let a=!0
;return t===KeyCode.Z&&r&KeyModifier.Control?r&KeyModifier.Shift?this.redo():this.undo():a=!1,a&&(this.lastKey={key:t,t:e},this.preview.update()),a}run(t){
this.enabled=!1,console.show(),console.abortEnabled=!0;try{t()}catch(t){console.criticalln(t.toString()),
t instanceof jt||new MessageBox(t.toString(),Rt,StdIcon.Error,StdButton.Ok).execute()}finally{console.abortEnabled=!1,this.enabled=!0,
this.imageButton.enabled=this.editButton.enabled=null!==this.ctx}}build(){let t=this.selectedWindows();this.run(()=>{
console.noteln("<end><cbr><br>"+Rt+" v"+Gt+": "+t.length+" panel(s)"),this.edit&&this.closeEdit(),this.ctx=null,this.pv=null,this.strokes=[];let r=Ot(t,{
graxpert:this.gxCheck.checked});r.NC={tiles:{},bytes:0,kern:{},kept:1},r.R=null,r.mcache={},r.colors=function(t){
for(var r=[[1,.35,.3],[.25,.85,1],[1,.85,.2],[.85,.4,1],[.35,1,.4],[.35,.5,1],[1,.6,.15],[1,.45,.75],[.6,1,.85],[.75,.75,.4]],e=[],a=0;a<t;a++)if(a<r.length)e.push(r[a]);else{
var o=.618034*a%1*6,n=Math.floor(o),i=o-n,s=.3,h=1-.7*i,l=.3+.7*i;e.push([[1,l,s],[h,1,s],[s,1,l],[s,h,1],[l,s,1],[1,s,h]][n%6])}return e}(r.names.length),
r.argb=r.colors.map(t=>(4278190080|Math.round(255*t[0])<<16|Math.round(255*t[1])<<8|Math.round(255*t[2]))>>>0),r.labels=zt(r.S);let e=(a=r.S,
Math.max(2,Math.round(Math.max(a.W,a.H)/1800)));var a;this.ctx=r,this.showPanels(),
r.gxSuggest&&new MessageBox("<p>Strong or complex background gradients were detected. If seams or blotches remain visible, tick <i>Use GraXpert</i> and build again.</p>",Rt,StdIcon.Information,StdButton.Ok).execute(),
r.excluded.length&&new MessageBox("<p>The mosaic was built from "+r.names.length+" panels. Left out:</p><ul>"+r.excluded.map(t=>"<li><b>"+t.id+"</b>: "+t.reason+"</li>").join("")+"</ul>",Rt,StdIcon.Warning,StdButton.Ok).execute(),
this.pv={b:e,stf:Ct(r.S,e).stf,tg:null,prot:null},console.noteln("Preview: noise synthesis (once; then sliders only rescale it)"),this.recompute(),
this.preview.zoom=1,
this.preview.ox=this.preview.oy=0,this.redraw(!0),console.noteln("Zoom into the preview to check the result; Create image makes the mosaic.")})}makeImage(){
this.ctx&&this.run(()=>{let t=function(t,r){let a=new ElapsedTime,o=t=>{console.writeln(format("%7.1f s  ",a.value)+t),Dt()},n=t.S,i=n.nc,s=yt(n,t.sig,r)
;console.noteln("<end><cbr>Noise transition x"+format("%.2f",r.blend)+", object detection "+format("%.2f",r.maskStrength)+", mask softness "+format("%.0f",r.maskFeather)+" px"),
console.writeln(format("Noise transition x%.2f, object protection %.2f, mask softness %.0f px",r.blend,r.maskStrength,r.maskFeather)),
console.writeln("Transition width per panel (px): "+t.names.map((t,r)=>t+" "+s.widths[r].toFixed(0)).join(", ")),t.mcache[2]||(t.mcache[2]={})
;let l=function(t,r,e,a){return At(t,r,e,a,2)}(n,s,t.sig,{maskStrength:r.maskStrength,maskFeather:r.maskFeather,cache:t.mcache[2]})
;o(format("object protection: %.1f%% of the mosaic fully protected, %.1f%% partly",100*l.full,100*l.part));let f=St(n,s,t.spectra,l,{log:o,cache:t.NC});l=null,
o("noise added ("+f.tiles+" tiles)");for(let r of function(t,r,a){
for(var o=t.W,n=t.H,i=h(r,o,n),s=tt(i,o,n,6),l=rt(i,o,n,1),f=["Result noise per region (luminance, robust): sigma px, sigma 3x3 bin, ratio 3x3/px"],u=0;u<a.length;u++){
for(var c=[],d=[],p=0;p<o*n;p+=3)t.labf[p]===u&&(c.push(i[p]-s[p]),d.push(l[p]-s[p]));if(!(c.length<3e3)){var v=e(c).sigma,m=e(d).sigma
;f.push("  "+T(a[u],10)+" "+v.toExponential(3)+"  "+m.toExponential(3)+"  "+(m/v).toFixed(3))}}return f}(n,f.chans,t.names))console.writeln(r)
;let u=r.crop?t.crop:[0,0,n.W,n.H],c=u[2]-u[0],d=u[3]-u[1],p=new ImageWindow(c,d,i,32,!0,t.isColor,"AutoPano"),v=p.mainView;v.beginProcess(UndoFlag.NoSwapFile)
;try{for(let t=0;t<i;++t){let e=f.chans[t];if(r.crop){let t=new Float32Array(c*d);for(let r=0;r<d;++r)t.set(e.subarray((u[1]+r)*n.W+u[0],(u[1]+r)*n.W+u[2]),r*c)
;e=t}v.image.setSamples(e,new Rect(0,0,c,d),t)}}finally{v.endProcess()}
r.crop&&console.writeln(format("Cropped to the filled area: x %d..%d, y %d..%d (%d x %d px, %.1f%% of the canvas)",u[0],u[2],u[1],u[3],c,d,100*c*d/(n.W*n.H)))
;let m=[];for(let e of r.crop?function(t,r,e){return t.map(function(t){return"CRPIX1"===t[0]?[t[0],t[1]-e[0],t[2]]:"CRPIX2"===t[0]?[t[0],t[1]-(r-e[3]),t[2]]:t})
}(t.wcs,n.H,u):t.wcs)m.push(new FITSKeyword(e[0],String(e[1]),e[2]))
;m.push(new FITSKeyword("HISTORY","",format("AutoPano %s: %d panels, seams + multiband blend",Gt,t.nPanels))),
m.push(new FITSKeyword("HISTORY","",format("AutoPano noise transition x%.2f, object detection %.2f, mask softness %.0f px",r.blend,r.maskStrength,r.maskFeather))),
p.keywords=m;try{p.regenerateAstrometricSolution()}catch(t){console.warningln("** could not attach the astrometric solution: "+t.toString())}return p.show(),
p.zoomToFit(),console.noteln(format("<end><cbr>AutoPano: %s (%d x %d px) in %.1f s",v.id,c,d,a.value)),p}(this.ctx,this.options())
;this.infoLabel.text=this.info+" Created "+t.mainView.id+" (behind this dialog)."})}}!function(){if(console.hide(),
ImageWindow.openWindows.length<2)return void new MessageBox("Open the panel masters first (at least two).",Rt,StdIcon.Information,StdButton.Ok).execute()
;let t=new Yt;t.execute(),t.saveSettings()}()}();
