#engine v8
// AutoPano 1.0.3 for PixInsight - Copyright (c) 2026 BananAndrews. All rights reserved.
// Free to use. Modification, reverse engineering and redistribution of modified versions are not permitted.
#feature-id    AutoPano : Utilities > AutoPano
#feature-info  One-button mosaic of linear (unstretched) panels.<br/>\
   Plate-solves the panels if needed, refines their positions on the stars of \
   all overlaps at once, reprojects them, matches their photometry, joins them \
   along seams through the sky with multiband blending and makes the noise \
   change between panels gradual.
#define USE_SOLVER_LIBRARY true
#define SETTINGS_MODULE "AutoPanoSolver"
#include "../ImageSolver/ImageSolver.js"
#undef TITLE
#undef VERSION
!function(){function t(t,r,e){for(var a=0,o=r-1;o>a;){for(var i=t[a+o>>1],n=a,s=o;n<=s;){for(;t[n]<i;)n++;for(;t[s]>i;)s--;if(n<=s){var h=t[n];t[n]=t[s],t[s]=h,
n++,s--}}if(e<=s)o=s;else{if(!(e>=n))return t[e];a=n}}return t[e]}function r(r,e){if(void 0===e&&(e=r.length),e<=0)return NaN
;for(var a=new Float64Array(e),o=0;o<e;o++)a[o]=r[o];var i=t(a,e,e>>1);if(1&e)return i;var n=-1/0;for(o=0;o<e>>1;o++)a[o]>n&&(n=a[o]);return.5*(n+i)}
function e(t,e){void 0===e&&(e=t.length);for(var a=r(t,e),o=new Float64Array(e),i=0;i<e;i++)o[i]=Math.abs(t[i]-a);return{med:a,sigma:1.4826*r(o,e)}}
function a(t,r,e){e=e||1;for(var a=0,o=t.length,i=0;i<o;i+=e)r&&!r[i]||a++;var n=new Float64Array(a),s=0;for(i=0;i<o;i+=e)r&&!r[i]||(n[s++]=t[i]);return n}
function o(t,r){return Math.sqrt(t*t+r*r)}function i(t){for(var r=[],e=0;e<t;e++)r.push(0);return r}function n(t,r,e){
for(var a=e.length===r&&"number"==typeof e[0]?[e]:e,o=0;o<r;o++){for(var i=t[o*r+o],n=0;n<o;n++)i-=t[o*r+n]*t[o*r+n];var s=i>1e-300?Math.sqrt(i):1e-150
;t[o*r+o]=s;for(var h=o+1;h<r;h++){var l=t[h*r+o];for(n=0;n<o;n++)l-=t[h*r+n]*t[o*r+n];t[h*r+o]=l/s}}for(var f=0;f<a.length;f++){var u=a[f];for(h=0;h<r;h++){
for(l=u[h],n=0;n<h;n++)l-=t[h*r+n]*u[n];u[h]=l/t[h*r+h]}for(h=r-1;h>=0;h--){for(l=u[h],n=h+1;n<r;n++)l-=t[n*r+h]*u[n];u[h]=l/t[h*r+h]}}return e}function s(t,r){
this.n=t,this.nrhs=r||1,this.M=new Float64Array(t*t),this.v=[];for(var e=0;e<this.nrhs;e++)this.v.push(new Float64Array(t))}function h(t,r,e){
for(var a=r*e,o=t.length,i=new Float32Array(a),n=0;n<o;n++)for(var s=t[n],h=0;h<a;h++)i[h]+=s[h];if(o>1)for(h=0;h<a;h++)i[h]/=o;return i}function l(t,r,e,a){
for(var o=Math.floor(r/a),i=Math.floor(e/a),n=new Float32Array(o*i),s=1/(a*a),h=0;h<i;h++)for(var l=0;l<a;l++)for(var f=(h*a+l)*r,u=h*o,c=0;c<o;c++){
for(var d=0,p=f+c*a,v=0;v<a;v++)d+=t[p+v];n[u+c]+=d}for(var m=0;m<n.length;m++)n[m]*=s;return{data:n,w:o,h:i}}function f(t,r,e,a,o){
for(var i=new Float32Array(a*o),n=r/a,s=e/o,h=new Int32Array(a),l=new Int32Array(a),f=new Float32Array(a),u=0;u<a;u++){
var c=Math.min(Math.max((u+.5)*n-.5,0),r-1),d=Math.floor(c);h[u]=d,l[u]=Math.min(d+1,r-1),f[u]=c-d}for(var p=0;p<o;p++){
var v=Math.min(Math.max((p+.5)*s-.5,0),e-1),m=Math.floor(v),w=v-m,g=m*r,y=Math.min(m+1,e-1)*r,x=p*a;for(u=0;u<a;u++){
var M=t[g+h[u]]+f[u]*(t[g+l[u]]-t[g+h[u]]),b=t[y+h[u]]+f[u]*(t[y+l[u]]-t[y+h[u]]);i[x+u]=M+w*(b-M)}}return i}function u(r,e,a,o){
var i=o>>1,n=new Float32Array(e*a),s=new Float64Array(o*o);function h(t,r){for(;t<0||t>=r;)t=t<0?-t-1:2*r-t-1;return t}for(var l=0;l<a;l++)for(var f=0;f<e;f++){
for(var u=0,c=-i;c<=i;c++)for(var d=h(l+c,a)*e,p=-i;p<=i;p++)s[u++]=r[d+h(f+p,e)];n[l*e+f]=t(s,u,u>>1)}return n}function c(t,r,e,a){return function(t,r,e,a){
var o=a.length-1>>1,i=new Float32Array(r*e),n=new Float32Array(r*e),s=new Float64Array(r+2*o),h=new Float64Array(r);function l(t,r){if(1===r)return 0
;for(;t<0||t>=r;)t=t<0?-t:2*r-2-t;return t}for(var f=0;f<e;f++){for(var u=f*r,c=-o;c<r+o;c++)s[c+o]=t[u+l(c,r)];for(var d=0;d<r;d++){
for(var p=0,v=0;v<a.length;v++)p+=a[v]*s[d+v];i[u+d]=p}}for(f=0;f<e;f++){for(d=0;d<r;d++)h[d]=0;for(v=0;v<a.length;v++){var m=a[v],w=l(f+v-o,e)*r
;for(d=0;d<r;d++)h[d]+=m*i[w+d]}for(u=f*r,d=0;d<r;d++)n[u+d]=h[d]}return n}(t,r,e,function(t){
for(var r=Math.max(1,Math.round(4*t)),e=new Float64Array(2*r+1),a=0,o=-r;o<=r;o++)e[o+r]=Math.exp(-o*o/(2*t*t)),a+=e[o+r];for(o=0;o<e.length;o++)e[o]/=a
;return e}(a))}function d(t,r,e){for(var a=new Int32Array(r*e),o=0;o<e;o++)for(var i=0;i<r;i++)if(t[h=o*r+i]){var n=i>0?a[h-1]:0,s=o>0?a[h-r]:0
;a[h]=Math.min(n,s)+1}else a[h]=0;for(o=e-1;o>=0;o--)for(i=r-1;i>=0;i--){var h;if(a[h=o*r+i]){n=i<r-1?a[h+1]:0,s=o<e-1?a[h+r]:0;var l=Math.min(n,s)+1
;l<a[h]&&(a[h]=l)}}return a}CoreApplication.ensureMinimumVersion(1,9,5),s.prototype.add=function(t,r,e){for(var a=this.n,o=this.M,i=0;i<a;i++){var n=t[i]
;if(0!==n){for(var s=e*n,h=i*a,l=0;l<a;l++)o[h+l]+=s*t[l];for(var f=0;f<this.nrhs;f++)this.v[f][i]+=s*r[f]}}},s.prototype.solve=function(t){
for(var r=this.n,e=new Float64Array(this.M),a=[],o=0;o<r;o++)e[o*r+o]+=t||0;for(var i=0;i<this.nrhs;i++)a.push(new Float64Array(this.v[i]));return n(e,r,a),a}
;function p(t,r){var e=t*Math.PI/180,a=r*Math.PI/180;return[Math.cos(a)*Math.cos(e),Math.cos(a)*Math.sin(e),Math.sin(a)]}function v(t){
var r=Math.atan2(t[1],t[0]),e=Math.asin(Math.max(-1,Math.min(1,t[2])));this.ra0=180*r/Math.PI,this.ra0<0&&(this.ra0+=360),this.dec0=180*e/Math.PI,this.t=t,
this.e=[-Math.sin(r),Math.cos(r),0],this.n=[-Math.sin(e)*Math.cos(r),-Math.sin(e)*Math.sin(r),Math.cos(e)]}function m(t,r){var e=t*t,a=e*t;r[0]=.5*(2*e-a-t),
r[1]=.5*(3*a-5*e+2),r[2]=.5*(-3*a+4*e+t),r[3]=.5*(a-e)}function w(t,r,e,a,o,i,n,s,h){var l=Math.floor(o),f=Math.floor(i);l<1?l=1:l>e-3&&(l=e-3),
f<1?f=1:f>a-3&&(f=a-3),m(o-l,s),m(i-f,h);for(var u=0,c=0,d=0;d<4;d++){for(var p=(f-1+d)*e+l-1,v=0,w=0,g=0;g<4;g++)v+=s[g]*t[p+g],w+=s[g]*r[p+g];u+=h[d]*v,
c+=h[d]*w}return n[0]=u,n[1]=c,n}function g(t,r,e){var a=t.grid;this.step=a.step,this.nx=a.nx,this.ny=a.ny,this.cx=r,this.cy=e,this.wx=new Float64Array(4),
this.wy=new Float64Array(4),this.tmp=[0,0]
;var o=(t.w-1)/2,i=(t.h-1)/2,n=this.fwd(o+8,i),s=this.fwd(o-8,i),h=this.fwd(o,i+8),l=this.fwd(o,i-8),f=(n[0]-s[0])/16,u=(n[1]-s[1])/16,c=(h[0]-l[0])/16,d=(h[1]-l[1])/16,p=f*d-c*u
;this.k11=d/p,this.k12=-c/p,this.k21=-u/p,this.k22=f/p,this.centre=this.fwd(o,i),this.xc=o,this.yc=i}function y(t,r,e){for(var a=[],o=0;o<e;o++){var i=o/e
;a.push([i*(t-1),0]),a.push([t-1,i*(r-1)]),a.push([(1-i)*(t-1),r-1]),a.push([0,(1-i)*(r-1)])}return a}function x(t){var r=t[0],e=-t[1],a=t[2],o=-t[3];return{
rot:180*Math.atan2(a,o)/Math.PI,parity:r*o-e*a<0?-1:1}}function M(t,r,e){this.c0=t,this.s=r,this.order=e,this.nb=[1,3,6,10][e],
this.cx=new Float64Array(this.nb),this.cy=new Float64Array(this.nb),this.phiBuf=new Float64Array(this.nb)}function b(t,e,a,o,i,n){function s(t,e,a){
for(var s=Math.min(n,a),h=Math.floor(e/10),l=e-Math.floor(e/10)-h,f=new Uint8Array(l),u=0;u<l;u++){for(var c=1,d=i;d<s&&c;d++)0===t(d,h+u)&&(c=0);f[u]=c}
var p=new Float64Array(s),v=new Float64Array(s),m=new Uint8Array(s),w=new Float64Array(l),g=new Float64Array(l);for(d=0;d<s;d++){var y=0,x=1;for(u=0;u<l;u++){
var M=t(d,h+u);0===M&&(x=0),f[u]&&(w[y++]=M)}m[d]=x;for(var b=0;b+1<y;b++)g[b]=w[b+1]-w[b];var A=r(g,y-1);for(b=0;b+1<y;b++)g[b]=Math.abs(g[b]-A)
;p[d]=1.4826*r(g,y-1)/Math.SQRT2,v[d]=r(w,y)}var k=r(p.subarray(i,s),s-i),F=0,S=0,C=0,B=0,I=s-i;for(d=i;d<s;d++)F+=d,S+=v[d],C+=d*d,B+=d*v[d]
;var P=(I*B-F*S)/(I*C-F*F),z=(S-P*F)/I;for(c=new Uint8Array(s),d=0;d<s;d++)c[d]=p[d]<1.1*k&&Math.abs(v[d]-(P*d+z))<.3*k&&m[d]?1:0;var T=o;for(d=0;d<o;d++){
for(var W=1,R=d;R<d+5;R++)if(!c[R]){W=0;break}if(W){T=d;break}}return T?T+2:0}return o=o||200,i=i||250,n=n||400,{top:s(function(r,a){return t[r*e+a]},e,a),
bottom:s(function(r,o){return t[(a-1-r)*e+o]},e,a),left:s(function(r,a){return t[a*e+r]},a,e),right:s(function(r,a){return t[a*e+(e-1-r)]},a,e)}}
function A(t,o,i,n){n=n||4e3
;for(var s=o*i,h=l(t,o,i,16),p=f(u(h.data,h.w,h.h,9),h.w,h.h,o,i),v=new Float32Array(s),m=new Uint8Array(s),w=0;w<s;w++)v[w]=t[w]-p[w],m[w]=t[w]>0?1:0
;for(var g=e(a(v,m,3)).sigma,y=c(v,o,i,1.2),x=e(a(y,m,3)).sigma,M=r(a(p,m,7)),b=d(m,o,i),A=6*x,k=[],F=5;F<i-5;F++)for(var S=5;S<o-5;S++)if(!(!((N=y[w=F*o+S])>A)||b[w]<=16||t[w]>.9||p[w]-M>=20*g)){
for(var C=!0,B=-5;B<=5&&C;B++)for(var I=w+B*o,P=-5;P<=5;P++)if(y[I+P]>N){C=!1;break}C&&k.push(w)}k.sort(function(t,r){return y[r]-y[t]}),
k.length>n&&(k.length=n);for(var z=13,T=new Float64Array(169),W={x:[],y:[],flux:[]},R=new Float64Array(52),G=0;G<k.length;G++){var j=k[G],q=j%o,L=(j-q)/o
;if(!(L<6||q<6||L>=i-6||q>=o-6)){for(var D=0;D<z;D++)for(w=0;w<z;w++)T[D*z+w]=v[(L-6+D)*o+q-6+w];var H=0;for(w=0;w<z;w++)R[H++]=T[w],R[H++]=T[156+w],
R[H++]=T[w*z],R[H++]=T[w*z+z-1];for(var E=r(R,H),V=0,U=0;U<169;U++){var N=T[U]-E;T[U]=N>0?N:0,V+=T[U]}if(!(V<=0)){var O=0,X=0
;for(D=0;D<z;D++)for(w=0;w<z;w++)O+=T[D*z+w]*(w-6),X+=T[D*z+w]*(D-6);O/=V,X/=V;var _=0,K=0;for(D=0;D<z;D++)for(w=0;w<z;w++){var Y=T[D*z+w];_+=Y*(w-6-O)*(w-6-O),
K+=Y*(D-6-X)*(D-6-X)}K/=V;var Z=(_/=V)/Math.max(K,1e-6);if(Z>.4&&Z<2.5){for(var J=!0,Q=0;Q<10;Q++){var $=0,tt=0,rt=0;for(D=0;D<z;D++)for(w=0;w<z;w++){
var et=w-6,at=D-6,ot=Math.exp(-((et-O)*(et-O)+(at-X)*(at-X))/4.5)*T[D*z+w];$+=ot,tt+=ot*et,rt+=ot*at}if($<=0){J=!1;break}tt/=$,rt/=$
;var it=Math.abs(tt-O)+Math.abs(rt-X)<.001;if(O=tt,X=rt,it)break}!J||Math.abs(O)>2||Math.abs(X)>2||(W.x.push(q+O),W.y.push(L+X),W.flux.push(V))}}}}return W}
function k(t,e){for(var a=t.length,i=0,n=0,s=0,h=new Float64Array(a),l=0;l<a;l++)i+=t[l],n+=e[l],h[l]=o(t[l],e[l]),s+=h[l]*h[l];return{n:a,dx:i/a,dy:n/a,
rms:Math.sqrt(s/a),med:r(h,a)}}function F(t,r){for(var e=0,a=t.length;e<a;){var o=e+a>>1;t[o]<r?e=o+1:a=o}return e/Math.max(t.length,1)}function S(t,r,e,a,i,n){
var s=t.stars[e],h=t.stars[a];function l(e,a){for(var o=t.maps[a],i=r[a],n=[],s=0;s<e.qx.length;s++){var h=o.inv(e.qx[s],e.qy[s])
;h[0]>20&&h[1]>20&&h[0]<i.w-20&&h[1]<i.h-20&&n.push(s)}return n}var f=l(s,a),u=l(h,e);if(f.length<5||u.length<5)return null;function c(t,r,e){
for(var a=new Float64Array(r.length),o=new Float64Array(r.length),i=0;i<r.length;i++){var s=n?n[e].apply(t.qx[r[i]],t.qy[r[i]]):[t.qx[r[i]],t.qy[r[i]]]
;a[i]=s[0],o[i]=s[1]}return{x:a,y:o}}for(var d=c(s,f,e),p=c(h,u,a),v=i,m={},w=0;w<u.length;w++){var g=Math.floor(p.x[w]/v)+","+Math.floor(p.y[w]/v)
;(m[g]||(m[g]=[])).push(w)}var y=new Int32Array(f.length);for(w=0;w<f.length;w++){
for(var x=Math.floor(d.x[w]/v),M=Math.floor(d.y[w]/v),b=-1,A=i,k=-1;k<=1;k++)for(var S=-1;S<=1;S++){var C=m[x+S+","+(M+k)];if(C)for(var B=0;B<C.length;B++){
var I=o(p.x[C[B]]-d.x[w],p.y[C[B]]-d.y[w]);I<A&&(A=I,b=C[B])}}y[w]=b}var P={},z=[],T=[];for(w=0;w<f.length;w++)y[w]<0||P[y[w]]||(P[y[w]]=1,z.push(f[w]),
T.push(u[y[w]]));if(z.length<5)return null;var W={ax:[],ay:[],bx:[],by:[],bright:[]};for(w=0;w<z.length;w++)W.ax.push(s.qx[z[w]]),W.ay.push(s.qy[z[w]]),
W.bx.push(h.qx[T[w]]),W.by.push(h.qy[T[w]]),W.bright.push(Math.min(F(s.sorted,s.flux[z[w]]),F(h.sorted,h.flux[T[w]])));return W}function C(t,r,e,a,i){
for(var n=r.length,h=[],l=0;l<n;l++)h.push(new M(t.maps[l].centre,Math.max(r[l].w,r[l].h)/2,i));var f=h[0].nb,u={},c=0;for(l=0;l<n;l++)l!==a&&(u[l]=c++*f)
;var d=c*f,p=[];for(var v in e)p.push(v);for(var m={},w=0;w<p.length;w++){for(var g=e[p[w]],y=new Uint8Array(g.ax.length),x=0;x<y.length;x++)y[x]=1;m[p[w]]=y}
for(var b=new Float64Array(d),A=new Float64Array(f),k=new Float64Array(f),F=0;F<6;F++){var S=new s(d,2),C=0;for(w=0;w<p.length;w++){g=e[p[w]]
;var B=+(j=p[w].split(","))[0],I=+j[1];for(y=m[p[w]],x=0;x<g.ax.length;x++)if(y[x]){for(var P=0;P<d;P++)b[P]=0;if(void 0!==u[B])for(h[B].phi(g.ax[x],g.ay[x],A),
P=0;P<f;P++)b[u[B]+P]+=A[P];if(void 0!==u[I])for(h[I].phi(g.bx[x],g.by[x],k),P=0;P<f;P++)b[u[I]+P]-=k[P];var z=.1+g.bright[x]*g.bright[x]
;S.add(b,[g.bx[x]-g.ax[x],g.by[x]-g.ay[x]],z),C++}}var T=S.solve(.001*C);for(l=0;l<n;l++)if(void 0!==u[l])for(P=0;P<f;P++)h[l].cx[P]=T[0][u[l]+P],
h[l].cy[P]=T[1][u[l]+P];var W={},R=0,G=0;for(w=0;w<p.length;w++){g=e[p[w]],B=+(j=p[w].split(","))[0],I=+j[1];var j,q=new Float64Array(g.ax.length)
;for(x=0;x<g.ax.length;x++){var L=h[B].apply(g.ax[x],g.ay[x]),D=h[I].apply(g.bx[x],g.by[x]);q[x]=o(D[0]-L[0],D[1]-L[1]),m[p[w]][x]&&(R+=q[x]*q[x],G++)}W[p[w]]=q
}var H=Math.max(3*Math.sqrt(R/Math.max(G,1)),.5);for(w=0;w<p.length;w++)for(q=W[p[w]],y=m[p[w]],x=0;x<q.length;x++)y[x]=q[x]<H?1:0}return h}function B(t,r,e){
for(var a=t.w,o=t.h,i=a*o,n=new Uint8Array(i),s=0;s<i;s++)n[s]=1;for(var h=0;h<t.chans.length;h++){var l=t.chans[h];for(s=0;s<i;s++)0===l[s]&&(n[s]=0)}
for(var f=0;f<o;f++)for(var u=0;u<a;u++)(f<r.top||f>=o-r.bottom||u<r.left||u>=a-r.right)&&(n[f*a+u]=0);var c=d(n,a,o);for(s=0;s<i;s++)n[s]=c[s]>e?1:0;return n}
function I(t,r,e,a,o){for(var i=t.maps[e],n=t.corrs?t.corrs[e]:null,s=t.W,h=t.H,l=y(r.w,r.h,64),f=1/0,u=1/0,c=-1/0,d=-1/0,p=0;p<l.length;p++){
var v=i.fwd(l[p][0],l[p][1]);n&&(v=n.apply(v[0],v[1])),v[0]<f&&(f=v[0]),v[0]>c&&(c=v[0]),v[1]<u&&(u=v[1]),v[1]>d&&(d=v[1])}
for(var m=Math.max(Math.floor(f)-1,0),w=Math.max(Math.floor(u)-1,0),g=Math.min(Math.ceil(c)+2,s),x=Math.min(Math.ceil(d)+2,h),M=g-m,b=x-w,A=16,k=Math.ceil((M-1)/A)+4,F=Math.ceil((b-1)/A)+4,S=new Float64Array(k*F),C=new Float64Array(k*F),B=null,I=0;I<F;I++)for(B=null,
p=0;p<k;p++){var P=m+(p-1)*A,z=w+(I-1)*A;n&&(P=(j=n.invert(P,z))[0],z=j[1]);var T=i.inv(P,z,B);S[I*k+p]=T[0],C[I*k+p]=T[1],B=T}
for(var W=r.chans.length,R=[],G=new Uint8Array(M*b),j=0;j<W;j++)R.push(new Float32Array(M*b));for(var q=function(t){var r=new Float32Array(6150);function e(t){
if(0===t)return 1;if(Math.abs(t)>=3)return 0;var r=Math.PI*t;return 3*Math.sin(r)*Math.sin(r/3)/(r*r)}for(var a=0;a<=t;a++){for(var o=a/t,i=0,n=0;n<6;n++){
var s=e(o-(n-2));r[6*a+n]=s,i+=s}for(n=0;n<6;n++)r[6*a+n]/=i}return r}(1024),L=r.w,D=r.h,H=0;H<b;H++){!o||255&H||o(H/b)
;for(var E=H/A+1,V=Math.floor(E),U=E-V,N=0;N<M;N++){
var O=N/A+1,X=Math.floor(O),_=O-X,K=V*k+X,Y=K+k,Z=S[K]+_*(S[K+1]-S[K]),J=S[Y]+_*(S[Y+1]-S[Y]),Q=C[K]+_*(C[K+1]-C[K]),$=Z+U*(J-Z),tt=Q+U*(C[Y]+_*(C[Y+1]-C[Y])-Q),rt=Math.floor($+.5),et=Math.floor(tt+.5)
;if(!(rt<0||et<0||rt>=L||et>=D)&&a[et*L+rt]){var at=Math.floor($),ot=Math.floor(tt);if(!(at<2||ot<2||at>L-4||ot>D-4)){
var it=6*Math.round(1024*($-at)),nt=6*Math.round(1024*(tt-ot)),st=H*M+N,ht=q[it],lt=q[it+1],ft=q[it+2],ut=q[it+3],ct=q[it+4],dt=q[it+5];for(G[st]=1,
j=0;j<W;j++){
for(var pt=r.chans[j],vt=(ot-2)*L+at-2,mt=0,wt=0;wt<6;wt++,vt+=L)mt+=q[nt+wt]*(ht*pt[vt]+lt*pt[vt+1]+ft*pt[vt+2]+ut*pt[vt+3]+ct*pt[vt+4]+dt*pt[vt+5])
;var gt=ot*L+at,yt=pt[gt],xt=pt[gt+1],Mt=pt[gt+L],bt=pt[gt+L+1],At=yt<xt?yt:xt,kt=yt<xt?xt:yt;Mt<At?At=Mt:Mt>kt&&(kt=Mt),bt<At?At=bt:bt>kt&&(kt=bt),
mt=mt<At?At:mt>kt?kt:mt,R[j][st]=mt<0?0:mt>1?1:mt}}}}}return{box:[m,w,g,x],w:M,h:b,chans:R,mask:G}}function P(t,e){
for(var a=(e=e||{}).log||function(){},i=t.length,n=void 0===e.order?2:e.order,s=0,l=1;l<i;l++)t[l].noise<t[s].noise&&(s=l);var f=function(t,r,e){
for(var a=t.length,o=[],i=[0,0,0],n=0;n<a;n++){for(var s=t[n].grid,h=[],l=0;l<s.nx*s.ny;l++)h.push(p(s.ra[l],s.dec[l]));o.push(h)
;var f=h[Math.floor(s.ny/2)*s.nx+Math.floor(s.nx/2)];i[0]+=f[0],i[1]+=f[1],i[2]+=f[2]}
var u=Math.sqrt(i[0]*i[0]+i[1]*i[1]+i[2]*i[2]),c=new v([i[0]/u,i[1]/u,i[2]/u]),d=[],m=[];for(n=0;n<a;n++){h=o[n]
;var w=new Float64Array(h.length),x=new Float64Array(h.length);for(l=0;l<h.length;l++){var M=c.project(h[l]);w[l]=M[0],x[l]=M[1]}d.push(w),m.push(x)}
var b=[],A=[];for(n=0;n<a;n++){var k=new g(t[n],d[n],m[n]),F=((M=t[n]).w-1)/2,S=(M.h-1)/2,C=k.fwd(F+16,S),B=k.fwd(F-16,S),I=(f=k.fwd(F,S+16),
k.fwd(F,S-16)),P=[(C[0]-B[0])/32,(f[0]-I[0])/32,(C[1]-B[1])/32,(f[1]-I[1])/32];b.push(P),A.push(Math.sqrt(Math.abs(P[0]*P[3]-P[1]*P[2])))}var z=A[0]
;for(n=1;n<a;n++)A[n]<z&&(z=A[n]);var T=b[r],W=A[r],R=(P=[T[0]/W*z,T[1]/W*z,T[2]/W*z,T[3]/W*z])[0]*P[3]-P[1]*P[2],G=[P[3]/R,-P[1]/R,-P[2]/R,P[0]/R],j=null
;if(e&&e.cropAngle){var q=[];for(n=0;n<a;n++){w=d[n],x=m[n];var L=new Float64Array(w.length),D=new Float64Array(w.length)
;for(l=0;l<w.length;l++)L[l]=G[0]*w[l]+G[1]*x[l],D[l]=G[2]*w[l]+G[3]*x[l];k=new g(t[n],L,D);var H=.015*(M=t[n]).w,E=.015*M.h
;q.push([k.fwd(H,E),k.fwd(M.w-1-H,E),k.fwd(M.w-1-H,M.h-1-E),k.fwd(H,M.h-1-E)])}j=function(t){function r(r){
for(var e=r*Math.PI/180,a=Math.cos(e),o=Math.sin(e),i=[],n=1/0,s=1/0,h=-1/0,l=-1/0,f=0;f<t.length;f++){for(var u=[],c=0;c<4;c++){
var d=a*t[f][c][0]-o*t[f][c][1],p=o*t[f][c][0]+a*t[f][c][1];u.push([d,p]),d<n&&(n=d),d>h&&(h=d),p<s&&(s=p),p>l&&(l=p)}
(u[1][0]-u[0][0])*(u[2][1]-u[0][1])-(u[1][1]-u[0][1])*(u[2][0]-u[0][0])<0&&u.reverse(),i.push(u)}
var v=300/Math.max(h-n,l-s),m=Math.ceil((h-n)*v)+1,w=Math.ceil((l-s)*v)+1,g=new Uint8Array(m*w);for(f=0;f<i.length;f++){u=i[f];var y=m,x=w,M=0,b=0
;for(c=0;c<4;c++)y=Math.min(y,Math.floor((u[c][0]-n)*v)),M=Math.max(M,Math.ceil((u[c][0]-n)*v)),x=Math.min(x,Math.floor((u[c][1]-s)*v)),
b=Math.max(b,Math.ceil((u[c][1]-s)*v));for(var A=Math.max(x,0);A<Math.min(b,w);A++)for(var k=Math.max(y,0);k<Math.min(M,m);k++){
var F=n+(k+.5)/v,S=s+(A+.5)/v,C=!0;for(c=0;c<4&&C;c++){var B=u[c],I=u[(c+1)%4];(I[0]-B[0])*(S-B[1])-(I[1]-B[1])*(F-B[0])<0&&(C=!1)}C&&(g[A*m+k]=1)}}var P=Rt({
W:m,H:w,union:g});return(P[2]-P[0])*(P[3]-P[1])/(v*v)}for(var e=r(0),a=0,o=e,i=1;i<90;i++)(n=r(i))>o&&(o=n,a=i);for(i=a-1;i<=a+1.001;i+=.1){var n
;(n=r(i))>o&&(o=n,a=i)}return o<1.01*e?{angle:0,gain:1}:{angle:(a=Math.round(10*a)/10)>45?a-90:a,gain:o/e}}(q);var V=j.angle*Math.PI/180,U=(f=Math.cos(V),
Math.sin(V));G=[f*G[0]-U*G[2],f*G[1]-U*G[3],U*G[0]+f*G[2],U*G[1]+f*G[3]],P=[P[0]*f-P[1]*U,P[0]*U+P[1]*f,P[2]*f-P[3]*U,P[2]*U+P[3]*f]}
var N=[],O=[],X=1/0,_=1/0,K=-1/0,Y=-1/0;for(n=0;n<a;n++){for(w=d[n],x=m[n],L=new Float64Array(w.length),D=new Float64Array(w.length),
l=0;l<w.length;l++)L[l]=G[0]*w[l]+G[1]*x[l],D[l]=G[2]*w[l]+G[3]*x[l];N.push(L),O.push(D),k=new g(t[n],L,D);var Z=y(t[n].w,t[n].h,64);for(l=0;l<Z.length;l++){
var J=k.fwd(Z[l][0],Z[l][1]);J[0]<X&&(X=J[0]),J[0]>K&&(K=J[0]),J[1]<_&&(_=J[1]),J[1]>Y&&(Y=J[1])}}
var Q=Math.floor(X)-2,$=Math.floor(_)-2,tt=Math.ceil(K-Q)+3,rt=Math.ceil(Y-$)+3,et=[];for(n=0;n<a;n++){for(L=N[n],D=O[n],l=0;l<L.length;l++)L[l]-=Q,D[l]-=$
;et.push(new g(t[n],L,D))}return{W:tt,H:rt,tangent:c,J:P,origin:[Q,$],maps:et,crop:j,scaleArcsec:180*z/Math.PI*3600,panelScales:A,panelJac:b}}(t,s,{
cropAngle:e.crop}),u={W:f.W,H:f.H,ref:s,canvas:f,maps:f.maps,corrs:null,stars:[],report:[]},c=u.report
;for(c.push("Panels: "+i+", reference (lowest noise): "+t[s].id),
c.push("Projection TAN at RA "+f.tangent.ra0.toFixed(4)+" Dec "+f.tangent.dec0.toFixed(4)+", scale "+f.scaleArcsec.toFixed(4)+'"/px, canvas '+f.W+" x "+f.H+" px"),
f.crop&&c.push(f.crop.angle?"Canvas rotated by "+f.crop.angle.toFixed(1)+" deg from the reference orientation for the largest crop (+"+(100*(f.crop.gain-1)).toFixed(0)+"% area vs no rotation)":"Crop: the reference orientation is already the best"),
a("canvas "+f.W+"x"+f.H+", reference "+t[s].id),
u.trims=[],c.push(""),c.push('panel        rot,deg   scale" parity      noise  edge trim px (top/bottom/left/right)  stars'),l=0;l<i;l++){
var d=t[l],m=h(d.chans,d.w,d.h),w=Date.now();u.trims.push(b(m,d.w,d.h));var M=A(m,d.w,d.h);m=null;for(var F=[],B=[],I=0;I<M.x.length;I++){
var R=f.maps[l].fwd(M.x[I],M.y[I]);F.push(R[0]),B.push(R[1])}var G=M.flux.slice(0).sort(function(t,r){return t-r});u.stars.push({qx:F,qy:B,px:M.x,py:M.y,
flux:M.flux,sorted:G});var j=x(f.panelJac[l]),q=u.trims[l]
;c.push(T(d.id,10)+" "+W(j.rot.toFixed(2),8)+" "+W((648e3*f.panelScales[l]/Math.PI).toFixed(4),8)+" "+W(String(j.parity),6)+" "+W(d.noise.toExponential(3),10)+"  "+T(q.top+"/"+q.bottom+"/"+q.left+"/"+q.right,36)+" "+M.x.length),
a("  "+d.id+": "+M.x.length+" stars ("+((Date.now()-w)/1e3).toFixed(1)+" s)")}function L(r,e){for(var a={},o=0;o<i;o++)for(var n=o+1;n<i;n++){
var s=S(u,t,o,n,r,e);s&&(a[o+","+n]=s)}return a}function D(t,r,e){for(var a=r.split(","),o=+a[0],i=+a[1],n=[],s=[],h=0;h<t.ax.length;h++){
var l=e?e[o].apply(t.ax[h],t.ay[h]):[t.ax[h],t.ay[h]],f=e?e[i].apply(t.bx[h],t.by[h]):[t.bx[h],t.by[h]];n.push(f[0]-l[0]),s.push(f[1]-l[1])}return{dx:n,dy:s}}
var H=L(3,null),E={},V=function(t,r){for(var e=[],a=0;a<t;a++)e.push(a);function o(t){for(;e[t]!==t;)t=e[t]=e[e[t]];return t}for(var i in r){var n=i.split(",")
;e[o(+n[0])]=o(+n[1])}var s={},h=[];for(a=0;a<t;a++){var l=o(a);(s[l]||(s[l]=h[h.push([])-1])).push(a)}return h}(i,H);if(V.length>1){V.sort(function(t,r){
return r.length-t.length||(t.indexOf(s)>=0?-1:r.indexOf(s)>=0?1:0)});var U=V[0],N=[];for(l=0;l<i;l++)if(!(U.length>1&&U.indexOf(l)>=0)){var O=[]
;for(I=0;I<i;I++)I!==l&&z(u,t,l,I)>.005&&O.push(t[I].id);N.push({id:t[l].id,
reason:O.length?"overlaps "+O.join(", ")+" but no common stars were found there (overlap too small, too few stars, or a wrong plate solution)":"does not overlap any other panel"
})}if(U.length<2)throw new Error("No two panels could be joined by common stars: "+N.map(function(t){return t.id+" "+t.reason}).join("; ")+".")
;for(I=0;I<N.length;I++)a("** "+N[I].id+" left out: "+N[I].reason);var X=P(U.map(function(r){return t[r]}),e);return X.used=X.used.map(function(t){return U[t]
}),X.excluded=N.concat(X.excluded),X.report.unshift("Left out (not linked to the mosaic): "+N.map(function(t){return t.id+" - "+t.reason}).join("; "),""),X}
for(u.used=[],l=0;l<i;l++)u.used.push(l);for(var _ in u.excluded=[],H){var K=D(H[_],_,null);E[_]=k(K.dx,K.dy)}var Y=null;if(n>=0){Y=C(u,t,H,s,n)
;for(var Z=0;Z<2;Z++)H=L(1.5,Y),Y=C(u,t,H,s,n)}for(u.corrs=Y,l=0;l<i;l++){var J=u.stars[l];for(J.x=[],J.y=[],
I=0;I<J.qx.length;I++)R=Y?Y[l].apply(J.qx[I],J.qy[I]):[J.qx[I],J.qy[I]],J.x.push(R[0]),J.y.push(R[1])}var Q=[],$=[];for(var _ in u.pairs=[],H){
var tt=H[_],rt=D(tt,_,Y),et=(M=k(rt.dx,rt.dy),[]),at=[];for(R=0;R<tt.ax.length;R++)Q.push(o(rt.dx[R],rt.dy[R])),$.push(tt.bright[R]),
tt.bright[R]>=.5&&(et.push(rt.dx[R]),at.push(rt.dy[R]));var ot=et.length>=3?k(et,at):null,it=_.split(",");u.pairs.push({i:+it[0],j:+it[1],before:E[_]||null,
after:M,bright:ot,check:ot?ot.med:M.med})}c.push(""),c.push("Residual vs star brightness (all pairs"+(Y?", refined":"")+"):")
;for(var nt=[[0,.5],[.5,.8],[.8,1.01]],st=0;st<3;st++){var ht=[];for(R=0;R<Q.length;R++)$[R]>=nt[st][0]&&$[R]<nt[st][1]&&ht.push(Q[R]);if(ht.length){var lt=0
;for(R=0;R<ht.length;R++)lt+=ht[R]*ht[R]
;c.push("  flux rank "+nt[st][0].toFixed(1)+"-"+Math.min(nt[st][1],1).toFixed(1)+": n="+W(String(ht.length),4)+"  median "+r(ht).toFixed(3)+" px  rms "+Math.sqrt(lt/ht.length).toFixed(3)+" px")
}}c.push(""),c.push("Star pairs (canvas px). before = plate solutions only, after = refined; check = median of the brighter half:"),
c.push(T("pair",22)+"    n  before |    n   after     rms |  nbr  check");var ft=null;for(I=0;I<u.pairs.length;I++){
var ut=(pt=u.pairs[I]).before,ct=pt.check>.3?"  <-- above 0.3 px":""
;c.push(T(t[pt.i].id+"-"+t[pt.j].id,22)+" "+W(ut?String(ut.n):"-",4)+" "+W(ut?ut.med.toFixed(3):"-",7)+" | "+W(String(pt.after.n),4)+" "+W(pt.after.med.toFixed(3),7)+" "+W(pt.after.rms.toFixed(3),7)+" | "+W(pt.bright?String(pt.bright.n):"-",4)+" "+W(pt.check.toFixed(3),6)+ct),
(!ft||pt.check>ft.check)&&(ft=pt)}
ft&&(u.worstCheck=ft.check,c.push("Worst pair: "+t[ft.i].id+"-"+t[ft.j].id+" (check "+ft.check.toFixed(3)+" px)"+(ft.check>.3?"  - ABOVE TARGET":""))),
c.push(""),c.push("Overlap of the joined pairs (share of the smaller panel area):");var dt=1;for(I=0;I<u.pairs.length;I++){var pt=u.pairs[I]
;O=Math.max(z(u,t,pt.i,pt.j),z(u,t,pt.j,pt.i)),pt.overlap=O,c.push("  "+T(t[pt.i].id+"-"+t[pt.j].id,22)+" "+W((100*O).toFixed(0),3)+"%"),
O>.03&&(dt=Math.min(dt,O))}
if(u.minOverlap=dt,dt<.15&&c.push("Advice: the smallest real overlap is "+(100*dt).toFixed(0)+"%. Plan "+15..toFixed(0)+"% or more next time (e.g. in MosaicPlanner): wider overlaps give the seams more room around objects and a better photometric match."),
Y)for(c.push(""),c.push("Star refinement: polynomial order "+n+" per panel, reference fixed. Correction at centre / max over the border (px):"),l=0;l<i;l++){
for(var vt=y(t[l].w,t[l].h,16),mt=0,wt=0;wt<vt.length;wt++){R=f.maps[l].fwd(vt[wt][0],vt[wt][1]);var gt=Y[l].apply(R[0],R[1])
;mt=Math.max(mt,o(gt[0]-R[0],gt[1]-R[1]))}c.push("  "+T(t[l].id,10)+" "+o(Y[l].cx[0],Y[l].cy[0]).toFixed(3)+" / "+mt.toFixed(3))}return u}function z(t,r,e,a){
for(var o=r[e],i=r[a],n=0,s=0;s<17;s++)for(var h=0;h<17;h++){var l=t.maps[e].fwd(s*(o.w-1)/16,h*(o.h-1)/16),f=t.maps[a].inv(l[0],l[1])
;f[0]>=0&&f[1]>=0&&f[0]<=i.w-1&&f[1]<=i.h-1&&n++}return n/289}function T(t,r){for(t=String(t);t.length<r;)t+=" ";return t}function W(t,r){
for(t=String(t);t.length<r;)t=" "+t;return t}function R(t){var r=t.canvas,e=r.J,a=180/Math.PI
;return[["CTYPE1","'RA---TAN'","Gnomonic projection"],["CTYPE2","'DEC--TAN'","Gnomonic projection"],["CRVAL1",r.tangent.ra0,"RA of the tangent point (deg)"],["CRVAL2",r.tangent.dec0,"Dec of the tangent point (deg)"],["CRPIX1",1-r.origin[0],"Tangent point, x (1-based)"],["CRPIX2",t.H+r.origin[1],"Tangent point, y (1-based, y up)"],["CD1_1",e[0]*a,""],["CD1_2",-e[1]*a,""],["CD2_1",e[2]*a,""],["CD2_2",-e[3]*a,""],["RADESYS","'ICRS'",""],["EQUINOX",2e3,""]]
}function G(t,r,e){var a=(e=e||{}).triStars||45,i=e.scoreStars||250,n=e.tol||3,s=e.scale||1,h=e.minMatch||10;function l(t,r){
for(var e=[],a=0;a<t.x.length;a++)e.push(a);e.sort(function(r,e){return t.flux[e]-t.flux[r]}),e.length>r&&(e.length=r);var o=[],i=[]
;for(a=0;a<e.length;a++)o.push(t.x[e[a]]),i.push(t.y[e[a]]);return{x:o,y:i}}var f=l(t,a),u=l(r,a),c=l(t,i),d=l(r,i);if(f.x.length<4||u.x.length<4)return null
;function p(t,r){for(var e=[],a=t.x.length,i=0;i<a;i++)for(var n=i+1;n<a;n++)for(var s=n+1;s<a;s++){
var h=[i,n,s],l=[o(t.x[n]-t.x[s],t.y[n]-t.y[s]),o(t.x[i]-t.x[s],t.y[i]-t.y[s]),o(t.x[i]-t.x[n],t.y[i]-t.y[n])],f=[0,1,2].sort(function(t,r){return l[t]-l[r]
}),u=l[f[0]]*r,c=l[f[1]]*r,d=l[f[2]]*r;u<40||u/d<.15||e.push({s0:u,s1:c,s2:d,v:[h[f[0]],h[f[1]],h[f[2]]]})}return e}
for(var v=p(f,1),m=p(u,s),w={},g=0;g<m.length;g++){var y=Math.round(m[g].s2/4)+","+Math.round(m[g].s1/4);(w[y]||(w[y]=[])).push(g)}
for(var x={},M=0;M<c.x.length;M++){var b=Math.floor(c.x[M]/8)+","+Math.floor(c.y[M]/8);(x[b]||(x[b]=[])).push(M)}function A(t,r){
for(var e=Math.floor(t/8),a=Math.floor(r/8),i=-1,s=n,h=-1;h<=1;h++)for(var l=-1;l<=1;l++){var f=x[e+l+","+(a+h)];if(f)for(var u=0;u<f.length;u++){
var d=o(c.x[f[u]]-t,c.y[f[u]]-r);d<s&&(s=d,i=f[u])}}return{i,d:s}}function k(t,r){for(var e=0,a=0,o={},i=0;i<d.x.length;i++){
var n=A(t.a*d.x[i]+t.b*d.y[i]+t.tx,t.c*d.x[i]+t.d*d.y[i]+t.ty);n.i>=0&&!o[n.i]&&(o[n.i]=1,e++,a+=n.d*n.d,r&&r.push([i,n.i]))}return{n:e,rms:e?Math.sqrt(a/e):0}}
function F(t,r,e,a,i){for(var n=t.length,s=0,h=0,l=0,f=0,u=i?-1:1,c=0;c<n;c++)s+=t[c],h+=u*r[c],l+=e[c],f+=a[c];s/=n,h/=n,l/=n,f/=n;var d=0,p=0,v=0
;for(c=0;c<n;c++){var m=t[c]-s,w=u*r[c]-h,g=e[c]-l,y=a[c]-f;d+=m*g+w*y,p+=m*y-w*g,v+=m*m+w*w}var x=d/v,M=p/v,b={a:x,b:-M*u,c:M,d:x*u};b.tx=l-(x*s-M*h),
b.ty=f-(M*s+x*h);var A=0;for(c=0;c<n;c++)A=Math.max(A,o(b.a*t[c]+b.b*r[c]+b.tx-e[c],b.c*t[c]+b.d*r[c]+b.ty-a[c]));return b.res=A,b.scale=Math.sqrt(x*x+M*M),b}
var S=null;for(g=0;g<v.length;g++){for(var C=v[g],B=Math.round(C.s2/4),I=Math.round(C.s1/4),P=n+.01*C.s2,z=-1;z<=1;z++)for(var T=-1;T<=1;T++){
var W=w[B+z+","+(I+T)];if(W)for(var R=0;R<W.length;R++){var G=m[W[R]];if(!(Math.abs(G.s0-C.s0)>P||Math.abs(G.s1-C.s1)>P||Math.abs(G.s2-C.s2)>P)){
for(var j=[],q=[],L=[],D=[],H=0;H<3;H++)j.push(u.x[G.v[H]]),q.push(u.y[G.v[H]]),L.push(f.x[C.v[H]]),D.push(f.y[C.v[H]]);for(var E=0;E<2;E++){
var V=F(j,q,L,D,1===E);if(!(V.res>2*n||Math.abs(V.scale/s-1)>.05)){var U=k(V);(!S||U.n>S.n||U.n===S.n&&U.rms<S.rms)&&((S=V).n=U.n,S.rms=U.rms,S.mirror=1===E)}}}
}}if(S&&S.n>=3*h)break}if(!S||S.n<h)return null;var N=[];for(k(S,N),j=[],q=[],L=[],D=[],M=0;M<N.length;M++)j.push(d.x[N[M][0]]),q.push(d.y[N[M][0]]),
L.push(c.x[N[M][1]]),D.push(c.y[N[M][1]]);var O=F(j,q,L,D,S.mirror);return U=k(O),O.n=U.n,O.rms=U.rms,O.mirrored=S.mirror,O.n>=h?O:null}
v.prototype.project=function(t){var r=t[0]*this.t[0]+t[1]*this.t[1]+t[2]*this.t[2]
;return[(t[0]*this.e[0]+t[1]*this.e[1]+t[2]*this.e[2])/r,(t[0]*this.n[0]+t[1]*this.n[1]+t[2]*this.n[2])/r]},g.prototype.fwd=function(t,r){
return w(this.cx,this.cy,this.nx,this.ny,t/this.step+1,r/this.step+1,[0,0],this.wx,this.wy)},g.prototype.inv=function(t,r,e){var a,o;if(e)a=e[0],o=e[1];else{
var i=t-this.centre[0],n=r-this.centre[1];a=this.xc+this.k11*i+this.k12*n,o=this.yc+this.k21*i+this.k22*n}for(var s=0;s<12;s++){
var h=w(this.cx,this.cy,this.nx,this.ny,a/this.step+1,o/this.step+1,this.tmp,this.wx,this.wy),l=t-h[0],f=r-h[1];if(a+=this.k11*l+this.k12*f,
o+=this.k21*l+this.k22*f,l*l+f*f<1e-12)break}return[a,o]},M.prototype.phi=function(t,r,e){e=e||this.phiBuf
;var a=(t-this.c0[0])/this.s,o=(r-this.c0[1])/this.s,i=0;return e[i++]=1,this.order>=1&&(e[i++]=a,e[i++]=o),this.order>=2&&(e[i++]=a*a,e[i++]=a*o,e[i++]=o*o),
this.order>=3&&(e[i++]=a*a*a,e[i++]=a*a*o,e[i++]=a*o*o,e[i++]=o*o*o),e},M.prototype.apply=function(t,r){
for(var e=this.phi(t,r),a=0,o=0,i=0;i<this.nb;i++)a+=e[i]*this.cx[i],o+=e[i]*this.cy[i];return[t+a,r+o]},M.prototype.invert=function(t,r){
for(var e=t,a=r,o=0;o<20;o++){for(var i=this.phi(e,a),n=0,s=0,h=0;h<this.nb;h++)n+=i[h]*this.cx[h],s+=i[h]*this.cy[h];e=t-n,a=r-s}return[e,a]};var j={bin:16,
minClean:.5,bgDeg:2,structWarn:.3,apR:9,anR0:14,anR1:20,vigMin:.01,knot:128,smooth:1,objEps:.003,gxSky:.5,skyMin:.6};function q(t,r,e){
var a=1e20,o=new Float64Array(r*e),i=Math.max(r,e),n=new Float64Array(i),s=new Float64Array(i+1),h=new Int32Array(i),l=new Float64Array(i),f=new Float64Array(32*e)
;function u(t){var r=0;h[0]=0,s[0]=-a,s[1]=a;for(var e=1;e<t;e++){for(var o=(n[e]+e*e-(n[h[r]]+h[r]*h[r]))/(2*e-2*h[r]);o<=s[r];)r--,
o=(n[e]+e*e-(n[h[r]]+h[r]*h[r]))/(2*e-2*h[r]);r++,h[r]=e,s[r]=o,s[r+1]=a}for(r=0,e=0;e<t;e++){for(;s[r+1]<e;)r++;var i=e-h[r];l[e]=i*i+n[h[r]]}}
for(var c=0;c<r;c+=32){for(var d=Math.min(32,r-c),p=0;p<e;p++)for(var v=p*r+c,m=0;m<d;m++)f[m*e+p]=t[v+m]?0:a;for(m=0;m<d;m++){var w=m*e
;for(p=0;p<e;p++)n[p]=f[w+p];for(u(e),p=0;p<e;p++)f[w+p]=l[p]}for(p=0;p<e;p++)for(v=p*r+c,m=0;m<d;m++)o[v+m]=f[m*e+p]}for(p=0;p<e;p++){v=p*r
;for(var g=0;g<r;g++)n[g]=o[v+g];for(u(r),g=0;g<r;g++)o[v+g]=l[g]}return o}function L(t,r,e,a){
for(var o=q(t,r,e),i=new Uint8Array(r*e),n=a*a+.5,s=0;s<i.length;s++)i[s]=o[s]<=n?1:0;return i}function D(t,r,e){
for(var a=new Uint8Array(r*e),o=new Uint8Array(r*e),i=0;i+1<e;i++)for(var n=0;n+1<r;n++)a[s=i*r+n]=t[s]&t[s+1]&t[s+r]&t[s+r+1];for(i=0;i<e;i++)for(n=0;n<r;n++){
var s;o[s=i*r+n]=a[s]|(n>0?a[s-1]:0)|(i>0?a[s-r]:0)|(n>0&&i>0?a[s-r-1]:0)}return o}function H(t,a,o,i,n,s){
for(var h=n?Math.round(32/n):32,l=Math.floor(o/h),d=Math.floor(i/h),p=new Float32Array(l*d),v=[],m=0;m<o*i;m+=5)a[m]&&v.push(t[m])
;for(var w=r(v),g=0;g<d;g++)for(var y=0;y<l;y++){for(var x=0,M=!1,b=0;b<h&&!M;b++)for(var A=(g*h+b)*o+y*h,k=0;k<h;k++){if(!a[A+k]){M=!0;break}x+=t[A+k]}
p[g*l+y]=M?w:x/(h*h)}var F=f(u(p,l,d,5),l,d,o,i),S=new Float32Array(o*i);for(m=0;m<o*i;m++)S[m]=t[m]-F[m];F=null;var C=n?rt(S,o,i,1.5/n):c(S,o,i,1.5),B=[]
;for(m=0;m<o*i;m+=3)a[m]&&B.push(C[m]);x=e(B).sigma;var I=new Uint8Array(o*i);for(m=0;m<o*i;m++)I[m]=C[m]>2.5*x?1:0;C=null,I=L(n?I:D(I,o,i),o,i,n?6/n:6)
;var P=s?new Uint8Array(I):null,z=n?rt(S,o,i,8/n):c(S,o,i,8),T=new Uint8Array(o*i);for(m=0;m<o*i;m++)T[m]=z[m]>x?1:0;for(z=null,T=L(T,o,i,n?30/n:30),
m=0;m<o*i;m++)I[m]|=T[m];return s?{obj:I,compact:P}:I}function E(t,e,a,o){for(var i=j.bin,n=t.box[0],s=t.box[1],h=t.w,l=t.h,f=t.chans.length,u=[],c=0;c<f;c++){
for(var d=new Float32Array(a*o),p=0;p<d.length;p++)d[p]=NaN;u.push(d)}
for(var v=Math.floor(n/i),m=Math.floor(s/i),w=Math.ceil((n+h)/i),g=Math.ceil((s+l)/i),y=new Float64Array(i*i),x=new Int32Array(i*i),M=j.minClean*i*i,b=m;b<g;b++)for(var A=v;A<w;A++){
for(var k=0,F=b*i;F<(b+1)*i;F++){var S=F-s;if(!(S<0||S>=l))for(var C=A*i;C<(A+1)*i;C++){var B=C-n;B<0||B>=h||e[p=S*h+B]&&(x[k++]=p)}}if(!(k<M))for(c=0;c<f;c++){
d=t.chans[c];for(var I=0;I<k;I++)y[I]=d[x[I]];u[c][b*a+A]=r(y,k)}}return u}function V(t,r){for(var a=t.w,o=t.h,i=[],n=0;n<t.chans.length;n++){
for(var s=t.chans[n],h=[],l=0;l+1<o;l+=2)for(var f=0;f+1<a;f+=2){var u=l*a+f;r[u]&&r[u+1]&&r[u+a]&&r[u+a+1]&&h.push((s[u]-s[u+a]-s[u+1]+s[u+a+1])/2)}
i.push(e(h).sigma)}return i}function U(t,e){
for(var a=j,o=a.anR1,i=t.box[0],n=t.box[1],s=t.w,h=t.h,l=t.chans.length,f=[],u=[],c=-o;c<=o;c++)for(var d=-o;d<=o;d++){var p=Math.sqrt(d*d+c*c)
;p<=a.apR?f.push(c*s+d):p>=a.anR0&&p<=o&&u.push(c*s+d)}for(var v=[],m=[],w=new Float64Array(u.length),g=0;g<e.length;g++){
for(var y=Math.round(e[g][0]-i),x=Math.round(e[g][1]-n),M=[],b=NaN,A=0;A<l;A++)M.push(NaN);if(y>=o&&x>=o&&y<s-o&&x<h-o){var k=!0,F=x*s+y
;for(c=-o;c<=o&&k;c++)for(d=-o;d<=o;d++)if(!t.mask[F+c*s+d]){k=!1;break}if(k)for(b=-1/0,A=0;A<l;A++){for(var S=t.chans[A],C=0,B=0;B<f.length;B++){
var I=S[F+f[B]];C+=I,I>b&&(b=I)}for(B=0;B<u.length;B++)w[B]=S[F+u[B]];M[A]=C-r(w,u.length)*f.length}}v.push(M),m.push(b)}return{flux:v,peak:m}}
function N(t,r,a,o,i,n){n=n||6,o=o||3,i=i||3;for(var h=t.length,l=t[0].length,f=new Uint8Array(h),u=null,c=0;c<h;c++)f[c]=isFinite(r[c])?1:0
;for(var d=new Float64Array(l),p=0;p<n;p++){var v=new s(l,1);for(c=0;c<h;c++)if(f[c]){for(var m=0;m<l;m++)d[m]=t[c][m];v.add(d,[r[c]],a?a[c]:1)}u=v.solve(0)[0]
;var w=new Float64Array(h),g=[];for(c=0;c<h;c++){var y=0;for(m=0;m<l;m++)y+=t[c][m]*u[m];w[c]=r[c]-y,f[c]&&g.push(w[c])}var x=e(g);if(0===x.sigma)break;var M=!1
;for(c=0;c<h;c++){var b=isFinite(r[c])&&w[c]<i*x.sigma&&w[c]>-o*x.sigma?1:0;b!==f[c]&&(M=!0,f[c]=b)}if(!M)break}return{coef:u,keep:f}}function O(t,r){
for(var e=[],a=0;a<r;a++){var o=new Float64Array(r);o[a]=1,e.push(o)}return n(new Float64Array(t),r,e),e}function X(t,r){this.ox=t[0],this.oy=t[1],this.k=r,
this.nx=Math.ceil((t[2]-t[0])/r)+3,this.ny=Math.ceil((t[3]-t[1])/r)+3,this.n=this.nx*this.ny,this.wx=new Float64Array(4),this.wy=new Float64Array(4)}
function _(t,r,e,a,o,i,n,s,h,l,f,u,c){
for(var d=r.length-1,p=f?new Float64Array(f):new Float64Array(t),v=new Float64Array(t),m=new Float64Array(t),w=new Float64Array(d),g=0;g<d;g++)for(var y=r[g];y<r[g+1];y++)v[e[y]]+=o[g]*a[y]*i[g],
m[e[y]]+=o[g]*a[y]*a[y];for(var x=0;x<n.length;x++)m[n[x]]+=h,m[s[x]]+=h;for(var M=0;M<t;M++)m[M]+=l;function b(i,f){for(var u=0;u<d;u++){
for(var c=0,p=r[u];p<r[u+1];p++)c+=a[p]*i[e[p]];w[u]=o[u]*c}for(var v=0;v<t;v++)f[v]=l*i[v]
;for(u=0;u<d;u++)if(0!==(c=w[u]))for(p=r[u];p<r[u+1];p++)f[e[p]]+=a[p]*c;for(var m=0;m<n.length;m++){var g=h*(i[n[m]]-i[s[m]]);f[n[m]]+=g,f[s[m]]-=g}}
g=new Float64Array(t);var A=new Float64Array(t),k=new Float64Array(t),F=new Float64Array(t);b(p,F);var S=0;for(M=0;M<t;M++)g[M]=v[M]-F[M],A[M]=g[M]/m[M],
k[M]=A[M],S+=v[M]*v[M];S=Math.sqrt(S)||1;var C=0;for(M=0;M<t;M++)C+=g[M]*A[M];for(var B=0;B<c;B++){b(k,F);var I=0;for(M=0;M<t;M++)I+=k[M]*F[M];var P=C/I,z=0
;for(M=0;M<t;M++)p[M]+=P*k[M],g[M]-=P*F[M],z+=g[M]*g[M];if(Math.sqrt(z)/S<u)break;var T=0;for(M=0;M<t;M++)A[M]=g[M]/m[M],T+=g[M]*A[M];var W=T/C;for(C=T,
M=0;M<t;M++)k[M]=A[M]+W*k[M]}return p.iterations=B,p}function K(t,r,e){for(var a=[1],o=1;o<=e;o++)for(var i=0;i<=o;i++)a.push(Math.pow(t,o-i)*Math.pow(r,i))
;return a}function Y(t,r,e,a){for(var o=[],i=0;i<e;i+=a)for(var n=0;n<r;n+=a){for(var s=0,h=0,l=i;l<i+a;l++)for(var f=n;f<n+a;f++)if(!(l>=e||f>=r)){
var u=t[l*r+f];u==u&&(s+=u,h++)}h>=a*a/2&&o.push(s/h)}return o}function Z(t,r){for(var e=new Float64Array(t.length),a=0;a<t.length;a++)e[a]=t[a];e.sort()
;var o=(e.length-1)*r/100,i=Math.floor(o),n=Math.min(i+1,e.length-1);return e[i]+(o-i)*(e[n]-e[i])}function J(t,r,e){
for(var a=l(h(t,r,e),r,e,4),o=a.w*a.h,i=new Uint8Array(o),n=0,s=0,f=0;f<o;f++)i[f]=0!==a.data[f]?1:0;var u=H(a.data,i,a.w,a.h,4);for(f=0;f<o;f++)i[f]&&(n++,
u[f]||s++);return n?s/n:0}X.w=function(t,r){var e=t*t,a=e*t;r[0]=(1-t)*(1-t)*(1-t)/6,r[1]=(3*a-6*e+4)/6,r[2]=(-3*a+3*e+3*t+1)/6,r[3]=a/6},
X.prototype.basis=function(t,r,e,a){var o=(t-this.ox)/this.k,i=(r-this.oy)/this.k,n=Math.floor(o),s=Math.floor(i);n<0?n=0:n>this.nx-4&&(n=this.nx-4),
s<0?s=0:s>this.ny-4&&(s=this.ny-4),X.w(o-n,this.wx),X.w(i-s,this.wy);for(var h=0,l=0;l<4;l++)for(var f=0;f<4;f++)e[h]=(s+l)*this.nx+n+f,
a[h++]=this.wy[l]*this.wx[f]},X.prototype.eval=function(t,r,e){var a=(t-this.ox)/this.k,o=(r-this.oy)/this.k,i=Math.floor(a),n=Math.floor(o)
;i<0?i=0:i>this.nx-4&&(i=this.nx-4),n<0?n=0:n>this.ny-4&&(n=this.ny-4),X.w(a-i,this.wx),X.w(o-n,this.wy);for(var s=0,h=0;h<4;h++){
for(var l=(n+h)*this.nx+i,f=0,u=0;u<4;u++)f+=this.wx[u]*e[l+u];s+=this.wy[h]*f}return s};var Q={G:8,levels:7,noiseW:4,edgeW:2,edgeR:400,edgeMin:48,seamW:1,
objW:30,sweeps:2,blendPad:512,blendK:1800,blendMin:300,visEps:.1,psdT:128,kernR:16,small:8};function $(t,r,e,a,o,i){
for(var n=-1,s=-3,h=1<<30,l=2*i,f=new Int32Array(l),u=new Float64Array(l),c=new Int32Array(t+1),d=new Int32Array(l),p=0;p<i;p++)f[2*p]=a[p],f[2*p+1]=e[p],
u[2*p]=o[p],c[e[p]+1]++,c[a[p]+1]++;for(var v=0;v<t;v++)c[v+1]+=c[v];var m=new Int32Array(t);for(p=0;p<i;p++){var w=e[p],g=a[p];d[c[w]+m[w]++]=2*p,
d[c[g]+m[g]++]=2*p+1}m=null
;var y=new Int32Array(t),x=new Uint8Array(t),M=new Int32Array(t),b=new Int32Array(t),A=new Int32Array(t+1),k=new Uint8Array(t),F=0,S=0,C=0,B=t+1;function I(t){
k[t]||(k[t]=1,A[S]=t,S=S+1===B?0:S+1,C++)}function P(){for(;C>0;){var t=A[F];if(F=F+1===B?0:F+1,C--,k[t]=0,y[t]!==s)return t}return-1}
for(v=0;v<t;v++)r[v]>0?(y[v]=n,x[v]=0,b[v]=1,I(v)):r[v]<0?(y[v]=n,x[v]=1,b[v]=1,I(v)):y[v]=s;var z=[],T=0,W=0;function R(t){y[t]=-2,z.push(t)}function G(t){
var e,a,o=u[t];for(a=f[1^t];(e=y[a])!==n;a=f[e])u[1^e]<o&&(o=u[1^e]);for(r[a]<o&&(o=r[a]),a=f[t];(e=y[a])!==n;a=f[e])u[e]<o&&(o=u[e]);for(-r[a]<o&&(o=-r[a]),
u[1^t]+=o,u[t]-=o,a=f[1^t];(e=y[a])!==n;a=f[e])u[e]+=o,u[1^e]-=o,0===u[1^e]&&R(a);for(r[a]-=o,0===r[a]&&R(a),a=f[t];(e=y[a])!==n;a=f[e])u[1^e]+=o,u[e]-=o,
0===u[e]&&R(a);r[a]+=o,0===r[a]&&R(a)}function j(t){for(var r=x[t],e=h,a=-1,o=c[t];o<c[t+1];o++){var i=d[o];if(r?u[i]>0:u[1^i]>0){var l=f[i]
;if(x[l]===r&&y[l]!==s){for(var p=0;;){if(M[l]===W){p+=b[l];break}if(p++,(v=y[l])===n){M[l]=W,b[l]=1;break}if(-2===v){p=h;break}l=f[v]}if(p<h)for(p<e&&(a=i,
e=p),l=f[i];M[l]!==W;l=f[y[l]])M[l]=W,b[l]=p--}}}if(a>=0)return y[t]=a,M[t]=W,void(b[t]=e+1);for(y[t]=s,o=c[t];o<c[t+1];o++){i=d[o],l=f[i];var v=y[l]
;x[l]===r&&v!==s&&((r?u[i]>0:u[1^i]>0)&&I(l),v!==n&&-2!==v&&f[v]===t&&R(l))}}for(var q=-1;!((q<0||y[q]===s)&&(q=P())<0);){var L=-1;if(x[v=q]){
for(D=c[v];D<c[v+1];D++)if(H=d[D],!(u[1^H]<=0))if(E=f[H],y[E]===s)x[E]=1,y[E]=1^H,M[E]=M[v],b[E]=b[v]+1,I(E);else{if(!x[E]){L=1^H;break}
M[E]<=M[v]&&b[E]>b[v]&&(y[E]=1^H,M[E]=M[v],b[E]=b[v]+1)}}else for(var D=c[v];D<c[v+1];D++){var H=d[D];if(!(u[H]<=0)){var E=f[H];if(y[E]===s)x[E]=0,y[E]=1^H,
M[E]=M[v],b[E]=b[v]+1,I(E);else{if(x[E]){L=H;break}M[E]<=M[v]&&b[E]>b[v]&&(y[E]=1^H,M[E]=M[v],b[E]=b[v]+1)}}}if(W++,L<0)q=-1;else{for(G(L);T<z.length;){
var V=z[T++];T>65536&&(z=z.slice(T),T=0),j(V)}z.length=0,T=0}}var U=new Uint8Array(t);for(v=0;v<t;v++)U[v]=y[v]===s||x[v]?0:1;return U}
function tt(t,r,e,a,o,i,n,s){var h=t.length,l=o*i;function f(a){for(var n=0,s=0;s<l;s++)a[s]>=0&&(n+=t[a[s]][s]);for(var h=0;h<i;h++)for(var f=0;f+1<o;f++){
var u=a[h*o+f],c=a[h*o+f+1];u>=0&&c>=0&&u!==c&&(n+=r[h*(o-1)+f])}for(h=0;h+1<i;h++)for(f=0;f<o;f++)u=a[h*o+f],c=a[(h+1)*o+f],u>=0&&c>=0&&u!==c&&(n+=e[h*o+f])
;return n}for(var u=[f(a)],c=new Int32Array(l),d=0;d<n;d++){for(var p=0,v=0;v<h;v++){for(var m=t[v],w=0,g=0;g<l;g++)c[g]=isFinite(m[g])?w++:-1;if(0!==w){
var y=new Float64Array(w);for(g=0;g<l;g++)c[g]>=0&&(y[c[g]]=(a[g]>=0?t[a[g]][g]:0)-m[g])
;for(var x=new Int32Array(2*w),M=new Int32Array(2*w),b=new Float64Array(2*w),A=0,k=function(t,r,e){var o=a[t],i=a[r],n=c[t],s=c[r];if(n>=0&&s>=0){
var h=i!==v?e:0,l=o!==v?e:0,f=o!==i?e:0;y[n]+=l,y[s]+=f-l;var u=h+l-f;u>0&&(x[A]=n,M[A]=s,b[A]=Math.round(1e3*u),A++)
}else n>=0&&i>=0?y[n]+=(o!==i?e:0)-(i!==v?e:0):s>=0&&o>=0&&(y[s]+=(i!==o?e:0)-(o!==v?e:0))},F=0;F<i;F++)for(var S=0;S+1<o;S++)k(F*o+S,F*o+S+1,r[F*(o-1)+S])
;for(F=0;F+1<i;F++)for(S=0;S<o;S++)k(F*o+S,(F+1)*o+S,e[F*o+S]);for(var C=new Float64Array(w),B=0;B<w;B++)C[B]=Math.round(1e3*y[B])
;var I=$(w,C,x,M,b,A),P=new Int32Array(a),z=0;for(g=0;g<l;g++)c[g]>=0&&I[c[g]]&&P[g]!==v&&(P[g]=v,z++);var T=f(P);T<u[u.length-1]-1e-9&&(p+=z,a=P,u.push(T))}}
if(s&&s("  graph cut sweep "+(d+1)+": energy "+u[u.length-1].toFixed(1)+", "+p+" cells changed"),0===p)break}return{label:a,hist:u}}function rt(t,r,e,a){
if(a<=.25)return new Float32Array(t);if(a<=2)return c(t,r,e,a);var o=Math.sqrt(12*a*a/3+1),i=Math.floor(o);i%2==0&&i--
;for(var n=i+2,s=Math.round((12*a*a-3*i*i-12*i-9)/(-4*i-4)),h=t,l=0;l<3;l++)h=et(h,r,e,(l<s?i:n)-1>>1);return h}function et(t,r,e,a){
var o=new Float32Array(r*e),i=new Float32Array(r*e),n=1/(2*a+1),s=new Float64Array(r+2*a+1),h=new Float64Array(r);function l(t,r){if(1===r)return 0
;for(;t<0||t>=r;)t=t<0?-t:2*r-2-t;return t}for(var f=0;f<e;f++){for(var u=f*r,c=-a;c<r+a;c++)s[c+a]=t[u+l(c,r)];s[r+2*a]=0;for(var d=0,p=0;p<2*a+1;p++)d+=s[p]
;for(var v=0;v<r;v++)o[u+v]=d*n,d+=s[v+2*a+1]-s[v]}for(v=0;v<r;v++)h[v]=0;for(p=-a;p<=a;p++){var m=l(p,e)*r;for(v=0;v<r;v++)h[v]+=o[m+v]}for(f=0;f<e;f++){
for(u=f*r,v=0;v<r;v++)i[u+v]=h[v]*n;if(f+1===e)break;var w=l(f+a+1,e)*r,g=l(f-a,e)*r;for(v=0;v<r;v++)h[v]+=o[w+v]-o[g+v]}return i}function at(t,r,e,a){
var o=r*e,i=new Uint8Array(o);if(!(a>0)){for(var n=0;n<o;n++)i[n]=t[n]?1:0;return i}if(a>8){
for(var s=Math.max(2,Math.floor(a/6)),h=Math.ceil(r/s),l=Math.ceil(e/s),f=new Uint8Array(h*l),u=0;u<e;u++)for(var c=u*r,d=Math.floor(u/s)*h,p=0;p<r;p++)t[c+p]&&(f[d+Math.floor(p/s)]=1)
;var v=L(f,h,l,a/s+.5);for(u=0;u<e;u++)for(c=u*r,d=Math.floor(u/s)*h,p=0;p<r;p++)i[c+p]=v[d+Math.floor(p/s)];return i}
var m=a*a+.5,w=Math.floor(Math.sqrt(m)),g=w+1,y=new Uint8Array(o);for(u=0;u<e;u++){c=u*r;var x=g;for(p=0;p<r;p++)x=t[c+p]?0:Math.min(x+1,g),y[c+p]=x;for(x=g,
p=r-1;p>=0;p--)(x=t[c+p]?0:Math.min(x+1,g))<y[c+p]&&(y[c+p]=x)}for(var M=-w;M<=w;M++){var b=m-M*M;if(!(b<0)){var A=Math.floor(Math.sqrt(b))
;for(u=Math.max(0,-M);u<Math.min(e,e-M);u++){c=u*r;var k=(u+M)*r;for(p=0;p<r;p++)y[k+p]<=A&&(i[c+p]=1)}}}return i}function ot(t,r,e,a){
for(var o=r*e,i=new Uint8Array(o),n=0;n<o;n++)i[n]=t[n]?0:1;var s=at(i,r,e,a);for(n=0;n<o;n++)s[n]=s[n]?0:1;return s}function it(t,r,e,a){
return a>0?at(ot(t,r,e,a),r,e,a):t}function nt(t,r,e,a){return a>0?ot(at(t,r,e,a),r,e,a):t}function st(t,r,e,a){
for(var o=r*e,i=new Int32Array(o),n=new Int32Array(o),s=new Uint8Array(o),h=0,l=0;l<o;l++)if(t[l]&&!i[l]){h++;var f=0,u=0;n[f++]=l,i[l]=h;for(var c=[];f>0;){
var d=n[--f],p=d%r,v=(d-p)/r;c.push(d),u++;for(var m=-1;m<=1;m++){var w=v+m;if(!(w<0||w>=e))for(var g=-1;g<=1;g++){var y=p+g;if(!(y<0||y>=r)){var x=w*r+y
;t[x]&&!i[x]&&(i[x]=h,n[f++]=x)}}}}if(u>a)for(var M=0;M<c.length;M++)s[c[M]]=1}return s}function ht(t,r,e){
for(var a=r*e,o=new Uint8Array(a),i=new Int32Array(a),n=0,s=0;s<a;s++)o[s]=1;function h(r){!t[r]&&o[r]&&(o[r]=0,i[n++]=r)}for(var l=0;l<r;l++)h(l),h((e-1)*r+l)
;for(var f=0;f<e;f++)h(f*r),h(f*r+r-1);for(;n>0;)(l=(s=i[--n])%r)>0&&h(s-1),l<r-1&&h(s+1),s>=r&&h(s-r),s<a-r&&h(s+r);return o}function lt(t,r,e){
for(var a=q(t,r,e),o=new Float32Array(r*e),i=0;i<o.length;i++)o[i]=Math.sqrt(a[i]);return o}function ft(t,r,e){
var a=r+1>>1,o=e+1>>1,i=new Float32Array(a*e),n=new Float32Array(a*o);function s(t,r){return 1===r?0:t<0?-t:t>=r?2*r-2-t:t}
for(var h=0;h<e;h++)for(var l=h*r,f=h*a,u=0;u<a;u++){var c=2*u
;i[f+u]=c>=2&&c+2<r?.0625*(t[l+c-2]+t[l+c+2]+4*(t[l+c-1]+t[l+c+1])+6*t[l+c]):.0625*(t[l+s(c-2,r)]+t[l+s(c+2,r)]+4*(t[l+s(c-1,r)]+t[l+s(c+1,r)])+6*t[l+c])}
for(h=0;h<o;h++){l=h*a;var d=s((c=2*h)-2,e)*a,p=s(c-1,e)*a,v=c*a,m=s(c+1,e)*a,w=s(c+2,e)*a
;for(u=0;u<a;u++)n[l+u]=.0625*(i[d+u]+i[w+u]+4*(i[p+u]+i[m+u])+6*i[v+u])}return n}function ut(t,r,e,a,o){
for(var i=new Float32Array(a*e),n=new Float32Array(a*o),s=0;s<e;s++){for(var h=s*r,l=s*a,f=2;f<a-2;f++){var u=f>>1
;i[l+f]=1&f?.5*(t[h+u]+t[h+u+1]):.125*(t[h+u-1]+6*t[h+u]+t[h+u+1])}for(f=0;f<a;f++)if(!(f>=2&&f<a-2)){
for(var c=0,d=-2;d<=2;d++)(w=f+d)<0?w=-w:w>=a&&(w=2*a-2-w),1&w||(c+=(0===d?6:1===d||-1===d?4:1)*t[h+Math.min(w>>1,r-1)]);i[l+f]=.125*c}}
for(s=0;s<o;s++)if(h=s*a,s>=2&&s<o-2){var p=(u=s>>1)*a,v=(u+1)*a,m=(u-1)*a
;if(1&s)for(f=0;f<a;f++)n[h+f]=.5*(i[p+f]+i[v+f]);else for(f=0;f<a;f++)n[h+f]=.125*(i[m+f]+6*i[p+f]+i[v+f])}else{for(f=0;f<a;f++)n[h+f]=0;for(d=-2;d<=2;d++){
var w;if((w=s+d)<0?w=-w:w>=o&&(w=2*o-2-w),!(1&w)){var g=.125*(0===d?6:1===d||-1===d?4:1),y=Math.min(w>>1,e-1)*a;for(f=0;f<a;f++)n[h+f]+=g*i[y+f]}}}return n}
function ct(t,r,e,a){for(var o=e*a,i=new Float32Array(o),n=0;n<o;n++)i[n]=t[n]*r[n];for(var s=[i],h=[r],l=[e],f=[a];Math.min(l[l.length-1],f[f.length-1])>8;){
var u=s.length-1;s.push(ft(s[u],l[u],f[u])),h.push(ft(h[u],l[u],f[u])),l.push(l[u]+1>>1),f.push(f[u]+1>>1)}var c=s.length-1,d=s[c]
;for(n=0;n<d.length;n++)d[n]=d[n]/Math.max(h[c][n],1e-6);for(u=c-1;u>=0;u--){var p=ut(d,l[u+1],f[u+1],l[u],f[u]),v=s[u],m=h[u],w=l[u]*f[u]
;for(d=new Float32Array(w),n=0;n<w;n++){var g=m[n],y=u?Math.min(Math.max(2*g,0),1):r[n];d[n]=y>0?y*(v[n]/Math.max(g,1e-6))+(1-y)*p[n]:p[n]}s[u+1]=null,
h[u+1]=null}return d}function dt(t,r,e){if(!e)return-1;if(r>=0&&e>>>r&1)return r;for(var a=0;a<t.order.length;a++)if(e>>>t.order[a]&1)return t.order[a];return-1
}function pt(t,r,e){for(var a=Q.G,o=t.cells.Wc,i=t.W,n=e[1];n<e[3];n++)for(var s=(n/a|0)*o,h=e[0];h<e[2];h++){var l=n*i+h;t.labf[l]=dt(t,r[s+(h/a|0)],t.cov[l])}
}function vt(t,r,e){for(var a=Q.levels,o=t.fill.length,i=t.nc,n=t.W,s=t.H,h=t.labf,l=[[r[2]-r[0],r[3]-r[1]]],f=0;f<a;f++)l.push([l[f][0]+1>>1,l[f][1]+1>>1])
;for(var u=null,c=[],d=0;d<i;d++){var p=l.map(function(t){return new Float32Array(t[0]*t[1])}),v=null===u;v&&(u=l.map(function(t){
return new Float32Array(t[0]*t[1])}));for(var m=0;m<o;m++){
var w=t.fbox[m],g=w[2]-w[0],y=[Math.max(w[0],r[0]),Math.max(w[1],r[1]),Math.min(w[2],r[2]),Math.min(w[3],r[3])];if(!(y[2]<=y[0]||y[3]<=y[1])){
e&&e("  blend "+t.names[m]+(i>1?", channel "+d:""))
;for(var x=y[2]-y[0],M=y[3]-y[1],b=new Float32Array(x*M),A=new Float32Array(x*M),k=t.fill[m][d],F=!1,S=0;S<M;S++){
for(var C=y[1]+S,B=(C-w[1])*g+y[0]-w[0],I=0;I<x;I++)b[S*x+I]=k[B+I];if(!(C>=s))for(I=0;I<x;I++){var P=y[0]+I;P<n&&h[C*n+P]===m&&(A[S*x+I]=1,F=!0)}}if(F){
var z=A,T=b,W=x,R=M;for(f=0;f<=a;f++){var G,j=1<<f,q=(y[0]-r[0])/j,L=(y[1]-r[1])/j,D=l[f][0],H=null,E=W+1>>1,V=R+1>>1;if(f<a){var U=ut(H=ft(T,W,R),E,V,W,R);G=T
;for(var N=0;N<G.length;N++)G[N]-=U[N];U=null}else G=T;var O=p[f],X=u[f];for(S=0;S<R;S++){var _=(L+S)*D+q,K=S*W;if(L+S>=l[f][1])break;for(I=0;I<W;I++){
var Y=z[K+I];0===Y||q+I>=D||(O[_+I]+=G[K+I]*Y,v&&(X[_+I]+=Y))}}f<a&&(z=ft(z,W,R),T=H,W=E,R=V)}b=A=z=T=null}}}var Z=null;for(f=a;f>=0;f--){O=p[f],X=u[f]
;var J=O.length;for(N=0;N<J;N++)O[N]=X[N]>1e-6?O[N]/X[N]:0;if(null===Z)Z=O;else{for(U=ut(Z,l[f+1][0],l[f+1][1],l[f][0],l[f][1]),N=0;N<J;N++)U[N]+=O[N];Z=U}
p[f]=null}c.push(Z)}return c}var mt={};function wt(t,r,e,a,o,i){o=o||0,i=i||1;for(var n=function(t){if(mt[t])return mt[t]
;for(var r=Math.round(Math.log(t)/Math.LN2),e=new Int32Array(t),a=new Float64Array(t/2),o=new Float64Array(t/2),i=0;i<t;i++){
for(var n=0,s=0;s<r;s++)n|=(i>>s&1)<<r-1-s;e[i]=n}for(i=0;i<t/2;i++)a[i]=Math.cos(2*Math.PI*i/t),o[i]=Math.sin(2*Math.PI*i/t);return mt[t]={rev:e,cs:a,sn:o}
}(e),s=n.rev,h=a?1:-1,l=0;l<e;l++)if((v=s[l])>l){var f=o+v*i,u=t[m=o+l*i];t[m]=t[f],t[f]=u,u=r[m],r[m]=r[f],r[f]=u}for(var c=2;c<=e;c<<=1){var d=c>>1,p=e/c
;for(l=0;l<e;l+=c)for(var v=0;v<d;v++){var m,w=n.cs[v*p],g=h*n.sn[v*p],y=t[f=(m=o+(l+v)*i)+d*i]*w-r[f]*g,x=t[f]*g+r[f]*w;t[f]=t[m]-y,r[f]=r[m]-x,t[m]+=y,r[m]+=x
}}}function gt(t,r,e,a){for(var o=0;o<e;o++)wt(t,r,e,a,o*e,1);for(var i=0;i<e;i++)wt(t,r,e,a,i,e);if(a)for(var n=1/(e*e),s=0;s<e*e;s++)t[s]*=n,r[s]*=n}
function yt(t,r){for(var e=new Float64Array(r*r),a=0;a<r;a++)e[a*r+a]=1;for(var o=0;o<30;o++){for(var i=0,n=0,s=0;s<r;s++){n+=t[s*r+s]*t[s*r+s]
;for(var h=s+1;h<r;h++)i+=t[s*r+h]*t[s*r+h]}if(i<=1e-24*n||0===i)break;for(s=0;s<r;s++)for(h=s+1;h<r;h++){var l=t[s*r+h];if(0!==l){
for(var f=(t[h*r+h]-t[s*r+s])/(2*l),u=(f>=0?1:-1)/(Math.abs(f)+Math.sqrt(f*f+1)),c=1/Math.sqrt(u*u+1),d=u*c,p=0;p<r;p++){var v=t[p*r+s],m=t[p*r+h]
;t[p*r+s]=c*v-d*m,t[p*r+h]=d*v+c*m}for(p=0;p<r;p++){var w=t[s*r+p],g=t[h*r+p];t[s*r+p]=c*w-d*g,t[h*r+p]=d*w+c*g}for(p=0;p<r;p++){var y=e[p*r+s],x=e[p*r+h]
;e[p*r+s]=c*y-d*x,e[p*r+h]=d*y+c*x}}}}var M=new Float64Array(r);for(a=0;a<r;a++)M[a]=t[a*r+a];return{ev:M,V:e}}function xt(t,e,a){a=a||{}
;for(var o=Q,i=o.small,n=t.W,s=t.H,h=Math.floor(n/i),l=Math.floor(s/i),f=h*l,u=e.length,c=new Int32Array(f),d=new Uint8Array(f),p=new Float32Array(f),v=0;v<l;v++)for(var m=0;m<h;m++){
var w=t.labf[Math.floor(v*s/l)*n+Math.floor(m*n/h)];c[C=v*h+m]=w,d[C]=w>=0?1:0,p[C]=w>=0?e[w]:0}for(var g=r(e),y=[],x=void 0===a.blend?1:a.blend,M=0;M<u;M++){
var b=a.zoneWidth>0?a.zoneWidth:Math.min(Math.max(o.blendK*Math.log(Math.max(e[M]/g,1)),o.blendMin),.35*Math.min(n,s));y.push(b*x)}
var A=new Float32Array(p),k=new Int32Array(c);for(M=0;M<u;M++){for(var F=new Uint8Array(f),S=!1,C=0;C<f;C++)c[C]===M&&(F[C]=1,S=!0);if(S){var B=lt(F,h,l)
;for(C=0;C<f;C++)if(d[C]&&e[M]>p[C]){var I=1-(m=Math.min(B[C]*i/y[M],1))*m*(3-2*m),P=p[C]*Math.pow(e[M]/Math.max(p[C],1e-30),I);P>A[C]&&(A[C]=P,k[C]=M)}}}
var z=function(t,r,e,a){for(var o=e*a,i=new Float32Array(o),n=new Float32Array(o),s=0;s<o;s++)n[s]=r[s]?1:0,i[s]=r[s]?t[s]:0;var h=rt(i,e,a,3),l=rt(n,e,a,3)
;for(s=0;s<o;s++)h[s]=h[s]/Math.max(l[s],1e-6);return h}(A,d,h,l);for(C=0;C<f;C++)d[C]||(A[C]=z[C]);return{f:i,ws:h,hs:l,tg:A,src:k,sc:p,widths:y}}
function Mt(t,r,e,a,o){a=a||1
;for(var i=(o=o||[0,0,Math.floor(t.W/a),Math.floor(t.H/a)])[2]-o[0],n=o[3]-o[1],s=i*n,h=new Float32Array(s),l=new Float32Array(s),f=new Int8Array(s),u=new Int8Array(s),c=r.ws/t.W,d=r.hs/t.H,p=new Float64Array(i),v=new Int32Array(i),m=new Float64Array(i),w=new Int32Array(i),g=0;g<i;g++){
var y=(o[0]+g)*a+(a-1)/2,x=Math.min(Math.max((y+.5)*c-.5,0),r.ws-1);v[g]=Math.min(Math.floor(x),r.ws-2),m[g]=x-v[g],
w[g]=Math.min(Math.floor((o[0]+g)*a+a/2),t.W-1),p[g]=Math.min(Math.floor(w[g]/r.f),r.ws-1)}for(var M=0;M<n;M++){
var b=(o[1]+M)*a+(a-1)/2,A=Math.min(Math.max((b+.5)*d-.5,0),r.hs-1),k=Math.min(Math.floor(A),r.hs-2),F=A-k,S=k*r.ws,C=S+r.ws,B=Math.min(Math.floor((o[1]+M)*a+a/2),t.H-1),I=Math.min(Math.floor(B/r.f),r.hs-1)
;for(g=0;g<i;g++){var P=M*i+g,z=t.labf[B*t.W+w[g]];if(u[P]=z,z<0)f[P]=-1;else{
var T=r.tg[S+v[g]]+m[g]*(r.tg[S+v[g]+1]-r.tg[S+v[g]]),W=r.tg[C+v[g]]+m[g]*(r.tg[C+v[g]+1]-r.tg[C+v[g]]);h[P]=T+F*(W-T),l[P]=e[z],f[P]=r.src[I*r.ws+p[g]]}}}
return{w:i,h:n,tgt:h,cur:l,src:f,lab:u}}function bt(t,r,e,a,o,i){
var n=Math.min(Math.max((o+.5)/a-.5,0),r-1),s=Math.min(Math.max((i+.5)/a-.5,0),e-1),h=Math.min(Math.floor(n),r-2),l=Math.min(Math.floor(s),e-2),f=n-h,u=s-l,c=l*r+h,d=t[c]+f*(t[c+1]-t[c])
;return d+u*(t[c+r]+f*(t[c+r+1]-t[c+r])-d)}function At(t,r){
for(var e=Math.floor(t.W/r),a=Math.floor(t.H/r),o=e*a,i=new Float32Array(o),n=new Uint8Array(o),s=new Int8Array(o),h=1/(r*r*t.nc),l=0;l<a;l++)for(var f=0;f<e;f++){
for(var u=0,c=1,d=0;d<r;d++)for(var p=(l*r+d)*t.W+f*r,v=0;v<r;v++){t.union[p+v]||(c=0);for(var m=0;m<t.nc;m++)u+=t.chans[m][p+v]}var w=l*e+f;i[w]=u*h,n[w]=c,
s[w]=c?t.labf[Math.min(l*r+(r>>1),t.H-1)*t.W+Math.min(f*r+(r>>1),t.W-1)]:-1}return{w:e,h:a,lum:i,union:n,lab:s}}function kt(t,o,i,n,s){s=s||1
;var l=void 0===(n=n||{}).maskStrength?1:n.maskStrength,c=void 0===n.maskFeather?12:n.maskFeather,d=s+"|"+l+"|"+c,p=n.cache&&n.cache.key===d?n.cache:null,v=p?p.L:1===s?{
w:t.W,h:t.H,lum:h(t.chans,t.W,t.H),union:t.union,lab:t.labf}:At(t,s),m=v.w,w=v.h,g=m*w;if(!(l>0))return{prot:new Float32Array(g),w:m,h:w,b:s,full:0,part:0}
;if(p)return Ft(t,o,i,s,v,p.M,l);for(var y=rt(v.lum,m,w,6/s),x=[],M=0;M<i.length;M++){for(var b=[],A=0;A<g;A+=11)v.lab[A]===M&&b.push(v.lum[A]-y[A])
;x.push(b.length?e(b).sigma:1)}y=null;var k=function(t,o,i,n,s,h,l,c,d){d=d||1
;for(var p=n*s,v=1/Math.max(l,.05),m=i,w=new Float32Array(p),g=0;g<p;g++)w[g]=i[g]?1:0
;for(var y=Math.max(2,Math.round(32/d)),x=Math.floor(n/y),M=Math.floor(s/y),b=new Float32Array(x*M),A=[],k=0;k<M;k++)for(var F=0;F<x;F++){
for(var S=0,C=!1,B=0;B<y&&!C;B++)for(var I=(k*y+B)*n+F*y,P=0;P<y;P++){if(!m[I+P]){C=!0;break}S+=t[I+P]}b[k*x+F]=C?NaN:S/(y*y),C||A.push(b[k*x+F])}var z=r(A)
;for(g=0;g<b.length;g++)b[g]!=b[g]&&(b[g]=z);var T=f(u(b,x,M,9),x,M,n,s);b=null;var W=new Float32Array(p),R=new Float32Array(p)
;for(g=0;g<p;g++)m[g]&&(R[g]=t[g]-T[g],W[g]=R[g]/(o[g]>=0?h[o[g]]:1));var G=rt(R,n,s,3/d);function j(t){return e(a(t,m,17))}R=null
;var q=rt(W,n,s,1.5/d),L=rt(W,n,s,8/d),H=new Float32Array(p);for(g=0;g<p;g++)H[g]=q[g]-L[g];L=null;var E=j(H),V=new Uint8Array(p),U=E.med+5*v*E.sigma
;for(g=0;g<p;g++)V[g]=H[g]>U?1:0;H=null,d<2&&(V=D(V,n,s));var N=new Uint8Array(p);for(g=0;g<p;g++)N[g]=q[g]>80&&V[g]?1:0;q=null,N=at(N,n,s,12/d)
;var O=at(V,n,s,3/d);for(g=0;g<p;g++)O[g]|=N[g];N=V=null;var X=at(O,n,s,4/d),_=new Float32Array(p),K=new Float32Array(p);for(g=0;g<p;g++)_[g]=X[g]?0:w[g],
K[g]=W[g]*_[g];var Y=rt(K,n,s,10/d),Z=rt(_,n,s,10/d),J=K;for(g=0;g<p;g++)J[g]=_[g]>0?W[g]:Y[g]/Math.max(Z[g],.001);Y=Z=_=W=null
;for(var Q=new Float32Array(p),$=[4,10,25],tt=0;tt<$.length;tt++){var et=$[tt],ot=rt(J,n,s,et/d),lt=j(ot),ft=new Uint8Array(p),ut=ot;for(g=0;g<p;g++){
var ct=ot[g]-lt.med;ft[g]=ct>3.5*v*lt.sigma?1:0,ut[g]=Math.min(Math.max((ct-2.5*v*lt.sigma)/(6*v*lt.sigma),0),1)}
var dt=at(ft=ht(nt(ft=st(ft=it(ft,n,s,2/d),n,s,Math.max(60,4*et*et)/(d*d)),n,s,Math.floor(et)/d),n,s),n,s,(Math.floor(2*et*c/12)+1)/d);for(g=0;g<p;g++){
var pt=dt[g]?ut[g]:0;ft[g]&&(pt=1),pt>Q[g]&&(Q[g]=pt)}ot=ut=ft=dt=null}for(J=null,Q=rt(Q,n,s,Math.max(c,1)/d),g=0;g<p;g++)Q[g]=Math.min(1.2*Q[g],1)
;var vt=new Float32Array(p);for(g=0;g<p;g++)vt[g]=O[g];vt=rt(vt,n,s,2/d);var mt=new Float32Array(p)
;for(g=0;g<p;g++)m[g]?mt[g]=Math.max(Math.min(1.3*vt[g],1),Q[g]):Q[g]=0;return{prot:mt,sigObj:G,ext:Q,starz:X,bg:T}}(v.lum,v.lab,v.union,m,w,x,l,c,s)
;return k.lumS=rt(v.lum,m,w,2/s),k.sigObj=k.ext=k.starz=null,n.cache&&(n.cache.key=d,n.cache.L=v,n.cache.M=k),Ft(t,o,i,s,v,k,l)}function Ft(t,r,a,o,i,n,s){
for(var h=i.w,l=i.h,f=h*l,u=function(t){if(t.lumStf)return t.lumStf;for(var r=At(t,4),a=[],o=0;o<r.lum.length;o+=7)r.union[o]&&a.push(r.lum[o])
;var i=e(a),n=Math.max(i.med-2.8*i.sigma,0),s=(i.med-n)/(1-n);return t.lumStf={c0:n,m:-.75*s/(-.5*s-.25)}
}(t),c=u.c0,d=u.m,p=2*d-1,v=Q.visEps*s,m=Mt(t,r,a,o),w=new Float32Array(f),g=0,y=0,x=0,M=0;M<f;M++)if(i.union[M]){
var b=n.prot[M],A=m.tgt[M],k=m.cur[M],F=A*A-k*k;if(b>0&&F>0){
var S=p*Math.min(Math.max((n.lumS[M]-c)/(1-c),0),1)-d,C=p*Math.min(Math.max((n.bg[M]-c)/(1-c),0),1)-d,B=C*C/Math.max(S*S,1e-30);B>1&&(B=1);var I=A*(1-v/B),P=1
;I>k&&(P=1-Math.sqrt(I*I-k*k)/Math.sqrt(F)),b*=P<0?0:P}w[M]=b,x++,b>.99?g++:b>.01&&y++}return{prot:w,w:h,h:l,b:o,full:g/Math.max(x,1),part:y/Math.max(x,1)}}
function St(t,r,e,a){var o=Math.imul(r,2654435761)^Math.imul(e+1663821227,2246822519)^Math.imul(t+a,3266489917);o=Math.imul(o^o>>>16,2146121005),
o=Math.imul(o^o>>>15,2221713035),o^=o>>>16;var i=Math.imul(668265263^o,374761393);i=Math.imul(i^i>>>15,2246822519)
;var n=((o>>>0)+1)/4294967297,s=((i^=i>>>13)>>>0)/4294967296;return Math.sqrt(-2*Math.log(n))*Math.cos(2*Math.PI*s)}function Ct(t,r,e,a,o){
for(var i=(o=o||{}).log||function(){},n=t.nc,s=Q.kernR,h=2*s+1,l=o.cache||{tiles:{},bytes:0,kern:{},kept:1
},f=o.rect||[0,0,t.W,t.H],u=f[0],c=f[1],d=f[2]-f[0],p=f[3]-f[1],v=e.map(function(t){return t.sigma}),m=o.out||[],w=0;w<n;w++){
var g=m[w]||new Float32Array(d*p),y=t.chans[w];if(o.rect)for(var x=0;x<p;x++)for(var M=(c+x)*t.W+u,b=0;b<d;b++)g[x*d+b]=y[M+b];else g.set(y);m[w]=g}
var A=256,k=A-2*s,F=65536;var S=null,C=null,B=null,I=null,P=0;function z(t,r,a,o,i){var f=t+"|"+r,u=l.tiles[f]||(l.tiles[f]={}),c=a+"|"+o;if(u[c])return u[c]
;if(!S){S=[],C=[],B=new Float64Array(F),I=new Float64Array(F);for(var d=0;d<n;d++)S.push(new Float64Array(F)),C.push(new Float64Array(F))}if(!i.done){
var p=t*k,v=r*k;for(d=0;d<n;d++){for(var m=S[d],w=C[d],g=0;g<A;g++)for(var y=0;y<A;y++)m[g*A+y]=St(d,p-s+y,v-s+g,7),w[g*A+y]=0;gt(m,w,A,!1)}i.done=!0}
for(var x=function(t,r){var a=t+"|"+r;if(l.kern[a])return l.kern[a];var o=function(t,r,e){
for(var a=Q.psdT,o=a*a,i=Q.kernR,n=2*i+1,s=[],h=[],l=0;l<e*e;l++)s.push(new Float64Array(o)),h.push(new Float64Array(o))
;for(var f=2*e,u=new Float64Array(f*f),c=0;c<o;c++)if(1!==e){for(var d=0;d<e;d++)for(var p=0;p<e;p++){
var v=d*e+p,m=p*e+d,w=.5*(t.re[v][c]-r.re[v][c]+(t.re[m][c]-r.re[m][c])),g=.5*(t.im[v][c]-r.im[v][c]-(t.im[m][c]-r.im[m][c]));u[d*f+p]=w,u[(d+e)*f+p+e]=w,
u[(d+e)*f+p]=g,u[d*f+p+e]=-g}var y=yt(u,f),x=y.V;for(d=0;d<e;d++)for(p=0;p<e;p++){for(var M=0,b=0,A=0;A<f;A++){var k=y.ev[A];if(!(k<=0)){var F=Math.sqrt(k)
;M+=x[d*f+A]*F*x[p*f+A],b+=x[(d+e)*f+A]*F*x[p*f+A]}}s[d*e+p][c]=M,h[d*e+p][c]=b}}else s[0][c]=Math.sqrt(Math.max(t.re[0][c]-r.re[0][c],0))
;var S=[],C=new Float64Array(e),B=new Float64Array(e),I=a/2;for(d=0;d<e;d++)for(p=0;p<e;p++){var P=s[d*e+p];gt(P,h[d*e+p],a,!0)
;for(var z=new Float64Array(n*n),T=0;T<a;T++)for(var W=0;W<a;W++){var R=P[T*a+W];C[d]+=R*R;var G=(T+I)%a-I,j=(W+I)%a-I
;Math.abs(G)<=i&&Math.abs(j)<=i&&(z[(G+i)*n+j+i]=R,B[d]+=R*R)}S.push(z)}var q=1;for(d=0;d<e;d++){var L=Math.sqrt(C[d]/Math.max(B[d],1e-30))
;for(q=Math.min(q,B[d]/Math.max(C[d],1e-30)),p=0;p<e;p++)for(z=S[d*e+p],A=0;A<z.length;A++)z[A]*=L}return{h:S,kept:q}}(e[t],e[r],n),i=[]
;l.kept=Math.min(l.kept,o.kept);for(var f=0;f<n*n;f++){
for(var u=new Float64Array(F),c=new Float64Array(F),d=o.h[f],p=-s;p<=s;p++)for(var v=-s;v<=s;v++)u[(p+A)%A*A+(v+A)%A]=d[(p+s)*h+v+s];gt(u,c,A,!1),i.push({re:u,
im:c})}return l.kern[a]=i}(a,o),M=[],b=0;b<n;b++){for(var z=0;z<F;z++)B[z]=0,I[z]=0;for(var T=0;T<n;T++){var W=x[b*n+T].re,R=x[b*n+T].im;for(m=S[T],w=C[T],
z=0;z<F;z++)B[z]+=W[z]*m[z]-R[z]*w[z],I[z]+=W[z]*w[z]+R[z]*m[z]}gt(B,I,A,!0);var G=new Float32Array(k*k);for(g=0;g<k;g++)for(y=0;y<k;y++)G[g*k+y]=B[(g+s)*A+y+s]
;M.push(G)}return l.bytes+=n*k*k*4,P++,u[c]=M}for(var T=new Float32Array(k*k),W=0,R=Math.floor(c/k);R*k<f[3];R++)for(var G=Math.floor(u/k);G*k<f[2];G++){
var j=Math.max(G*k,u),q=Math.max(R*k,c),L=Math.min((G+1)*k,f[2],t.W),D=Math.min((R+1)*k,f[3],t.H);if(!(L<=j||D<=q)){
for(var H=Mt(t,r,v,1,[j,q,L,D]),E=L-j,V={},U=0,N=0;N<H.lab.length;N++){var O=H.lab[N],X=H.src[N]
;!(O<0||X<0||X===O)&&H.tgt[N]>1.0001*H.cur[N]&&(V[K=64*X+O]||(V[K]=!0,U++))}if(U){for(31&++W||i("  noise tiles: "+W),
x=q;x<D;x++)for(b=j;b<L;b++)T[(x-q)*E+b-j]=a?1-bt(a.prot,a.w,a.h,a.b,b,x):1;var _={done:!1};for(var K in V){
var Y=z(G,R,X=Math.floor(K/64),O=K%64,_),Z=Math.max(v[X]*v[X]-v[O]*v[O],1e-30),J=v[O]*v[O];for(x=q;x<D;x++)for(b=j;b<L;b++)if(N=(x-q)*E+b-j,
H.lab[N]===O&&H.src[N]===X&&H.tgt[N]>1.0001*H.cur[N])for(var $=Math.sqrt(Math.min(Math.max((H.tgt[N]*H.tgt[N]-J)/Z,0),1))*T[N],tt=(x-R*k)*k+b-G*k,rt=(x-c)*d+b-u,et=0;et<n;et++)m[et][rt]+=Y[et][tt]*$
}}}}return{chans:m,w:d,h:p,tiles:W,made:P,kept:l.kept,cacheMB:l.bytes/1048576}}function Bt(t,r){
for(var a=Math.floor(t.W/r),o=Math.floor(t.H/r),i=a*o,n=[],s=[],h=0;h<t.nc;h++){for(var f=l(t.chans[h],t.W,t.H,r).data,u=[],c=0;c<i;c+=7)0!==f[c]&&u.push(f[c])
;var d=e(u),p=Math.max(d.med-2.8*d.sigma,0),v=(d.med-p)/(1-p);s.push({c0:p,m:-.75*v/(-.5*v-.25)}),It(f,s[h]),n.push(f)}for(;n.length<3;)n.push(n[0]),
s.push(s[0]);return{w:a,h:o,b:r,rgb:n,stf:s}}function It(t,r){for(var e=r.c0,a=r.m,o=0;o<t.length;o++)if(0!==t[o]){var i=Math.min(Math.max((t[o]-e)/(1-e),0),1)
;t[o]=(a-1)*i/((2*a-1)*i-a)}return t}function Pt(t,r,e,a,o,i,n,s,h){
for(var l=Math.floor((e[2]-e[0])/a),f=Math.floor((e[3]-e[1])/a),u=l*f,c=1/(a*a),d=[],p=0;p<3;p++){var v=r[Math.min(p,t.nc-1)],m=new Float32Array(u)
;if(p>=t.nc)m.set(d[0]),d.push(m);else{for(var w=0;w<f;w++)for(var g=w*l,y=0;y<a;y++)for(var x=(e[1]+w*a+y)*t.W+e[0],M=0;M<l;M++){
for(var b=x+M*a,A=0,k=0;k<a;k++)A+=v[b+k];m[g+M]+=A}if(a>1)for(var F=0;F<u;F++)m[F]*=c;d.push(It(m,o[p]))}}var S=null,C=null;if(i)for(S=new Float32Array(u),
w=0;w<f;w++)for(M=0;M<l;M++)S[w*l+M]=bt(i.prot,i.w,i.h,i.b,e[0]+M*a+(a-1)/2,e[1]+w*a+(a-1)/2);return n&&(C=Mt(t,n,s,a,[e[0]/a,e[1]/a,e[0]/a+l,e[1]/a+f])),
(S||C)&&(d=function(t,r,e,a,o){
for(var i=Math.log(Math.max(o/a,1.0001)),n=t.w*t.h,s=[new Float32Array(n),new Float32Array(n),new Float32Array(n)],h=t.rgb,l=0;l<n;l++){
var f=h[0][l],u=h[1][l],c=h[2][l];if(e&&e.cur[l]>0){var d=Math.min(Math.max(Math.log(e.tgt[l]/a)/i,0),1),p=d<.5?.6-.6*d:.3-.6*(d-.5)
;f=.4*f+.6*(d<.5?.1:.1+1.8*(d-.5)),u=.4*u+.6*(.25+.7*d),c=.4*c+.6*Math.max(p,0)}r&&(f=.5*f+.65*r[l],u*=.5,c*=.5),s[0][l]=f>1?1:f,s[1][l]=u>1?1:u,s[2][l]=c>1?1:c
}return s}({w:l,h:f,rgb:d},S,C,Math.min.apply(null,s),Math.max.apply(null,s))),h&&function(t,r,e,a){
for(var o=r.w,i=Math.max(1,Math.round(a||1)),n=6*i,s=4*i,h=0;h<r.lab.length;h++){var l=r.lab[h];if(!(l<0)){
var f=e[l],u=r.edge[h],c=h%o,d=h/o|0,p=r.fo?r.fo[h]:-1,v=p>=0&&((c+d)/s|0)%2==0?.6:.3;p>=0&&(f=e[p]);for(var m=0;m<3;m++)t[m][h]=(1-v)*t[m][h]+v*f[m]
;if(r.ac&&!r.ac[h])for(m=0;m<3;m++)t[m][h]*=.35
;if(r.seam[h])for(m=0;m<3;m++)t[m][h]=.92;else if(u>=0&&((c+d)/n|0)%2==0)for(m=0;m<3;m++)t[m][h]=.25*t[m][h]+.75*e[u][m]}}}(d,function(t,r,e,a,o,i,n){
var s=Math.floor((r[2]-r[0])/e),h=Math.floor((r[3]-r[1])/e),l=s*h,f=e>>1,u=new Int8Array(l),c=new Uint32Array(l),d=new Uint8Array(l),p=new Int8Array(l),v=null,m=null,w=Q.G,g=t.cells.Wc
;if(i){v=new Int8Array(l);for(var y=0;y<l;y++)v[y]=-1}null!=n&&n>=0&&(m=new Uint8Array(l));for(var x=0;x<h;x++){
for(var M=(r[1]+x*e+f)*t.W+r[0]+f,b=0;b<s;b++)u[x*s+b]=t.labf[M+b*e],c[x*s+b]=t.cov[M+b*e];var A=((r[1]+x*e+f)/w|0)*g
;if(o)for(b=0;b<s;b++)u[x*s+b]=dt(t,o[A+((r[0]+b*e+f)/w|0)],c[x*s+b]);if(v)for(b=0;b<s;b++)v[x*s+b]=i[A+((r[0]+b*e+f)/w|0)]
;if(m)for(b=0;b<s;b++)m[x*s+b]=c[x*s+b]>>>n&1}var k=Math.max(1,Math.round(a||1)),F=t.sig.length;for(x=0;x<h;x++)for(b=0;b<s;b++){var S=u[y=x*s+b],C=c[y]
;if(p[y]=-1,!(S<0)){var B=b+k<s?u[y+k]:-1,I=x+k<h?u[y+k*s]:-1;(B>=0&&B!==S||I>=0&&I!==S)&&(d[y]=1);var P=0;if(b>=k&&(P|=C&~c[y-k]),b+k<s&&(P|=C&~c[y+k]),
x>=k&&(P|=C&~c[y-k*s]),x+k<h&&(P|=C&~c[y+k*s]),P)for(var z=0;z<F;z++)if(P&1<<z){p[y]=z;break}}}return{w:s,h,lab:u,seam:d,edge:p,fo:v,ac:m}
}(t,e,a,h.lw,h.label,h.forced,h.active),h.colors,h.lw),{w:l,h:f,rgb:d}}function zt(t,r){
for(var e=r||t.cells.label,a=t.cells.Wc,o=t.cells.Hc,i=Q.G,n=a+2,s=o+2,h=[],l=0,f=0;f<a*o;f++)e[f]>=0&&l++;for(var u=0;u<t.sig.length;u++){
for(var c=new Uint8Array(n*s),d=0,p=0;p<s;p++)for(var v=0;v<n;v++){var m=v>0&&p>0&&v<n-1&&p<s-1&&e[(p-1)*a+v-1]===u;c[p*n+v]=m?0:1,m&&d++}if(d){
var w=lt(c,n,s),g=0;for(f=1;f<w.length;f++)w[f]>w[g]&&(g=f);h.push({k:u,x:(g%n-1+.5)*i,y:((g/n|0)-1+.5)*i,area:d/Math.max(l,1)})}}return h}function Tt(t,r){
for(var e=Q.G,a=t.cells.Wc,o=t.cells.Hc,i=new Int8Array(a*o),n=t.cut.valid,s=0;s<i.length;s++)i[s]=-1;for(var h=0;h<r.length;h++){var l=r[h]
;if(void 0===l.clear){var f=l.erase?0:l.k+1,u=l.r,c=u*u,d=l.pts,p=function(t,r){
for(var s=Math.max(0,Math.floor((t-u)/e)),h=Math.min(a-1,Math.floor((t+u)/e)),l=Math.max(0,Math.floor((r-u)/e)),d=Math.min(o-1,Math.floor((r+u)/e)),p=l;p<=d;p++)for(var v=s;v<=h;v++){
var m=(v+.5)*e-t,w=(p+.5)*e-r,g=p*a+v;m*m+w*w>c||(0===f?i[g]=-1:n[f-1][g]&&(i[g]=f-1))}};p(d[0],d[1])
;for(var v=2;v+1<d.length;v+=2)for(var m=d[v-2],w=d[v-1],g=d[v]-m,y=d[v+1]-w,x=Math.max(1,Math.ceil(Math.sqrt(g*g+y*y)/Math.max(u/3,e/2))),M=1;M<=x;M++)p(m+g*M/x,w+y*M/x)
}else for(s=0;s<i.length;s++)i[s]===l.clear&&(i[s]=-1)}return i}function Wt(t,r,e){
for(var a=t.cut,o=a.D,i=o.length,n=r.length,s=[],h=new Int32Array(a.auto),l=0,f=0;f<n;f++){var u=r[f];if(!(u<0||h[f]<0)){
for(var c=0;c<i;c++)s.push(c,f,o[c][f]),o[c][f]=c===u?0:1/0;h[f]=u,l++}}if(!l)return h;try{return tt(o,a.wh,a.wv,h,t.cells.Wc,t.cells.Hc,Q.sweeps,e).label
}finally{for(var d=0;d<s.length;d+=3)o[s[d]][s[d+1]]=s[d+2]}}function Rt(t){
for(var r=t.W,e=t.H,a=t.union,o=new Int32Array(r),i=new Int32Array(r+1),n=0,s=[0,0,r,e],h=0;h<e;h++){for(var l=h*r,f=0,u=0;u<r;u++)o[u]=a[l+u]?o[u]+1:0
;for(u=0;u<=r;u++){for(var c=u<r?o[u]:0;f>0&&o[i[f-1]]>=c;){var d=o[i[--f]],p=f>0?i[f-1]+1:0,v=d*(u-p);v>n&&(n=v,s=[p,h-d+1,u,h+1])}i[f++]=u}}return s}
function Gt(t,r){var e=t.bg;if(e)for(var a=0;a<t.nc;a++)for(var o=t.chans[a],i=e.chans[a],n=r[1];n<r[3];n++){
var s=(n+.5)/e.f-.5,h=Math.min(Math.max(Math.floor(s),0),e.h-2),l=s-h;e.h<2&&(h=0,l=0);for(var f=r[0];f<r[2];f++){var u=n*t.W+f;if(t.union[u]){
var c=(f+.5)/e.f-.5,d=Math.min(Math.max(Math.floor(c),0),e.w-2),p=c-d;e.w<2&&(d=0,p=0)
;var v=h*e.w+d,m=e.h>1?v+e.w:v,w=e.w>1?1:0,g=i[v]+p*(i[v+w]-i[v]),y=i[m]+p*(i[m+w]-i[m]);o[u]-=g+l*(y-g)}}}}
var jt="AutoPano",qt="1.0.3",Lt="AutoPano",Dt=[[1,"https://api.bepaid.by/products/prd_e9ae5ef19bddc47d/pay"],[3,"https://api.bepaid.by/products/prd_29731c50851f55a8/pay"],[5,"https://api.bepaid.by/products/prd_f2c63d66f7cfe15b/pay"],[10,"https://api.bepaid.by/products/prd_424196484db864d0/pay"]]
;class Ht extends Error{}function Et(){if(CoreApplication.processEvents(),console.abortRequested)throw new Ht("Aborted by the user.")}function Vt(t,r){
let e=t.keywords;for(let t=0;t<e.length;++t)if(e[t].name===r){let r=e[t].strippedValue.trim(),a=parseFloat(r);return isFinite(a)?a:r}return null}
function Ut(t,r){let e=new ImageSolver;e.initialize(t,!1);let a=e.solverCfg;if(a.showStars=!1,a.showStarMatches=!1,a.showSimplifiedSurfaces=!1,
a.showDistortion=!1,a.generateErrorImg=!1,a.generateDistortModel=!1,a.distortionCorrection=!0,r&&(e.metadata.ra=r.ra,e.metadata.dec=r.dec),
!(e.metadata.resolution||e.metadata.focal&&e.metadata.xpixsz))throw new Error(t.mainView.id+" has no astrometric solution, and its header has no focal length / pixel size for plate solving. Solve it with ImageSolver first.")
;try{e.solveImage(t)}catch(t){return console.warningln("   ImageSolver: "+String(t&&t.message?t.message:t)),!1}return t.hasAstrometricSolution}function Nt(t,r){
let e=t.mainView.image,a=e.width,o=e.height,i=Math.ceil((a-1)/r)+3,n=Math.ceil((o-1)/r)+3,s=i*n,h=new Float64Array(s),l=new Float64Array(s)
;for(let t=0;t<n;++t)for(let e=0;e<i;++e)h[t*i+e]=(e-1)*r+.5,l[t*i+e]=(t-1)*r+.5;let f=new Float64Array(s),u=new Float64Array(s),c=0,d=null;try{
d=t.imageToCelestial(h,l,!0)}catch(t){d=null}for(let r=0;r<s;++r){if(d&&d.length===2*s)f[r]=d[2*r],u[r]=d[2*r+1];else{let e=null;try{
e=t.imageToCelestial(h[r],l[r])}catch(t){e=null}f[r]=e?e.x:NaN,u[r]=e?e.y:NaN}isFinite(f[r])&&isFinite(u[r])||++c}if(c>0){
for(let t=0;t<2;++t)for(let t=0;t<n;++t)for(let r=0;r<i;++r){let e=t*i+r;if(isFinite(f[e])&&isFinite(u[e]))continue
;let a=0===r?1:r===i-1?-1:0,o=0===t?1:t===n-1?-1:0,s=e+o*i+a,h=e+2*(o*i+a);if((a||o)&&isFinite(f[s])&&isFinite(f[h])){let t=f[s]-f[h]
;t>180?t-=360:t<-180&&(t+=360),f[e]=f[s]+t,u[e]=2*u[s]-u[h]}}
for(let r=0;r<s;++r)if(!isFinite(f[r])||!isFinite(u[r]))throw new Error("Cannot evaluate the astrometric solution of "+t.mainView.id+" near its borders.")}
return{step:r,nx:i,ny:n,ra:f,dec:u}}function Ot(t){let r=t.mainView.image,a=r.width,o=r.height,i=[]
;for(let t=0;t<r.numberOfChannels;++t)i.push(r.toFloat32Array(new Rect(0,0,a,o),t));let n=0,s=0;for(let r=0;r<i.length;++r){let e=Vt(t,format("NOISE%02d",r))
;"number"==typeof e&&e>0&&(n+=e,++s)}return n=s===i.length?n/s:function(t,r,a){for(var o=0,i=0;i<t.length;i++){
for(var n=t[i],s=[],h=0;h+1<a;h+=2)for(var l=0;l+1<r;l+=2){var f=h*r+l,u=n[f],c=n[f+1],d=n[f+r],p=n[f+r+1];0!==u&&0!==c&&0!==d&&0!==p&&s.push((u-c-d+p)/2)}
o+=e(s).sigma}return o/t.length}(i,a,o),{id:t.mainView.id,w:a,h:o,chans:i,noise:n,grid:Nt(t,32)}}function Xt(){try{
let t=File.homeDirectory+"/AppData/Local/GraXpertScript/GraXpertPath.txt";if(File.exists(t)){let r=File.readTextFile(t).trim()
;if(r.length&&File.exists(r))return r}let r=File.homeDirectory+"/AppData/Local/Programs/GraXpert/GraXpert.exe";if(File.exists(r))return r}catch(t){}return null}
function _t(t,r,e){let a=File.systemTempDirectory+"/AutoPano_gx_"+r.mainView.id,o=a+".xisf",i=a+"_bg.xisf";for(let t of[o,i])File.exists(t)&&File.remove(t)
;let n=r.mainView.image,s=new ImageWindow(n.width,n.height,n.numberOfChannels,32,!0,n.isColor,"AutoPano_gx_tmp");try{
if(s.mainView.beginProcess(UndoFlag.NoSwapFile),s.mainView.image.assign(n),s.mainView.endProcess(),
!s.saveAs(o,!1,!1,!1,!1))throw new Error("could not write "+o)}finally{s.forceClose()}
let h='"'+File.unixPathToWindows(t)+'" -cli -cmd background-extraction -correction Subtraction -smoothing 0.046 -output "'+File.unixPathToWindows(a+"_bg")+'" "'+File.unixPathToWindows(o)+'"'
;console.writeln("   "+h);let l=new ExternalProcess,f="";for(l.onStandardErrorDataAvailable=function(){f+=String(this.stderr)},
l.start(h);l.isStarting;)CoreApplication.processEvents();for(;l.isRunning;)if(CoreApplication.processEvents(),console.abortRequested)throw l.kill(),
new Ht("aborted")
;if(File.exists(o)&&File.remove(o),!File.exists(i))throw new Error("GraXpert failed on "+r.mainView.id+(f?": "+f.slice(-400):"")+". Untick 'Remove gradients with GraXpert' to build without it.")
;let u=ImageWindow.open(i);try{let t=u[0].mainView.image
;if(t.width!==e.w||t.height!==e.h||t.numberOfChannels!==e.chans.length)throw new Error("GraXpert returned a different image size for "+r.mainView.id)
;for(let r=0;r<e.chans.length;++r)e.chans[r]=t.toFloat32Array(new Rect(0,0,e.w,e.h),r)}finally{for(let t of u)t.forceClose();File.remove(i)}}function Kt(t,e){
let a=File.systemTempDirectory+"/AutoPano_gx_mosaic",o=a+".xisf",i=a+"_bg.xisf";for(let t of[o,i])File.exists(t)&&File.remove(t);let n=function(t,r,e){
for(var a=Math.ceil(r/8),o=Math.ceil(e/8),i=[],n=0;n<t.length;n++){
for(var s=t[n],h=new Float64Array(a*o),l=new Float64Array(a*o),f=new Float32Array(a*o),u=0;u<e;u++)for(var c=Math.floor(u/8)*a,d=0;d<r;d++)h[p=c+Math.floor(d/8)]+=s[u*r+d],
l[p]++;for(var p=0;p<f.length;p++)f[p]=h[p]/l[p];i.push(f)}return i}(function(t,e){e=e||16
;for(var a=Math.ceil(t.W/e),o=Math.ceil(t.H/e),i=[],n=new Float64Array(e*e),s=0;s<t.nc;s++){
for(var h=t.chans[s],l=new Float32Array(a*o),f=new Float32Array(a*o),u=0;u<o;u++)for(var c=0;c<a;c++){
for(var d=0,p=u*e;p<Math.min((u+1)*e,t.H);p++)for(var v=c*e;v<Math.min((c+1)*e,t.W);v++){var m=p*t.W+v;t.union[m]&&(n[d++]=h[m])}d>e*e/4&&(l[u*a+c]=r(n,d),
f[u*a+c]=1)}var w=ct(l,f,a,o),g=new Float32Array(t.W*t.H);for(p=0;p<t.H;p++){
var y=Math.min(Math.max((p+.5)/e-.5,0),o-1),x=Math.min(Math.floor(y),Math.max(o-2,0)),M=o>1?y-x:0;for(v=0;v<t.W;v++){var b;if(m=p*t.W+v,t.union[m])b=h[m];else{
var A=Math.min(Math.max((v+.5)/e-.5,0),a-1),k=Math.min(Math.floor(A),Math.max(a-2,0)),F=a>1?A-k:0,S=x*a+k,C=o>1?S+a:S,B=a>1?1:0,I=w[S]+F*(w[S+B]-w[S])
;b=I+M*(w[C]+F*(w[C+B]-w[C])-I)}g[m]=b<0?0:b>1?1:b}}i.push(g)}return i
}(e,16),e.W,e.H),s=Math.ceil(e.W/8),h=Math.ceil(e.H/8),l=new ImageWindow(s,h,e.nc,32,!0,e.nc>1,"AutoPano_gx_tmp");try{
l.mainView.beginProcess(UndoFlag.NoSwapFile);for(let t=0;t<e.nc;++t)l.mainView.image.setSamples(n[t],new Rect(0,0,s,h),t);if(l.mainView.endProcess(),
!l.saveAs(o,!1,!1,!1,!1))throw new Error("could not write "+o)}finally{l.forceClose()}
let f='"'+File.unixPathToWindows(t)+'" -cli -cmd background-extraction -correction Subtraction -smoothing 0.046 -output "'+File.unixPathToWindows(a+"_bg")+'" "'+File.unixPathToWindows(o)+'"'
;console.writeln("   "+f);let u=new ExternalProcess,c="";for(u.onStandardErrorDataAvailable=function(){c+=String(this.stderr)},
u.start(f);u.isStarting;)CoreApplication.processEvents();for(;u.isRunning;)if(CoreApplication.processEvents(),console.abortRequested)throw u.kill(),
new Ht("aborted")
;if(File.exists(o)&&File.remove(o),!File.exists(i))throw new Error("GraXpert failed"+(c?": "+c.slice(-400):"")+". Untick 'Remove gradients with GraXpert' to build without it.")
;let d=ImageWindow.open(i);try{let t=d[0].mainView.image
;if(t.width!==s||t.height!==h||t.numberOfChannels!==e.nc)throw new Error("GraXpert returned a different image size");let r=[];for(let a=0;a<e.nc;++a){
let e=t.toFloat32Array(new Rect(0,0,s,h),a),o=new Float32Array(s*h);for(let t=0;t<o.length;++t)o[t]=n[a][t]-e[t];r.push(o)}!function(t,r,e){
for(var a=Math.ceil(t.W/e),o=Math.ceil(t.H/e),i=new Float32Array(a*o),n=[],s=0;s<t.H;s++)for(var h=0;h<t.W;h++)t.union[s*t.W+h]&&(i[Math.floor(s/e)*a+Math.floor(h/e)]=1)
;for(var l=0;l<r.length;l++)n.push(ct(r[l],i,a,o));t.bg={w:a,h:o,f:e,chans:n},Gt(t,[0,0,t.W,t.H])}(e,r,8)}finally{for(let t of d)t.forceClose();File.remove(i)}}
function Yt(t,n){n=n||{};let f=new ElapsedTime,u=t=>{console.writeln(format("%7.1f s  ",f.value)+t),Et()};!function(t){
if(t.length<2)throw new Error("Tick at least two panels.");if(t.length>32)throw new Error("At most 32 panels per mosaic ("+t.length+" ticked).")
;let r=t[0].mainView.image.numberOfChannels,e=[];for(let a of t){let t=a.mainView.image
;if(t.numberOfChannels!==r)throw new Error("All panels must be either colour or mono ("+a.mainView.id+" differs). Build mono filters one at a time.")
;t.median()>.25&&e.push(a.mainView.id+format(" (median %.3f)",t.median()))}if(e.length&&(console.warningln("** Not linear? "+e.join(", ")),
new MessageBox("<p>These panels do not look linear (unstretched): "+e.join(", ")+".</p><p>AutoPano is made for linear masters: photometry and noise matching assume linear data, so a stretched mosaic may show seams. Continue anyway?</p>",jt,StdIcon.Warning,StdButton.Yes,StdButton.No).execute()!==StdButton.Yes))throw new Ht("cancelled: non-linear panels")
}(t);let d=function(t){let r=t.filter(t=>!t.hasAstrometricSolution);if(0===r.length)return[]
;console.noteln("<end><cbr>Plate solving "+r.length+" panel(s) without an astrometric solution");let e=[];for(let t of r)Et(),
console.writeln("   "+t.mainView.id+" ..."),Ut(t,null)?console.noteln("   "+t.mainView.id+": solved"):e.push(t);if(0===e.length)return[]
;if(e.length===t.length)throw new Error("ImageSolver could not solve any panel from the header coordinates. Solve at least one panel with ImageSolver (with corrected coordinates) and run AutoPano again: the others are then placed on it by their stars.")
;console.noteln("<end><cbr>Placing "+e.length+" unsolved panel(s) on solved neighbours by star patterns");let a=new Map,o=t=>(a.has(t)||a.set(t,function(t){
let r=t.mainView.image,e=r.width,a=r.height,o=[];for(let t=0;t<r.numberOfChannels;++t)o.push(r.toFloat32Array(new Rect(0,0,e,a),t));return A(h(o,e,a),e,a)}(t)),
a.get(t)),i=new Set;for(let r=!0;r&&e.length>0;){r=!1;for(let a of e.slice()){let n=a.mainView.image,s=!1;for(let r of t.filter(t=>t.hasAstrometricSolution)){
let t=a.mainView.id+"|"+r.mainView.id;if(i.has(t))continue;i.add(t),Et();let e=G(o(r),o(a));if(!e)continue
;let h=(n.width-1)/2,l=(n.height-1)/2,f=r.imageToCelestial(e.a*h+e.b*l+e.tx+.5,e.c*h+e.d*l+e.ty+.5)
;if(f&&(console.writeln(format("   %s: %d stars matched with %s, centre RA %.4f Dec %.4f - solving",a.mainView.id,e.n,r.mainView.id,f.x,f.y)),Ut(a,{ra:f.x,
dec:f.y}))){s=!0;break}}s&&(console.noteln("   "+a.mainView.id+": solved"),e.splice(e.indexOf(a),1),r=!0)}}
if(t.length-e.length<2)throw new Error("Only one panel could be plate-solved. Solve the others with ImageSolver (with corrected coordinates) and run AutoPano again.")
;for(let t of e)console.warningln("** "+t.mainView.id+": could not be plate-solved - left out of the mosaic");return e.map(t=>({win:t,
reason:"could not be plate-solved (no star match with a solved panel, or ImageSolver failed): solve it with ImageSolver and build again"}))}(t).map(t=>({
id:t.win.mainView.id,reason:t.reason}));t=t.filter(t=>t.hasAstrometricSolution),console.noteln("<end><cbr>Reading "+t.length+" panels");let p=[]
;for(let r of t)p.push(Ot(r)),Et();let v=n.graxpert?function(){let t=File.homeDirectory+"/AppData/Local/GraXpertScript",r=t+"/GraXpertPath.txt",e=Xt()
;if(e)return e
;new MessageBox("<p>GraXpert was not found. Select GraXpert.exe (it is remembered for AutoPano and PixInsight's GraXpert scripts).</p>",jt,StdIcon.Information,StdButton.Ok).execute()
;let a=new OpenFileDialog;if(a.caption=jt+": select GraXpert",a.filters=[["GraXpert","GraXpert*.exe"],["All files","*"]],
!a.execute())throw new Ht("GraXpert not selected");try{File.directoryExists(t)||File.createDirectory(t,!0),File.writeTextFile(r,a.fileName)}catch(t){}
return a.fileName}():null;if(v){console.noteln("<end><cbr>GraXpert on the panels with enough empty sky");for(let r=0;r<p.length;++r){
let e=J(p[r].chans,p[r].w,p[r].h)
;e>=j.gxSky?(_t(v,t[r],p[r]),u(format("  GraXpert: %s (%.0f%% empty sky)",p[r].id,100*e))):u(format("  %s: only %.0f%% empty sky (a large object fills it) - left to the pass over the whole mosaic",p[r].id,100*e)),
Et()}}let m=p.map(t=>t.id),w=t[0].mainView.image.isColor;console.noteln("Geometry");let g=P(p,{log:u,crop:!0});d=d.concat(g.excluded),p=g.used.map(t=>p[t]),
m=p.map(t=>t.id);let y=0;!function(t,r,e){var a=(e=e||{}).log||function(){};t.rep=[];for(var o=0;o<r.length;o++){
var i=Date.now(),n=B(r[o],t.trims[o],3),s=I(t,r[o],o,n,e.progress?function(t){e.progress(r[o].id,t)}:null);t.rep.push(s),e.keep||(r[o].chans=null),
a("  reprojected "+r[o].id+" -> box "+s.box.join(",")+" ("+((Date.now()-i)/1e3).toFixed(1)+" s)")}t.rep}(g,p,{log:u,progress:(t,r)=>{f.value-y>.5&&(y=f.value,
Et())}}),console.noteln("Photometry");let x=function(t,e,a){
var n=(a=a||{}).log||function(){},l=j,f=l.bin,u=e.length,c=t.ref,d=t.W,p=t.H,v=Math.ceil(d/f),m=Math.ceil(p/f),w=v*m,g=t.rep[0].chans.length,y=[],x=a.vignetting||"auto"
;function M(r,a,i){var n=t.corrs?t.corrs[r].invert(a,i):[a,i],s=t.maps[r].inv(n[0],n[1]),h=(e[r].w-1)/2,l=(e[r].h-1)/2;return o(s[0]-h,s[1]-l)/o(h,l)}
y.push("Panels: "+u+", reference: "+e[c].id+"; mode: "+(a.keepGradients?"keep gradients":"flatten")+"; bins "+f+" px"),y.push("")
;for(var b={},A=0;A<u;A++)for(var k=A+1;k<u;k++){
for(var F=t.stars[A],S=t.stars[k],C={},B=[],I=0;I<S.x.length;I++)(C[pt=Math.floor(S.x[I]/2)+","+Math.floor(S.y[I]/2)]||(C[pt]=[])).push(I)
;for(I=0;I<F.x.length;I++){for(var P=Math.floor(F.x[I]/2),z=Math.floor(F.y[I]/2),R=-1,G=1.5,q=-1;q<=1;q++)for(var L=-1;L<=1;L++){var D=C[P+L+","+(z+q)]
;if(D)for(var J=0;J<D.length;J++){var Q=o(S.x[D[J]]-F.x[I],S.y[D[J]]-F.y[I]);Q<G&&(G=Q,R=D[J])}}R>=0&&B.push([(F.x[I]+S.x[R])/2,(F.y[I]+S.y[R])/2])}
B.length>=3&&(b[A+","+k]=B)}for(var $=[],tt=[],rt=[],et={},at=0;at<u;at++){
var ot=t.rep[at],it=Date.now(),nt=H(kr=h(ot.chans,ot.w,ot.h),ot.mask,ot.w,ot.h,0,!0),st=nt.obj;kr=null;var ht=new Uint8Array(ot.w*ot.h)
;for(A=0;A<ht.length;A++)ht[A]=ot.mask[A]&&!st[A]?1:0;$.push(E(ot,ht,v,m));var lt=new Uint8Array(ot.w*ot.h)
;for(A=0;A<lt.length;A++)lt[A]=ot.mask[A]&&!nt.compact[A]?1:0;tt.push(E(ot,lt,v,m)),st=nt=lt=null;for(var ft=V(ot,ht),ut=0,ct=0;ct<g;ct++)ut+=ft[ct]/g;var dt=[]
;for(ct=0;ct<g;ct++)dt.push(ft[ct]/ut*e[at].noise);for(var pt in rt.push(dt),b)+(bt=pt.split(","))[0]!==at&&+bt[1]!==at||(et[pt+"|"+at]=U(ot,b[pt]))
;n("  photometry pass 1: "+e[at].id+" ("+((Date.now()-it)/1e3).toFixed(1)+" s)")}var vt=[];for(at=0;at<u;at++){
for(var mt=0,wt=0,gt=0;gt<w;gt++)$[at][0][gt]==$[at][0][gt]&&mt++,tt[at][0][gt]==tt[at][0][gt]&&wt++;vt.push(wt?mt/wt:1)}
for(y.push(T("panel",10)+" "+function(){for(var t=[],r=0;r<g;r++)t.push(T("noise_"+r,10));return t.join("  ")}()),
at=0;at<u;at++)y.push(T(e[at].id,10)+" "+rt[at].map(function(t){return T(t.toExponential(3),10)}).join("  "));y.push("");var yt=[],xt={}
;for(at=0;at<u;at++)at!==c&&(xt[at]=yt.length,yt.push(at));var Mt=[];for(var pt in b){A=+(bt=pt.split(","))[0],k=+bt[1];var bt,At=et[pt+"|"+A],kt=et[pt+"|"+k]
;for(B=b[pt],I=0;I<B.length;I++){var Ft=At.flux[I],St=kt.flux[I],Ct=Math.max(At.peak[I],kt.peak[I])<.5,Bt=1/0;for(ct=0;ct<g&&Ct;ct++){if(!(Ft[ct]>0&&St[ct]>0)){
Ct=!1;break}var It=Math.sqrt(Math.PI*l.apR*l.apR)*Math.max(rt[A][ct],rt[k][ct]);Math.min(Ft[ct],St[ct])<=30*It&&(Ct=!1),
Bt=Math.min(Bt,Math.min(Ft[ct],St[ct])/It)}if(Ct){var Pt=[];for(ct=0;ct<g;ct++)Pt.push(Math.log(Ft[ct])-Math.log(St[ct]));Mt.push({i:A,j:k,
ri:M(A,B[I][0],B[I][1]),rj:M(k,B[I][0],B[I][1]),lr:Pt,snr:Bt})}}}var zt=0;for(var pt in b)zt++
;if(y.push("Scale from "+Mt.length+" star measurements in "+zt+" pairs (aperture r="+l.apR+" px, SNR > 30)."),
Mt.length<3*yt.length)throw new Error("Too few stars shared by the overlaps for photometry ("+Mt.length+").");function Tt(t){
for(var r=yt.length+(t?2:0),e=[],a=[],o=0;o<Mt.length;o++){var n=Mt[o],h=i(r);void 0!==xt[n.i]&&(h[xt[n.i]]+=1),void 0!==xt[n.j]&&(h[xt[n.j]]-=1),
t&&(h[r-2]=n.ri*n.ri-n.rj*n.rj,h[r-1]=Math.pow(n.ri,4)-Math.pow(n.rj,4)),e.push(h);var l=Math.min(n.snr,300);a.push(l*l/100)}for(var f=[],u=0;u<g;u++){
var c=Mt.map(function(t){return t.lr[u]}),d=N(e,c,a,3,3),p=0,v=0,m=0,w=new s(r,1);for(o=0;o<Mt.length;o++)if(d.keep[o]){l=0
;for(var y=0;y<r;y++)l+=e[o][y]*d.coef[y];var x=c[o]-l;p+=x*x,v+=a[o]*x*x,m++,w.add(new Float64Array(e[o]),[0],a[o])}v/=Math.max(m-r,1);var M=O(w.M,r);f.push({
coef:d.coef,rms:Math.sqrt(p/Math.max(m,1)),inv:M,chi:v})}return f}var Wt=Tt(!1),Rt=Tt(!0),Gt=yt.length+2,jt=[],qt=[],Lt=!0;for(ct=0;ct<g;ct++){
var Dt=Rt[ct].coef[Gt-2],Ht=Rt[ct].coef[Gt-1],Et=Rt[ct].inv,Vt=Rt[ct].chi,Ut=Math.sqrt((Et[Gt-2][Gt-2]+Et[Gt-1][Gt-1]+2*Et[Gt-1][Gt-2])*Vt)
;jt.push(Math.exp(Dt+Ht)-1),qt.push(Ut),Math.abs(jt[ct])>l.vigMin&&Math.abs(jt[ct])>3*Ut||(Lt=!1)}var Nt="on"===x||"auto"===x&&Lt,Ot=Nt?Rt:Wt,Xt=[],_t=[]
;for(at=0;at<u;at++){var Kt=[];for(ct=0;ct<g;ct++)Kt.push(1);Xt.push(Kt)}for(ct=0;ct<g;ct++){for(I=0;I<yt.length;I++)Xt[yt[I]][ct]=Math.exp(Ot[ct].coef[I])
;_t.push(Nt?[Ot[ct].coef[Gt-2],Ot[ct].coef[Gt-1]]:[0,0])}for(y.push("  log-ratio rms: no vignetting "+Wt.map(function(t){return t.rms.toFixed(4)
}).join(" ")+" | with vignetting "+Rt.map(function(t){return t.rms.toFixed(4)}).join(" ")),
y.push("  vignetting model at the sensor corner: "+jt.map(function(t,r){return(t>=0?"+":"")+(100*t).toFixed(2)+"+-"+(100*qt[r]).toFixed(2)+"%"
}).join(" ")+" -> "+(Nt?"APPLIED":"not applied (not significant in all channels)")),ct=0;ct<g;ct++)y.push("  ch"+ct+" scale errors: "+yt.map(function(t,r){
return e[t].id+" "+(100*Math.sqrt(Ot[ct].inv[r][r]*Ot[ct].chi)).toFixed(2)+"%"}).join(" "))
;for(at=0;at<u;at++)y.push("  "+T(e[at].id,10)+" "+Xt[at].map(function(t){return t.toFixed(4)}).join(" ")+(at===c?"   (reference)":""));function Yt(t,r){
return Math.exp(_t[r][0]*t*t+_t[r][1]*t*t*t*t)}y.push("");var Zt=[];for(at=0;at<u;at++){var Jt=null;if(Nt)for(Jt=new Float32Array(w),
gt=0;gt<w;gt++)$[at][0][gt]==$[at][0][gt]&&(Jt[gt]=M(at,gt%v*f+f/2,Math.floor(gt/v)*f+f/2));Zt.push(Jt)}var Qt=[];for(at=0;at<u;at++){var $t=[]
;for(ct=0;ct<g;ct++){Kt=new Float32Array(w);var tr=$[at][ct];for(gt=0;gt<w;gt++)Kt[gt]=tr[gt]/(Xt[at][ct]*(Nt?Yt(Zt[at][gt],ct):1));$t.push(Kt)}Qt.push($t)}
var rr=[];for(at=0;at<u;at++){for($t=[],ct=0;ct<g;ct++){for(Kt=new Float32Array(w),tr=tt[at][ct],
gt=0;gt<w;gt++)Kt[gt]=tr[gt]/(Xt[at][ct]*(Nt&&tr[gt]==tr[gt]?Yt(M(at,gt%v*f+f/2,Math.floor(gt/v)*f+f/2),ct):1));$t.push(Kt)}rr.push($t)}function er(t,r){
return rt[t][r]/Xt[t][r]}function ar(t,a){y.push(a);for(var o=T("  pair",24)+" "+W("bins",5)+" |",i=0;i<g;i++)o+=" ch"+i+" med  p90   b95  |";y.push(o)
;for(var n=[],s=0;s<u;s++)for(var h=s+1;h<u;h++){for(var l=0,f=0;f<w;f++)t[s][0][f]==t[s][0][f]&&t[h][0][f]==t[h][0][f]&&l++;if(!(l<20)){
var c=T("  "+e[s].id+"-"+e[h].id,24)+" "+W(String(l),5)+" |";for(i=0;i<g;i++){var d=[],p=[],x=Math.max(er(s,i),er(h,i)),M=new Float64Array(w);for(f=0;f<w;f++){
var b=t[s][i][f],A=t[h][i][f];b==b&&A==A&&t[s][0][f]==t[s][0][f]&&t[h][0][f]==t[h][0][f]?(d.push(b-A),p.push(Math.abs(b-A)),M[f]=b-A):M[f]=NaN}
for(var k=Y(M,v,m,8),F=0;F<k.length;F++)k[F]=Math.abs(k[F]);var S=Math.abs(r(d))/x
;c+=" "+W(S.toFixed(2),5)+" "+W((Z(p,90)/x).toFixed(2),5)+" "+W(k.length?(Z(k,95)/x).toFixed(2):"nan",5)+" |",n.push(S)}y.push(c)}}var C=0
;for(F=0;F<n.length;F++)C+=n[F]/n.length;return y.push("  mean |median step| = "+C.toFixed(3)+" sigma"),y.push(""),C}tt=null,
y.push("Overlap sky difference in units of pixel noise (sigma): |median|, 90th pct of |diff| per "+f+"x"+f+" bin; b95 = 95th pct of |mean diff| over "+8*f+" px blocks (local steps)."),
y.push(""),ar($,"A. raw:"),ar(Qt,"B. after scale"+(Nt?" + vignetting":"")+":");var or=(l.bgDeg+1)*(l.bgDeg+2)/2,ir=[],nr=[],sr=[],hr=[],lr=[]
;for(at=0;at<u;at++){var fr=t.rep[at].box;nr.push([(fr[0]+fr[2])/2,(fr[1]+fr[3])/2,Math.max(fr[2]-fr[0],fr[3]-fr[1])/2]);var ur=[]
;for(ct=0;ct<g;ct++)ur.push(new Float32Array(Qt[at][ct]));sr.push(ur);var cr=[];for(ct=0;ct<g;ct++)cr.push(new Float32Array(rr[at][ct]));hr.push(cr);var dr=[]
;for(ct=0;ct<g;ct++)dr.push(i(or));ir.push(dr)}for(ct=0;ct<g;ct++){var pr=[];for(gt=0;gt<w;gt++)Qt[c][ct][gt]==Qt[c][ct][gt]&&pr.push(Qt[c][ct][gt])
;lr.push(r(pr))}var vr=[];if(!a.keepGradients){for(at=0;at<u;at++){var mr=[],wr=[];for(gt=0;gt<w;gt++)Qt[at][0][gt]==Qt[at][0][gt]&&(mr.push(gt),
wr.push(K((gt%v*f+f/2-nr[at][0])/nr[at][2],(Math.floor(gt/v)*f+f/2-nr[at][1])/nr[at][2],l.bgDeg)));for(ct=0;ct<g;ct++){var gr=mr.map(function(t){
return Qt[at][ct][t]}),yr=N(wr,gr,null,3,2);for(ir[at][ct]=Array.prototype.slice.call(yr.coef),I=0;I<mr.length;I++){for($t=0,
J=0;J<or;J++)$t+=wr[I][J]*yr.coef[J];sr[at][ct][mr[I]]=Qt[at][ct][mr[I]]-$t+lr[ct]}var xr=hr[at][ct],Mr=rr[at][ct];for(gt=0;gt<w;gt++)if(Mr[gt]==Mr[gt]){
var br=K((gt%v*f+f/2-nr[at][0])/nr[at][2],(Math.floor(gt/v)*f+f/2-nr[at][1])/nr[at][2],l.bgDeg);for($t=0,J=0;J<or;J++)$t+=br[J]*yr.coef[J]
;xr[gt]=Mr[gt]-$t+lr[ct]}}}ar(sr,"C. after per-panel background flattening (degree "+l.bgDeg+"):"),
y.push("Background structure left after the polynomial (p95 of |mean| over "+8*f+" px blocks, sigma):");var Ar=0;for(ct=0;ct<g;ct++)Ar+=lr[ct]/g
;for(at=0;at<u;at++){var kr=new Float64Array(w),Fr=0;if(vt[at]<l.skyMin)vr.push(0),
y.push("  "+T(e[at].id,10)+" -   (only "+(100*vt[at]).toFixed(0)+"% empty sky: large objects fill the panel, not measured)");else{
for(ct=0;ct<g;ct++)Fr+=er(at,ct)/g;for(gt=0;gt<w;gt++){for($t=0,ct=0;ct<g;ct++)$t+=sr[at][ct][gt];kr[gt]=$t/g-Ar}var Sr=Y(kr,v,m,8),Cr=r(Sr)
;for(J=0;J<Sr.length;J++)Sr[J]=Math.abs(Sr[J]-Cr);vr.push(Sr.length?Z(Sr,95)/Fr:0),y.push("  "+T(e[at].id,10)+" "+vr[at].toFixed(3))}}var Br=[]
;for(at=0;at<u;at++)vr[at]>l.structWarn&&Br.push(e[at].id)
;a.graxpert?y.push("  (GraXpert was applied to the panels)"+(Br.length?" -> it left background structure in: "+Br.join(", ")+"; the joint overlap fit corrects it where panels overlap.":"")):Br.length?y.push("  -> strong / complex gradient in "+Br.join(", ")+': recommend "Remove gradients with GraXpert".'):vt.every(function(t){
return t<l.skyMin
})?y.push("  -> GraXpert not recommended: large objects fill the panels (it would remove their faint outskirts)."):y.push("  -> below "+l.structWarn.toFixed(2)+" sigma: GraXpert not needed."),
y.push("")}it=Date.now();var Ir=[],Pr={},zr=0;for(at=0;at<u;at++)Ir.push(new X(t.rep[at].box,l.knot));for(I=0;I<yt.length;I++)Pr[yt[I]]=zr,zr+=Ir[yt[I]].n
;var Tr=[];for(A=0;A<u;A++)for(k=A+1;k<u;k++){var Wr=[];for(gt=0;gt<w;gt++)hr[A][0][gt]==hr[A][0][gt]&&hr[k][0][gt]==hr[k][0][gt]&&Wr.push(gt)
;Wr.length>=20&&Tr.push({i:A,j:k,g:Wr})}var Rr=0;for(Ut=0;Ut<Tr.length;Ut++)Rr+=Tr[Ut].g.length
;var Gr=new Int32Array(Rr+1),jr=new Int32Array(32*Rr),qr=new Float64Array(32*Rr),Lr=0,Dr=0,Hr=new Int32Array(16),Er=new Float64Array(16)
;for(Ut=0;Ut<Tr.length;Ut++){var Vr=Tr[Ut];for(I=0;I<Vr.g.length;I++){var Ur=(gt=Vr.g[I])%v*f+f/2;if(gr=Math.floor(gt/v)*f+f/2,
void 0!==Pr[Vr.i])for(Ir[Vr.i].basis(Ur,gr,Hr,Er),J=0;J<16;J++)jr[Dr]=Hr[J]+Pr[Vr.i],qr[Dr++]=Er[J];if(void 0!==Pr[Vr.j])for(Ir[Vr.j].basis(Ur,gr,Hr,Er),
J=0;J<16;J++)jr[Dr]=Hr[J]+Pr[Vr.j],qr[Dr++]=-Er[J];Gr[++Lr]=Dr}}var Nr=[],Or=[];for(I=0;I<yt.length;I++){var Xr=Ir[yt[I]],_r=Pr[yt[I]]
;for(gr=0;gr<Xr.ny;gr++)for(Ur=0;Ur<Xr.nx;Ur++)Ur+1<Xr.nx&&(Nr.push(_r+gr*Xr.nx+Ur),Or.push(_r+gr*Xr.nx+Ur+1)),gr+1<Xr.ny&&(Nr.push(_r+gr*Xr.nx+Ur),
Or.push(_r+(gr+1)*Xr.nx+Ur))}var Kr=l.smooth*(l.knot/f)*(l.knot/f),Yr=[];for(at=0;at<u;at++){for(dr=[],ct=0;ct<g;ct++)dr.push(new Float64Array(Ir[at].n))
;Yr.push(dr)}var Zr=0;for(ct=0;ct<g;ct++){gr=new Float64Array(Rr);var Jr=new Float64Array(Rr),Qr=(J=0,0);for(Ut=0;Ut<Tr.length;Ut++){
var $r=(er((Vr=Tr[Ut]).i,ct)*er(Vr.i,ct)+er(Vr.j,ct)*er(Vr.j,ct))/(.64*f*f);for(I=0;I<Vr.g.length;I++,J++){Kt=hr[Vr.i][ct][Vr.g[I]];var te=hr[Vr.j][ct][Vr.g[I]]
;Xr=Math.max(0,(Kt+te)/2-lr[ct])*l.objEps,gr[J]=Kt-te,Jr[J]=1/($r+Xr*Xr),Qr+=Jr[J]}}Qr/=Rr;var re=new Uint8Array(Rr),ee=new Float64Array(Rr);for(Ur=null,
Jt=new Float64Array(Rr),J=0;J<Rr;J++)Jr[J]/=Qr,re[J]=1;for(var ae=0;ae<6;ae++){for(J=0;J<Rr;J++)ee[J]=re[J]?Jr[J]:0
;Zr+=(Ur=_(zr,Gr,jr,qr,ee,gr,Nr,Or,Kr,1e-6,Ur,1e-7,3e3)).iterations;var oe=[];for(J=0;J<Rr;J++){for($t=0,Ht=Gr[J];Ht<Gr[J+1];Ht++)$t+=qr[Ht]*Ur[jr[Ht]]
;Jt[J]=gr[J]-$t,re[J]&&oe.push(Math.abs(Jt[J]))}var ie=1.4826*r(oe),ne=!1;for(J=0;J<Rr;J++){var se=Math.abs(Jt[J])<3*ie?1:0;se!==re[J]&&(re[J]=se,ne=!0)}
if(!ne)break}for(I=0;I<yt.length;I++)Yr[yt[I]][ct]=Ur.subarray(Pr[yt[I]],Pr[yt[I]]+Ir[yt[I]].n)}
n("  joint surfaces: "+zr+" unknowns, "+Rr+" overlap bins, "+Zr+" CG iterations ("+((Date.now()-it)/1e3).toFixed(1)+" s)");var he=[];for(at=0;at<u;at++){
for(ur=[],ct=0;ct<g;ct++){for(Kt=new Float32Array(sr[at][ct]),gt=0;gt<w;gt++)Kt[gt]==Kt[gt]&&(Kt[gt]-=Ir[at].eval(gt%v*f+f/2,Math.floor(gt/v)*f+f/2,Yr[at][ct]))
;ur.push(Kt)}he.push(ur)}ar(he,"D. after joint residual surfaces (B-spline, knots "+l.knot+" px, smooth "+l.smooth.toFixed(1)+", reference fixed):");var le=[]
;for(at=0;at<u;at++){for(ur=[],ct=0;ct<g;ct++){for(Kt=new Float32Array(hr[at][ct]),
gt=0;gt<w;gt++)Kt[gt]==Kt[gt]&&(Kt[gt]-=Ir[at].eval(gt%v*f+f/2,Math.floor(gt/v)*f+f/2,Yr[at][ct]));ur.push(Kt)}le.push(ur)}
for(ar(le,"E. the same over the whole overlaps incl. galaxies / nebulae (stars excluded; the fit uses these bins):"),at=0;at<u;at++){
var fe=(ot=t.rep[at]).box[0],ue=ot.box[1],ce=Math.ceil((ot.w-1)/4)+2,de=Math.ceil((ot.h-1)/4)+2;for(ct=0;ct<g;ct++){
var pe=new Float32Array(ce*de),ve=new Float32Array(ce*de);for(k=0;k<de;k++)for(A=0;A<ce;A++){var me=fe+4*A,we=ue+4*k
;if(pe[_r=k*ce+A]=Xt[at][ct]*(Nt?Yt(M(at,me,we),ct):1),Kt=Ir[at].eval(me,we,Yr[at][ct]),!a.keepGradients){
for(br=K((me-nr[at][0])/nr[at][2],(we-nr[at][1])/nr[at][2],l.bgDeg),$t=0,J=0;J<or;J++)$t+=br[J]*ir[at][ct][J];Kt+=$t-lr[ct]}ve[_r]=Kt}var ge=ot.chans[ct]
;for(gr=0;gr<ot.h;gr++){z=gr/4;var ye=Math.floor(z),xe=z-ye;for(Ur=0;Ur<ot.w;Ur++)if(_r=gr*ot.w+Ur,ot.mask[_r]){P=Ur/4
;var Me=Math.floor(P),be=P-Me,Ae=ye*ce+Me,ke=Ae+ce,Fe=pe[Ae]+be*(pe[Ae+1]-pe[Ae]),Se=pe[ke]+be*(pe[ke+1]-pe[ke]),Ce=ve[Ae]+be*(ve[Ae+1]-ve[Ae]),Be=ve[ke]+be*(ve[ke+1]-ve[ke])
;ge[_r]=ge[_r]/(Fe+xe*(Se-Fe))-(Ce+xe*(Be-Ce))}else ge[_r]=0}}}var Ie=[];for(at=0;at<u;at++){for($t=[],ct=0;ct<g;ct++)$t.push(er(at,ct));Ie.push($t)}return{
report:y,scale:Xt,vignetting:_t,useVig:Nt,bg:ir,pedestal:lr,noise:rt,sigma:Ie,struct:vr,recommendGraXpert:vr.some(function(t){return t>l.structWarn})}}(g,p,{
log:u});console.noteln("Seams and blending");let M=function(t,r,o){
for(var i=Q,n=(o=o||{}).log||function(){},s=t.rep.length,h=t.W,l=t.H,f=t.rep[0].chans.length,u=i.G,d=1<<i.levels,p=Math.ceil(h/d)*d,v=Math.ceil(l/d)*d,m=p/u,w=v/u,g=m*w,y=[],x=0;x<s;x++){
for(var M=0,b=0;b<f;b++)M+=r[x][b]/f;y.push(M)}var A=o.names||t.rep.map(function(t,r){return"panel "+(r+1)}),k=[],F=[],S=[];for(x=0;x<s;x++){
for(var C=(qt=t.rep[x]).box[0],B=qt.box[1],I=new Uint8Array(g),P=new Float32Array(g),z=Math.floor(C/u),R=Math.floor(B/u),G=Math.floor((C+qt.w)/u),j=Math.floor((B+qt.h)/u),q=R;q<j;q++)for(var L=z;L<G;L++){
var D=L*u-C,H=q*u-B;if(!(D<0||H<0||D+u>qt.w||H+u>qt.h)){for(var E=1,V=(M=0,0);V<u&&E;V++)for(var U=(H+V)*qt.w+D,N=0;N<u;N++){if(!qt.mask[U+N]){E=0;break}
for(b=0;b<f;b++)M+=qt.chans[b][U+N]}E&&(I[q*m+L]=1,P[q*m+L]=M/(u*u*f))}}F.push(I),S.push(P)}
for(var O=new Uint8Array(g),X=new Float32Array(g),_=new Uint8Array(g),K=0;K<g;K++){M=0;var Y=0;for(x=0;x<s;x++)F[x][K]&&(M+=S[x][K],Y++);_[K]=Y,O[K]=Y?1:0,
X[K]=Y?M/Y:0}S=null;var Z=e(a(X,O)),J=new Float32Array(g);for(K=0;K<g;K++)J[K]=O[K]?Math.min(Math.max((X[K]-Z.med)/(5*Z.sigma),0),1):0;J=c(function(t,r,e){
for(var a=new Float32Array(r*e),o=new Float32Array(r*e),i=0;i<e;i++)for(var n=0;n<r;n++){
for(var s=-1/0,h=i*r,l=Math.max(0,n-2);l<=Math.min(r-1,n+2);l++)t[h+l]>s&&(s=t[h+l]);a[h+n]=s}for(n=0;n<r;n++)for(i=0;i<e;i++){for(s=-1/0,
l=Math.max(0,i-2);l<=Math.min(e-1,i+2);l++)a[l*r+n]>s&&(s=a[l*r+n]);o[i*r+n]=s}return o}(J,m,w),m,w,1)
;for(var $=new Float64Array(w*(m-1)),rt=new Float64Array((w-1)*m),et=0;et<w;et++)for(var at=0;at+1<m;at++)$[et*(m-1)+at]=i.seamW+i.objW*Math.max(J[et*m+at],J[et*m+at+1])
;for(et=0;et+1<w;et++)for(at=0;at<m;at++)rt[et*m+at]=i.seamW+i.objW*Math.max(J[et*m+at],J[(et+1)*m+at]);var ot=[],it=[],nt=m+2,st=w+2;for(x=0;x<s;x++){
var ht=new Uint8Array(nt*st);for(et=0;et<st;et++)for(at=0;at<nt;at++)ht[et*nt+at]=0!==at&&0!==et&&at!==nt-1&&et!==st-1&&F[x][(et-1)*m+at-1]?0:1
;var ft=lt(ht,nt,st),ut=new Float32Array(g);for(et=0;et<w;et++)for(at=0;at<m;at++)ut[et*m+at]=ft[(et+1)*nt+at+1]*u;it.push(ut)}var dt=new Float64Array(g)
;for(K=0;K<g;K++){var mt=1/0;for(x=0;x<s;x++)F[x][K]&&y[x]<mt&&(mt=y[x]);dt[K]=mt}for(x=0;x<s;x++){var wt=new Float64Array(g);for(K=0;K<g;K++)if(wt[K]=1/0,
F[x][K]&&!((ut=it[x][K])<i.edgeMin&&1!==_[K])){var gt=i.edgeW*Math.max(i.edgeR/Math.max(ut,1)-1,0);wt[K]=i.noiseW*Math.log(y[x]/dt[K])+Math.min(gt,50)}
ot.push(wt)}var yt=new Int32Array(g);for(K=0;K<g;K++)if(O[K]){var xt=!1;for(x=0;x<s;x++)isFinite(ot[x][K])&&(xt=!0)
;if(!xt)for(x=0;x<s;x++)F[x][K]&&(ot[x][K]=50+i.noiseW*Math.log(y[x]/dt[K]));var Mt=-1,bt=1/0;for(x=0;x<s;x++)ot[x][K]<bt&&(bt=ot[x][K],Mt=x);yt[K]=Mt
}else yt[K]=-1;it=null,n("graph cut on "+m+" x "+w+" cells");var At=tt(ot,$,rt,yt,m,w,i.sweeps,n);yt=At.label,
k.push("Labels: graph cut "+m+" x "+w+" cells of "+u+" px, energy "+At.hist[0].toFixed(0)+" -> "+At.hist[At.hist.length-1].toFixed(0)+" ("+(At.hist.length-1)+" expansions accepted).")
;var kt=0,Ft=0;for(et=0;et<w;et++)for(at=0;at<m;at++){var St=yt[K=et*m+at];St<0||(at+1<m&&yt[K+1]>=0&&yt[K+1]!==St&&(kt++,J[K]>.3&&Ft++),
et+1<w&&yt[K+m]>=0&&yt[K+m]!==St&&(kt++,J[K]>.3&&Ft++))}k.push("Seams: "+kt*u+" px total, "+(kt?100*Ft/kt:0).toFixed(1)+"% on stars/galaxies.")
;var Ct=Math.min.apply(null,y),Bt=0;for(K=0;K<g;K++)Bt+=O[K];for(k.push("",T("panel",12)+W("sigma",10)+W("rel",7)+W("area%",8)+W("cover%",8)),x=0;x<s;x++){
var It=0,Pt=0;for(K=0;K<g;K++)yt[K]===x&&It++,F[x][K]&&Pt++
;k.push(T(A[x],12)+W(y[x].toExponential(3),10)+W((y[x]/Ct).toFixed(2),7)+W((100*It/Bt).toFixed(1),8)+W((100*Pt/Bt).toFixed(1),8))}
var zt=h*l,Tt=new Uint8Array(zt),Wt=s<=8?new Uint8Array(zt):s<=16?new Uint16Array(zt):new Uint32Array(zt);for(x=0;x<s;x++){C=(qt=t.rep[x]).box[0],B=qt.box[1]
;var Rt=1<<x;for(et=0;et<qt.h;et++)for(U=(B+et)*h+C,M=et*qt.w,at=0;at<qt.w;at++)qt.mask[M+at]&&(Tt[U+at]=1,Wt[U+at]|=Rt)}var Gt=y.map(function(t,r){return r
}).sort(function(t,r){return y[t]-y[r]}),jt={W:h,H:l,nc:f,chans:null,labf:new Int8Array(zt),union:Tt,cov:Wt,sig:y,order:Gt,names:A,report:k,cells:{label:yt,
Wc:m,Hc:w},cut:{D:ot,wh:$,wv:rt,valid:F,auto:new Int32Array(yt)},fill:[],fbox:[]};for(pt(jt,yt,[0,0,h,l]),x=0;x<s;x++){mt=(qt=t.rep[x]).box
;var qt,Lt=[Math.max(Math.floor(mt[0]/d)*d-d,0),Math.max(Math.floor(mt[1]/d)*d-d,0),Math.min(Math.ceil(mt[2]/d)*d+d,p),Math.min(Math.ceil(mt[3]/d)*d+d,v)],Dt=Lt[2]-Lt[0],Ht=Lt[3]-Lt[1],Et=(It=Dt*Ht,
qt.box[0]-Lt[0]),Vt=qt.box[1]-Lt[1],Ut=[];for(n("  extend "+A[x]),b=0;b<f;b++){var Nt=new Float32Array(It),Ot=new Float32Array(It)
;for(et=0;et<qt.h;et++)for(at=0;at<qt.w;at++)M=et*qt.w+at,qt.mask[M]&&(Nt[ut=(et+Vt)*Dt+at+Et]=qt.chans[b][M],Ot[ut]=1);Ut.push(ct(Nt,Ot,Dt,Ht))}
jt.fill.push(Ut),jt.fbox.push(Lt)}var Xt=vt(jt,[0,0,p,v],n);for(jt.chans=[],b=0;b<f;b++){var _t=new Float32Array(zt),Kt=Xt[b]
;for(et=0;et<l;et++)for(at=0;at<h;at++)_t[K=et*h+at]=Tt[K]?Kt[et*p+at]:0;jt.chans.push(_t)}return jt}(g,x.sigma,{log:u,names:m})
;v&&(console.noteln("GraXpert background extraction on the whole mosaic (gradient common to the field)"),Kt(v,M),
u("GraXpert: background model of the mosaic subtracted")),console.noteln("Noise spectra");let b=function(t,e){
for(var a=(e=e||{}).log||function(){},o=Q.psdT,i=o*o,n=[],s=new Float64Array(o),f=new Float64Array(i),u=0,c=0;c<o;c++)s[c]=.5-.5*Math.cos(2*Math.PI*c/(o-1))
;for(var d=0;d<o;d++)for(var p=0;p<o;p++)f[d*o+p]=s[d]*s[p],u+=f[d*o+p]*f[d*o+p];for(var v=0;v<t.rep.length;v++){
var m=t.rep[v],w=m.w,g=m.h,y=m.chans.length,x=l(h(m.chans,w,g),w,g,2),M=new Uint8Array(x.w*x.h);for(d=0;d<x.h;d++)for(p=0;p<x.w;p++){var b=2*d*w+2*p
;M[d*x.w+p]=m.mask[b]&m.mask[b+1]&m.mask[b+w]&m.mask[b+w+1]}var A=H(x.data,M,x.w,x.h,2,!0),k=new Uint8Array(w*g),F=new Uint8Array(w*g)
;for(d=0;d<g;d++)for(p=0;p<w;p++){var S=Math.min(d>>1,x.h-1)*x.w+Math.min(p>>1,x.w-1);k[d*w+p]=A.obj[S],F[d*w+p]=A.compact[S]}var C=x;x=M=A=null
;for(var B=[],I=[],P=0;P<g-o;P+=o/2)for(var z=0;z<w-o;z+=o/2){var T=!0,W=0,R=0;for(d=0;d<o&&T;d++)for(p=0;p<o;p++){if(c=(P+d)*w+z+p,!m.mask[c]){T=!1;break}
k[c]||W++,F[c]||R++}if(T&&(W>=.85*i&&B.push([z,P]),R>=.85*i)){var G=0,j=0
;for(d=0;d<o;d+=4)for(p=0;p<o;p+=4)G+=C.data[Math.min(P+d>>1,C.h-1)*C.w+Math.min(z+p>>1,C.w-1)],j++;I.push([z,P,G/j])}}C=null;var q=!1
;B.length<8&&I.length&&(I.sort(function(t,r){return t[2]-r[2]}),B=I.slice(0,Math.max(8,Math.ceil(.3*I.length))),k=F,q=!0),F=null
;for(var L=[],D=[],E=0;E<y*y;E++)L.push(new Float64Array(i)),D.push(new Float64Array(i))
;for(var V=[],U=[],N=new Uint8Array(i),O=new Float64Array(i),X=0,_=0;_<y;_++)V.push(new Float64Array(i)),U.push(new Float64Array(i))
;for(var K=q?new Float32Array(i):null,Y=0;Y<B.length;Y++){z=B[Y][0],P=B[Y][1];var Z=0;for(d=0;d<o;d++)for(p=0;p<o;p++){var J=k[(P+d)*w+z+p]?0:1;N[d*o+p]=J,
J&&(Z+=f[d*o+p]*f[d*o+p])}var $=1/Math.sqrt(Z/u);for(_=0;_<y;_++){var tt=m.chans[_],et=0;for(d=0;d<o;d++)for(p=0;p<o;p++)N[d*o+p]&&(O[et++]=tt[(P+d)*w+z+p])
;var at=r(O,et),ot=V[_],it=U[_],nt=null;if(q){for(d=0;d<o;d++)for(p=0;p<o;p++)K[pt=d*o+p]=N[pt]?tt[(P+d)*w+z+p]:at;nt=rt(K,o,o,6)}
for(d=0;d<o;d++)for(p=0;p<o;p++)ot[pt=d*o+p]=N[pt]?(tt[(P+d)*w+z+p]-(nt?nt[pt]:at))*f[pt]*$:0,it[pt]=0;gt(ot,it,o,!1)}
for(var st=0;st<y;st++)for(var ht=st;ht<y;ht++)for(var lt=L[st*y+ht],ft=D[st*y+ht],ut=V[st],ct=U[st],dt=V[ht],pt=(S=U[ht],
0);pt<i;pt++)lt[pt]+=ut[pt]*dt[pt]+ct[pt]*S[pt],ft[pt]+=ct[pt]*dt[pt]-ut[pt]*S[pt];X++}for(st=0;st<y;st++)for(ht=0;ht<st;ht++){lt=L[st*y+ht],ft=D[st*y+ht]
;var vt=L[ht*y+st],mt=D[ht*y+st];for(pt=0;pt<i;pt++)lt[pt]=vt[pt],ft[pt]=-mt[pt]}var wt=1/(Math.max(X,1)*u),yt=0
;for(E=0;E<y*y;E++)for(pt=0;pt<i;pt++)L[E][pt]*=wt,D[E][pt]*=wt;if(q){var xt=o/8,Mt=[];for(d=0;d<o;d++)for(p=0;p<o;p++){
var bt=d<=o/2?d:o-d,At=p<=o/2?p:o-p,kt=Math.sqrt(At*At+bt*bt);Mt.push(kt<xt?0:kt<2*xt?1:2)}for(E=0;E<y*y;E++){var Ft=0,St=0,Ct=0
;for(pt=0;pt<i;pt++)1===Mt[pt]&&(Ft+=L[E][pt],St+=D[E][pt],Ct++);for(Ft/=Ct,St/=Ct,pt=0;pt<i;pt++)0===Mt[pt]&&(L[E][pt]=Ft,D[E][pt]=St)}}
for(_=0;_<y;_++)for(pt=0;pt<i;pt++)yt+=L[_*y+_][pt];if(q&&e.sigma&&e.sigma[v]){var Bt=0;for(_=0;_<y;_++)Bt+=e.sigma[v][_]*e.sigma[v][_]/y;var It=Bt/(yt/i/y)
;for(E=0;E<y*y;E++)for(pt=0;pt<i;pt++)L[E][pt]*=It,D[E][pt]*=It;yt*=It}n.push({re:L,im:D,n:X,sigma:Math.sqrt(yt/i/y),detrend:q}),
a("  noise spectrum "+(e.names?e.names[v]:v)+": "+X+(q?" faint patches over objects (too little empty sky)":" sky patches")+", sigma "+n[v].sigma.toExponential(3))
}return n}(g,{log:u,names:m,sigma:x.sigma});return g.rep=null,console.writeln("<end><cbr><br>"+g.report.join("\n")),
console.writeln("<end><cbr><br>Photometry<br>"+x.report.join("\n")),console.writeln("<end><cbr><br>Seams<br>"+M.report.join("\n")),
x.recommendGraXpert&&!n.graxpert&&console.warningln("** Strong / complex background gradients detected: tick 'Remove gradients with GraXpert' and build again."),
console.noteln(format("<end><cbr>AutoPano: %d x %d px mosaic analysed in %.1f s",M.W,M.H,f.value)),
d.length&&console.warningln("<end><cbr>** Left out of the mosaic: "+d.map(t=>t.id+" - "+t.reason).join("; ")),{S:M,spectra:b,sig:b.map(t=>t.sigma),names:m,
wcs:R(g),isColor:w,nPanels:p.length,excluded:d,gxSuggest:x.recommendGraXpert&&!n.graxpert,crop:Rt(M),cropAngle:g.canvas.crop?g.canvas.crop.angle:0,NC:{tiles:{},
bytes:0,kern:{},kept:1},mcache:{},R:null}}class Zt extends Dialog{constructor(){super();let t=t=>()=>{Dialog.openBrowser(t),this.ok()}
;this.textLabel=new Label(this),this.textLabel.wordWrapping=!0,this.textLabel.useRichText=!0,
this.textLabel.text="<p>Thank you for using AutoPano! If it saved you time, you can support its development \u2014 any amount via PayPal, or by card with one of the buttons below.</p>",
this.textLabel.setScaledFixedWidth(380),this.paypalButton=new PushButton(this),this.paypalButton.text="PayPal (any amount)",
this.paypalButton.onClick=t("https://www.paypal.com/donate/?business=contact%40bluebelleweddings.com&no_recurring=0&item_name=AutoPano"),
this.cardLabel=new Label(this),this.cardLabel.text="By card:",this.cardSizer=new HorizontalSizer,this.cardSizer.spacing=4;for(let r of Dt){
let e=new PushButton(this);e.text="$"+r[0],e.onClick=t(r[1]),this.cardSizer.add(e,100)}this.sizer=new VerticalSizer,this.sizer.margin=12,this.sizer.spacing=8,
this.sizer.add(this.textLabel),this.sizer.add(this.paypalButton),this.sizer.addSpacing(4),this.sizer.add(this.cardLabel),this.sizer.add(this.cardSizer),
this.windowTitle="Support the author",this.adjustToContents(),this.setFixedSize()}}class Jt extends Control{constructor(t){super(t),this.bitmap=null,
this.pxScale=1,this.detail=null,this.zoom=1,this.ox=0,this.oy=0,this.drag=null,this.onViewChanged=null,this.cropRect=null,this.labels=null,this.editor=null,
this.stroke=null,this.cursorPos=null,this.mouseTracking=!0,this.message="Build the mosaic to see the preview",this.setScaledMinSize(520,520),
this.toolTip="<p>Mouse wheel: zoom (from 1:2 on, the visible part is shown in full resolution with the added noise) &nbsp; Drag: pan &nbsp; Double click: fit</p>",
this.wheelTimer=new Timer,this.wheelTimer.interval=.35,this.wheelTimer.singleShot=!0,this.wheelTimer.onTimeout=()=>this.viewChanged(),this.onPaint=()=>{
let t=new Graphics(this);if(t.fillRect(0,0,this.width,this.height,new Brush(4280295456)),this.bitmap){let r=this.view();t.translateTransformation(r.tx,r.ty),
t.scaleTransformation(r.k),t.drawBitmap(0,0,this.bitmap);let e=this.detail;if(e&&(t.resetTransformation(),
t.translateTransformation(r.tx+r.k*e.x0/this.pxScale,r.ty+r.k*e.y0/this.pxScale),t.scaleTransformation(r.k*e.s/this.pxScale),t.drawBitmap(0,0,e.bitmap)),
this.cropRect){t.resetTransformation();let e=r.k/this.pxScale,a=this.cropRect;t.pen=new Pen(3221225472,3),
t.drawRect(r.tx+a[0]*e,r.ty+a[1]*e,r.tx+a[2]*e,r.ty+a[3]*e),t.pen=new Pen(4294955072,1),t.drawRect(r.tx+a[0]*e,r.ty+a[1]*e,r.tx+a[2]*e,r.ty+a[3]*e)}
if(this.labels){t.resetTransformation();let e=this.font.ascent;for(let a of this.labels){
let o=Math.round(r.tx+r.k*a.x/this.pxScale-this.font.width(a.text)/2),i=Math.round(r.ty+r.k*a.y/this.pxScale+e/2);t.pen=new Pen(4278190080)
;for(let r of[[-1,0],[1,0],[0,-1],[0,1],[1,1]])t.drawText(o+r[0],i+r[1],a.text);t.pen=new Pen(a.color),t.drawText(o,i,a.text)}}if(this.editor){
t.resetTransformation(),t.antialiasing=!0;let e=r.k/this.pxScale,a=this.editor.radius()*e;if(this.stroke){
let o=(this.stroke.erase?2164260863:16777215&this.editor.color()|2147483648)>>>0,i=this.stroke.pts,n=[]
;for(let t=0;t+1<i.length;t+=2)n.push(new Point(r.tx+i[t]*e,r.ty+i[t+1]*e));1===n.length?t.fillCircle(n[0],a,new Brush(o)):(t.pen=new Pen(o,2*a),
t.drawPolyline(n))}this.cursorPos&&(t.strokeCircle(this.cursorPos.x,this.cursorPos.y,a+1,new Pen(3221225472,1)),
t.strokeCircle(this.cursorPos.x,this.cursorPos.y,a,new Pen(4294967295,1)))}}else t.pen=new Pen(4288716960),
t.drawTextRect(0,0,this.width,this.height,this.message,TextAlignment.Center|TextAlignment.VertCenter);t.end()},this.onMouseWheel=(t,r,e)=>{
if(!this.bitmap)return;let a=this.view(),o=(t-a.tx)/a.k,i=(r-a.ty)/a.k;if(this.zoom=Math.max(1,Math.min(64,this.zoom*(e>0?1.25:.8))),
1===this.zoom)this.ox=this.oy=0;else{let e=this.view();this.ox+=t-(e.tx+o*e.k),this.oy+=r-(e.ty+i*e.k)}this.detail=null,this.update(),this.wheelTimer.stop(),
this.wheelTimer.start()},this.onMousePress=(t,r,e,a,o)=>{if(this.editor&&this.bitmap&&e===MouseButton.Left&&!(o&KeyModifier.SpaceBar)){let e=this.toMosaic(t,r)
;return o&KeyModifier.Control?void this.editor.pick(e[0],e[1]):(this.stroke={erase:0!==(o&KeyModifier.Alt),pts:e},void this.update())}this.drag={x:t,y:r,
ox:this.ox,oy:this.oy}},this.onMouseMove=(t,r)=>{if(this.editor&&(this.cursorPos={x:t,y:r}),this.stroke){
let e=this.toMosaic(t,r),a=this.stroke.pts,o=a.length,i=Math.max(this.editor.radius()/4,2*this.pxScale/this.view().k)
;return Math.hypot(e[0]-a[o-2],e[1]-a[o-1])>=i&&a.push(e[0],e[1]),void this.update()}this.drag?(this.ox=this.drag.ox+t-this.drag.x,
this.oy=this.drag.oy+r-this.drag.y,this.update()):this.editor&&this.update()},this.onLeave=()=>{this.cursorPos&&(this.cursorPos=null,this.update())},
this.onMouseRelease=()=>{if(this.stroke){let t=this.stroke;return this.stroke=null,void this.editor.strokeDone(t)}
let t=this.drag&&(this.ox!==this.drag.ox||this.oy!==this.drag.oy);this.drag=null,t&&(this.detail=null,this.viewChanged())},this.onMouseDoubleClick=()=>{
this.zoom=1,this.ox=this.oy=0,this.detail=null,this.update()},this.onResize=()=>{this.detail=null,this.update()}}viewChanged(){
this.onViewChanged&&this.onViewChanged()}toMosaic(t,r){let e=this.view();return[(t-e.tx)/e.k*this.pxScale,(r-e.ty)/e.k*this.pxScale]}view(){
let t=this.bitmap.width,r=this.bitmap.height,e=Math.min(this.width/t,this.height/r)*this.zoom;return{k:e,tx:(this.width-t*e)/2+this.ox,
ty:(this.height-r*e)/2+this.oy}}mosaicViewport(t,r){if(!this.bitmap)return null
;let e=this.view(),a=this.pxScale,o=Math.max(0,Math.floor(-e.tx/e.k*a)),i=Math.max(0,Math.floor(-e.ty/e.k*a)),n=Math.min(t,Math.ceil((this.width-e.tx)/e.k*a)),s=Math.min(r,Math.ceil((this.height-e.ty)/e.k*a))
;return{k:e.k/a,rect:[o,i,n,s]}}static bitmapOf(t,r,e){let a=new Image(r,e,3,ColorSpace.RGB);for(let o=0;o<3;++o)a.setSamples(t[o],new Rect(0,0,r,e),o)
;let o=a.render();return a.free(),o}setImage(t,r,e,a,o){this.bitmap=Jt.bitmapOf(t,r,e),this.pxScale=a,o||(this.zoom=1,this.ox=this.oy=0,this.detail=null),
this.update()}setDetail(t,r,e,a,o,i){this.detail=t?{bitmap:Jt.bitmapOf(t,r,e),x0:a,y0:o,s:i}:null,this.update()}}function Qt(t,r,e,a,o,i,n,s){
let h=new NumericControl(t);return h.label.text=r,h.label.setScaledFixedWidth(130),h.setRange(e,a),h.setPrecision(o),h.slider.setRange(0,i),
h.slider.setScaledMinWidth(160),h.setValue(n),h.toolTip=s,h}class $t extends Dialog{constructor(){super(),this.ctx=null,this.pv=null,this.sliding=!1,
this.info="",this.strokes=[],this.edit=null,this.lastKey={key:0,t:0},this.helpLabel=new Label(this),this.helpLabel.frameStyle=FrameStyle.Box,
this.helpLabel.margin=6,this.helpLabel.wordWrapping=!0,this.helpLabel.useRichText=!0,
this.helpLabel.text="<b>"+jt+" v"+qt+"</b> &mdash; tick the <i>linear</i> panels of the mosaic (colour or one mono filter) and press <i>Build mosaic</i>. Every panel keeps its own signal-to-noise ratio; the grain of a noisier panel fades gradually into its neighbours, bright parts of stars / galaxies are protected from the added noise. Zoom into the preview to check the result, adjust the sliders, then <i>Create image</i> (the image appears behind this dialog).",
this.tree=new TreeBox(this),this.tree.numberOfColumns=5,this.tree.headerVisible=!0,this.tree.setHeaderText(0,"Panel"),this.tree.setHeaderText(1,"Noise"),
this.tree.setHeaderText(2,"Size"),this.tree.setHeaderText(3,"Channels"),this.tree.setHeaderText(4,"Astrometry"),this.tree.rootDecoration=!1,
this.tree.alternateRowColor=!0,this.tree.setScaledMinSize(420,160);for(let t of ImageWindow.openWindows){if(t.isNull||!t.visible&&!t.iconic)continue
;let r=t.mainView;if(r.isNull||0===r.id.indexOf("AutoPano"))continue;let e=new TreeBoxNode(this.tree);e.checkable=!0,e.checked=!0,e.setText(0,r.id),
e.setText(2,r.image.width+" x "+r.image.height),e.setText(3,r.image.isColor?"RGB":"Gray"),e.setText(4,t.hasAstrometricSolution?"solved":"will be solved"),
e.viewId=r.id}for(let t=0;t<5;++t)this.tree.adjustColumnWidthToContents(t);this.allButton=new PushButton(this),this.allButton.text="Select all",
this.allButton.onClick=()=>this.setAll(!0),this.noneButton=new PushButton(this),this.noneButton.text="Select none",this.noneButton.onClick=()=>this.setAll(!1),
this.listButtons=new HorizontalSizer,this.listButtons.spacing=6,this.listButtons.add(this.allButton),this.listButtons.add(this.noneButton),
this.listButtons.addStretch(),this.editButton=new PushButton(this),this.editButton.enabled=!1,this.editButton.onClick=()=>{
this.edit?this.leaveEdit(!1):this.enterEdit()},this.editButtonMode(!1),this.listButtons.add(this.editButton),this.gxCheck=new CheckBox(this),
this.gxCheck.text="Remove gradients with GraXpert",this.gxCheck.checked=null!==Xt(),
this.gxCheck.toolTip="<p>GraXpert background extraction (subtraction), in two steps: each panel with enough empty sky first (its own gradient, e.g. a light-pollution dome), then once the whole seamless mosaic (the gradient common to the field, the glow around a large galaxy). Panels filled by a large object are left to the second step, so their halo is not cut. Needs GraXpert installed (as for PixInsight's GraXpert script). Applies to the next Build.</p>",
this.gxSizer=new HorizontalSizer,this.gxSizer.add(this.gxCheck),this.gxSizer.addStretch(),this.tree.onCurrentNodeUpdated=()=>{
if(!this.edit||!this.tree.currentNode)return;let t=this.ctx.names.indexOf(this.tree.currentNode.viewId);t>=0&&t!==this.edit.active&&(this.edit.active=t,
this.showActive(),this.redraw(!0))
},this.blendControl=Qt(this,"Noise transition:",.25,3,2,275,1,"<p>Width of the gradual noise transition around a noisier panel, relative to the automatic width (1.00 = auto: wider for a bigger noise difference). Larger = gentler change of the grain, but more of the cleaner neighbours gets extra noise.</p>"),
this.strengthControl=Qt(this,"Object protection:",0,3,2,300,1,"<p>How much the bright parts of stars and galaxies are spared the added noise. Protection follows the screen stretch: only where the missing grain stays invisible (bright cores), so faint halos and outskirts get the same grain as the sky around them. Higher = more protection (and fainter objects detected); 0 = off.</p>"),
this.featherControl=Qt(this,"Mask softness (px):",2,60,0,58,12,"<p>Feather of the object mask edges, px.</p>")
;for(let t of[this.blendControl,this.strengthControl,this.featherControl])t.slider.onMousePress=()=>{this.sliding=!0},t.slider.onMouseRelease=()=>{
this.sliding=!1,this.slidersChanged()},t.onValueUpdated=()=>{this.sliding||this.slidersChanged()};this.maskCheck=new CheckBox(this),
this.maskCheck.text="Object mask (red)",this.maskCheck.toolTip="<p>Overlay the object protection on the preview: red = no added noise.</p>",
this.maskCheck.onCheck=()=>this.redraw(!0),this.noiseCheck=new CheckBox(this),this.noiseCheck.text="Noise map",
this.noiseCheck.toolTip="<p>Overlay the final noise level relative to the cleanest panel (log scale): dark blue = as the cleanest panel .. yellow = as the noisiest. Shows how the grain of a noisier panel fades into its neighbours (Noise transition).</p>",
this.noiseCheck.onCheck=()=>this.redraw(!0),this.seamCheck=new CheckBox(this),this.seamCheck.text="Seam map",
this.seamCheck.toolTip="<p>Which panel gives which part of the mosaic: each area is tinted in its panel colour (the colour squares in the panel list) and labelled with the panel and its noise relative to the cleanest panel. Solid light lines = seams; dashed lines = where each panel really ends, i.e. how much spare image a panel has beyond its seam.</p>",
this.seamCheck.onCheck=()=>this.redraw(!0),this.showLabel=new Label(this),this.showLabel.text="Show:",
this.showLabel.textAlignment=TextAlignment.Right|TextAlignment.VertCenter,this.showLabel.setScaledFixedWidth(130),this.checkSizer=new HorizontalSizer,
this.checkSizer.spacing=12,this.checkSizer.add(this.showLabel),this.checkSizer.add(this.maskCheck),this.checkSizer.add(this.noiseCheck),
this.checkSizer.add(this.seamCheck),this.cropCheck=new CheckBox(this),this.cropCheck.text="Crop to the filled area",
this.cropCheck.toolTip="<p>Cut the mosaic to the largest rectangle without empty corners (the frame on the preview). The mosaic is always built at the angle that makes this rectangle largest - the panels are resampled only once, and the astrometric solution stays exact.</p>",
this.cropCheck.onCheck=()=>this.redraw(!0),this.cropSizer=new HorizontalSizer,this.cropSizer.addScaledSpacing(134),this.cropSizer.add(this.cropCheck),
this.cropSizer.addStretch(),this.checkSizer.addStretch(),this.infoLabel=new Label(this),this.infoLabel.wordWrapping=!0,this.infoLabel.setScaledMinHeight(48),
this.infoLabel.text="",this.noiseGroup=new GroupBox(this),this.noiseGroup.title="Noise and seams",this.noiseGroup.sizer=new VerticalSizer,
this.noiseGroup.sizer.margin=6,this.noiseGroup.sizer.spacing=4,this.noiseGroup.sizer.add(this.blendControl),this.noiseGroup.sizer.add(this.strengthControl),
this.noiseGroup.sizer.add(this.featherControl),this.noiseGroup.sizer.add(this.checkSizer),this.noiseGroup.sizer.add(this.cropSizer),
this.qualityLabel=new Label(this),this.qualityLabel.text="Preview quality:",this.qualityLabel.textAlignment=TextAlignment.Right|TextAlignment.VertCenter,
this.qualityLabel.setScaledFixedWidth(130),this.qualityCombo=new ComboBox(this)
;for(let t of["Full (1:1)","Half (1:2)","Quarter (1:4)","Eighth (1:8)"])this.qualityCombo.addItem(t);this.qualityCombo.currentItem=2,
this.qualityCombo.toolTip="<p>Resolution of the preview, as in video editors: the preview always shows the final result (with the added noise), reduced to this quality. Lower = faster slider updates. The object mask is also computed at this resolution: Half and Full give exactly the mask of the final image, Quarter / Eighth a close approximation (the final image always uses the exact one).</p>",
this.qualityCombo.onItemSelected=()=>this.recompute(),this.qualitySizer=new HorizontalSizer,this.qualitySizer.spacing=4,
this.qualitySizer.add(this.qualityLabel),this.qualitySizer.add(this.qualityCombo),this.qualitySizer.addStretch(),this.noiseGroup.sizer.add(this.qualitySizer),
this.noiseGroup.sizer.add(this.infoLabel),this.activeLabel=new Label(this),this.activeLabel.useRichText=!0,this.activeLabel.text="",
this.sizeControl=Qt(this,"Brush size (px):",20,2e3,0,1980,300,"<p>Brush radius in mosaic pixels.</p>"),
this.sizeControl.onValueUpdated=()=>this.preview.update(),this.editHelp=new Label(this),this.editHelp.useRichText=!0,this.editHelp.wordWrapping=!0,
this.editHelp.text="<p>Pick the panel in the list or <b>Ctrl+click</b> it on the preview, then paint where this panel should be used (e.g. over a galaxy): the seams go around your strokes through the background. <b>Alt</b>+paint: erase strokes. <b>Ctrl+Z</b> / <b>Ctrl+Shift+Z</b>: undo / redo. Wheel: zoom; right or middle button (or Space) + drag: pan. Dimmed = the active panel has no data there.</p>",
this.undoButton=new PushButton(this),this.undoButton.text="Undo",this.undoButton.onClick=()=>this.undo(),this.redoButton=new PushButton(this),
this.redoButton.text="Redo",this.redoButton.onClick=()=>this.redo(),this.clearButton=new PushButton(this),this.clearButton.text="Clear panel",
this.clearButton.toolTip="<p>Remove the strokes of the active panel (other panels keep theirs).</p>",this.clearButton.onClick=()=>{this.edit&&this.addAction({
clear:this.edit.active})},this.applyButton=new PushButton(this),this.applyButton.text="Apply",this.applyButton.icon=this.scaledResource(":/icons/ok.png"),
this.applyButton.toolTip="<p>Re-blend the mosaic with the edited seams, recompute the noise and leave seam editing.</p>",
this.applyButton.onClick=()=>this.leaveEdit(!0),this.editButtons=new HorizontalSizer,this.editButtons.spacing=6,this.editButtons.add(this.undoButton),
this.editButtons.add(this.redoButton),this.editButtons.add(this.clearButton),this.editButtons.addStretch(),this.editButtons.add(this.applyButton),
this.editInfo=new Label(this),this.editInfo.wordWrapping=!0,this.editInfo.text="",this.editGroup=new GroupBox(this),this.editGroup.title="Seam editing",
this.editGroup.sizer=new VerticalSizer,this.editGroup.sizer.margin=6,this.editGroup.sizer.spacing=6,this.editGroup.sizer.add(this.activeLabel),
this.editGroup.sizer.add(this.sizeControl),this.editGroup.sizer.add(this.editHelp),this.editGroup.sizer.add(this.editButtons),
this.editGroup.sizer.add(this.editInfo),this.editGroup.visible=!1,this.preview=new Jt(this),this.preview.onKeyPress=(t,r)=>this.editKey(t,r),
this.onKeyPress=(t,r)=>this.editKey(t,r),this.preview.onViewChanged=()=>this.updateDetail(),this.buildButton=new PushButton(this),
this.buildButton.text="Build mosaic",this.buildButton.icon=this.scaledResource(":/icons/ok.png"),
this.buildButton.toolTip="<p>Analyse the ticked panels (geometry, photometry, seams, noise) and show the preview.</p>",
this.buildButton.onClick=()=>this.build(),this.imageButton=new PushButton(this),this.imageButton.text="Create image",
this.imageButton.icon=this.scaledResource(":/icons/add.png"),
this.imageButton.toolTip="<p>Create the mosaic image with the current settings (no rebuild). It opens behind this dialog; settings can be changed and another image created.</p>",
this.imageButton.enabled=!1,this.imageButton.onClick=()=>this.makeImage(),this.closeButton=new PushButton(this),this.closeButton.text="Close",
this.closeButton.icon=this.scaledResource(":/icons/close.png"),this.closeButton.onClick=()=>this.cancel(),this.heartLabel=new Label(this),
this.heartLabel.useRichText=!0,this.heartLabel.text='<span style="color:#e0245e; font-size:15pt;">&#9829;</span>',
this.heartLabel.toolTip="<p>Like AutoPano? Support its development with a donation (PayPal or card).</p>",
this.heartLabel.cursor=new Cursor(StdCursor.PointingHand),this.heartLabel.onMousePress=()=>(new Zt).execute(),this.buttons=new HorizontalSizer,
this.buttons.spacing=6,this.buttons.add(this.heartLabel),this.buttons.addStretch(),this.buttons.add(this.buildButton),this.buttons.add(this.imageButton),
this.buttons.add(this.closeButton),this.leftSizer=new VerticalSizer,this.leftSizer.spacing=6,this.leftSizer.add(this.helpLabel),
this.leftSizer.add(this.tree,100),this.leftSizer.add(this.listButtons),this.leftSizer.add(this.gxSizer),this.leftSizer.add(this.noiseGroup),
this.leftSizer.add(this.editGroup),this.mainSizer=new HorizontalSizer,this.mainSizer.spacing=8,this.mainSizer.add(this.leftSizer,40),
this.mainSizer.add(this.preview,100),this.sizer=new VerticalSizer,this.sizer.margin=8,this.sizer.spacing=6,this.sizer.add(this.mainSizer,100),
this.sizer.add(this.buttons),this.loadSettings(),this.windowTitle=jt+" v"+qt,this.adjustToContents(),this.setScaledMinSize(1100,700)}settingsList(){
return[["blend",DataType.Double,this.blendControl],["maskStrength",DataType.Double,this.strengthControl],["maskFeather",DataType.Double,this.featherControl],["brushSize",DataType.Double,this.sizeControl],["showMask",DataType.Boolean,this.maskCheck],["showNoise",DataType.Boolean,this.noiseCheck],["showSeams",DataType.Boolean,this.seamCheck],["quality",DataType.Int32,this.qualityCombo],["crop",DataType.Boolean,this.cropCheck],["graxpert",DataType.Boolean,this.gxCheck]]
}loadSettings(){for(let[t,r,e]of this.settingsList()){let a=Settings.read(Lt+"/"+t,r)
;Settings.lastReadOK&&null!=a&&(r===DataType.Boolean?e.checked=a:r===DataType.Int32?a>=0&&a<e.numberOfItems&&(e.currentItem=a):e.setValue(a))}}saveSettings(){
for(let[t,r,e]of this.settingsList())Settings.write(Lt+"/"+t,r,r===DataType.Boolean?e.checked:r===DataType.Int32?e.currentItem:e.value)}setAll(t){
for(let r=0;r<this.tree.numberOfChildren;++r)this.tree.child(r).checked=t}selectedWindows(){let t=[];for(let r=0;r<this.tree.numberOfChildren;++r){
let e=this.tree.child(r);if(!e.checked)continue;let a=View.viewById(e.viewId);a&&!a.isNull&&t.push(a.window)}return t}options(){return{
blend:this.blendControl.value,maskStrength:this.strengthControl.value,maskFeather:this.featherControl.value,crop:this.cropCheck.checked}}quality(){
return[1,2,4,8][this.qualityCombo.currentItem]}seamMap(t){if(!this.ctx)return null;let r=this.edit;return r?{colors:this.ctx.colors,lw:t,label:r.draft,
forced:r.forced,active:r.active}:this.seamCheck.checked?{colors:this.ctx.colors,lw:t}:null}showPanels(){
let t=this.ctx,r=Math.min.apply(null,t.sig),e=Math.round(12*this.displayPixelRatio);for(let a=0;a<this.tree.numberOfChildren;++a){
let o=this.tree.child(a),i=t.names.indexOf(o.viewId);if(i<0){let r=new Bitmap(e,e);r.fill(0),o.setIcon(0,r),
o.setText(1,t.excluded.some(t=>t.id===o.viewId)?"left out":"");continue}let n=new Bitmap(e,e);n.fill(t.argb[i]),o.setIcon(0,n),
o.setText(1,format("%.2fx",t.sig[i]/r))}for(let t=0;t<5;++t)this.tree.adjustColumnWidthToContents(t)}refreshAstrometry(){
for(let t=0;t<this.tree.numberOfChildren;++t){let r=this.tree.child(t),e=View.viewById(r.viewId)
;e&&!e.isNull&&r.setText(4,e.window.hasAstrometricSolution?"solved":this.ctx&&r.checked?"not solved":"will be solved")}this.tree.adjustColumnWidthToContents(4)}
busy(t,r){this.cursor=new Cursor(t?StdCursor.Wait:StdCursor.Arrow),t&&r&&(this.infoLabel.text=r),CoreApplication.processEvents()}slidersChanged(){
this.recompute()}recompute(){if(!this.ctx||!this.pv)return;let t=this.ctx,r=this.pv,e=this.options(),a=this.quality(),o=Math.max(2,a)
;this.busy(!0,"Updating the preview...");let i=new ElapsedTime;try{r.tg=xt(t.S,t.sig,e),t.mcache[o]||(t.mcache[o]={}),r.prot=kt(t.S,r.tg,t.sig,{
maskStrength:e.maskStrength,maskFeather:e.maskFeather,cache:t.mcache[o]},o);let a=Ct(t.S,r.tg,t.spectra,r.prot,{cache:t.NC,out:t.R});t.R=a.chans;let n=0
;for(let r=1;r<t.sig.length;++r)t.sig[r]>t.sig[n]&&(n=r)
;this.info=format("Transition around the noisiest panel (%s, %.2fx the cleanest): %.0f px. Protected: %.1f%% of the mosaic fully, %.1f%% partly (mask at 1:%d). Updated in %.1f s.",t.names[n],t.sig[n]/Math.min.apply(null,t.sig),r.tg.widths[n],100*r.prot.full,100*r.prot.part,o,i.value),
this.redraw(!0)}catch(t){console.criticalln(t.toString())}finally{this.busy(!1)}}redraw(t){if(!this.ctx||!this.pv||!this.ctx.R)return
;let r=this.ctx,e=this.pv,a=Math.max(e.b,this.quality()),o=r.S,i=Math.floor(o.W/a),n=Math.floor(o.H/a),s=Math.max(1,Math.round(1/Math.min(this.preview.width/i,this.preview.height/n))),h=Pt(o,r.R,[0,0,i*a,n*a],a,e.stf,this.maskCheck.checked?e.prot:null,this.noiseCheck.checked?e.tg:null,r.sig,this.seamMap(s)),l=Math.min.apply(null,r.sig)
;this.preview.cropRect=this.cropCheck.checked&&!this.edit?r.crop:null,
this.preview.labels=this.seamCheck.checked||this.edit?(this.edit?this.edit.labels:r.labels).map(t=>({x:t.x,y:t.y,color:r.argb[t.k],
text:r.names[t.k]+"  "+format("%.2fx",r.sig[t.k]/l)})):null,this.preview.setImage(h.rgb,h.w,h.h,a,t),this.updateDetail()}updateDetail(){
if(!this.ctx||!this.pv||!this.ctx.R)return
;let t=this.ctx,r=this.pv,e=this.preview.mosaicViewport(t.S.W,t.S.H),a=this.quality(),o=Math.max(r.b,a),i=e?Math.max(a,Math.min(o,Math.floor(1/e.k)||1)):o
;if(!e||i>=o)return this.preview.setDetail(null),void(this.infoLabel.text=this.info);let n=e.rect.slice();if(n[0]=Math.floor(n[0]/i)*i,
n[1]=Math.floor(n[1]/i)*i,n[2]=n[0]+Math.floor((n[2]-n[0])/i)*i,n[3]=n[1]+Math.floor((n[3]-n[1])/i)*i,!(n[2]-n[0]<2*i||n[3]-n[1]<2*i))try{
let e=Pt(t.S,t.R,n,i,r.stf,this.maskCheck.checked?r.prot:null,this.noiseCheck.checked?r.tg:null,t.sig,this.seamMap(1))
;this.preview.setDetail(e.rgb,e.w,e.h,n[0],n[1],i),this.infoLabel.text=this.info+" View 1:"+i+"."}catch(t){console.criticalln(t.toString())}}editButtonMode(t){
let r=this.editButton;r.text=t?"Cancel":"Edit seams",r.icon=this.scaledResource(t?":/icons/cancel.png":":/icons/brush.png"),
r.toolTip=t?"<p>Leave seam editing without applying the changes made since entering it.</p>":"<p>Seam editing: choose with a brush which panel gives which part of the mosaic. Seams around your strokes are routed automatically through the background; Apply re-blends the mosaic.</p>"
}enterEdit(){if(!this.ctx||this.edit)return;let t=this.ctx,r=0;this.tree.currentNode&&(r=Math.max(0,t.names.indexOf(this.tree.currentNode.viewId))),this.edit={
strokes:this.strokes.slice(),redo:null,active:r,draft:null,forced:null,labels:t.labels},this.preview.editor={radius:()=>this.sizeControl.value,
color:()=>t.argb[this.edit.active],pick:(t,r)=>this.pickPanel(t,r),strokeDone:t=>this.addAction({k:this.edit.active,r:this.sizeControl.value,erase:t.erase,
pts:t.pts})},this.noiseGroup.visible=!1,this.editGroup.visible=!0,this.editButtonMode(!0),this.buildButton.enabled=this.imageButton.enabled=!1,
this.showActive(),this.recut()}leaveEdit(t){let r=this.edit,e=this.ctx;if(!r)return;if(!t)return this.closeEdit(),void this.redraw(!0)
;this.busy(!0,"Re-blending the mosaic...");let a=null;try{let t=new ElapsedTime,o=r.draft||Wt(e.S,Tt(e.S,r.strokes));if(a=function(t,r){
for(var e=Q,a=e.G,o=1<<e.levels,i=t.cells.Wc,n=t.cells.Hc,s=t.cells.label,h=i,l=n,f=-1,u=-1,c=0,d=0;d<n;d++)for(var p=0;p<i;p++)s[B=d*i+p]!==r[B]&&(c++,
p<h&&(h=p),p>f&&(f=p),d<l&&(l=d),d>u&&(u=d));if(!c)return null;t.cells.label=new Int32Array(r);var v=[h*a,l*a,Math.min((f+1)*a,t.W),Math.min((u+1)*a,t.H)]
;pt(t,r,v)
;for(var m=i*a,w=n*a,g=e.blendPad,y=[Math.max(v[0]-g,0),Math.max(v[1]-g,0),Math.min(v[2]+g,t.W),Math.min(v[3]+g,t.H)],x=[Math.max(Math.floor((y[0]-g)/o)*o,0),Math.max(Math.floor((y[1]-g)/o)*o,0),Math.min(Math.ceil((y[2]+g)/o)*o,m),Math.min(Math.ceil((y[3]+g)/o)*o,w)],M=vt(t,x,void 0),b=x[2]-x[0],A=0;A<t.nc;A++)for(var k=t.chans[A],F=M[A],S=y[1];S<y[3];S++)for(var C=y[0];C<y[2];C++){
var B;k[B=S*t.W+C]=t.union[B]?F[(S-x[1])*b+C-x[0]]:0}return Gt(t,y),{rect:y,win:x,changed:c}}(e.S,o),this.strokes=r.strokes,a){e.labels=zt(e.S),e.mcache={}
;let o=format("Seam edits: %d brush action(s), %d label cells changed, re-blended %d x %d px in %.1f s",r.strokes.length,a.changed,a.win[2]-a.win[0],a.win[3]-a.win[1],t.value)
;console.writeln(o)}}catch(t){console.criticalln(t.toString())}finally{this.busy(!1)}this.closeEdit(),a?this.recompute():this.redraw(!0)}closeEdit(){
this.edit=null,this.preview.editor=null,this.preview.stroke=null,this.preview.cursorPos=null,this.editGroup.visible=!1,this.noiseGroup.visible=!0,
this.editButtonMode(!1),this.buildButton.enabled=!0,this.imageButton.enabled=null!==this.ctx}showActive(){let t=this.edit,r=this.ctx;if(!t)return
;let e=16777215&r.argb[t.active]
;this.activeLabel.text="Active panel: <span style='color:#"+(16777216+e).toString(16).slice(1)+"; font-size:14pt;'>&#9632;</span> <b>"+r.names[t.active]+"</b>"
;for(let e=0;e<this.tree.numberOfChildren;++e){let a=this.tree.child(e);a.viewId===r.names[t.active]&&this.tree.currentNode!==a&&(this.tree.currentNode=a)}}
pickPanel(t,r){let e=this.edit,a=this.ctx.S;if(t=Math.floor(t),r=Math.floor(r),!e||t<0||r<0||t>=a.W||r>=a.H)return
;let o=r*a.W+t,i=Q.G,n=e.draft?dt(a,e.draft[Math.floor(r/i)*a.cells.Wc+Math.floor(t/i)],a.cov[o]):a.labf[o];n<0||n===e.active||(e.active=n,this.showActive(),
this.redraw(!0))}addAction(t){this.edit&&(this.edit.strokes.push(t),this.edit.redo=null,this.recut())}undo(){let t=this.edit
;t&&t.strokes.length&&(t.redo=t.strokes.pop(),this.recut())}redo(){let t=this.edit;t&&t.redo&&(t.strokes.push(t.redo),t.redo=null,this.recut())}recut(){
let t=this.edit,r=this.ctx.S;if(t){this.busy(!0);try{let e=new ElapsedTime;t.forced=Tt(r,t.strokes),t.draft=Wt(r,t.forced),t.labels=zt(r,t.draft)
;let a=0,o=0,i=r.cells.label;for(let r=0;r<t.forced.length;++r)t.forced[r]>=0&&++a,t.draft[r]!==i[r]&&++o
;this.editInfo.text=format("%d action(s); %.1f%% of the mosaic painted; seams moved over %.1f%% (%.1f s). Apply to re-blend.",t.strokes.length,100*a/t.forced.length,100*o/t.forced.length,e.value),
this.undoButton.enabled=t.strokes.length>0,this.redoButton.enabled=null!==t.redo,this.redraw(!0)}catch(t){console.criticalln(t.toString())}finally{this.busy(!1)
}}}editKey(t,r){if(!this.edit)return!1;let e=Date.now();if(t===this.lastKey.key&&e-this.lastKey.t<40)return!0;let a=!0
;return t===KeyCode.Z&&r&KeyModifier.Control?r&KeyModifier.Shift?this.redo():this.undo():a=!1,a&&(this.lastKey={key:t,t:e},this.preview.update()),a}run(t){
this.enabled=!1,console.show(),console.abortEnabled=!0;try{t()}catch(t){console.criticalln(t.toString()),
t instanceof Ht||new MessageBox(t.toString(),jt,StdIcon.Error,StdButton.Ok).execute()}finally{console.abortEnabled=!1,this.enabled=!0,
this.imageButton.enabled=this.editButton.enabled=null!==this.ctx,this.refreshAstrometry()}}build(){let t=this.selectedWindows();this.run(()=>{
console.noteln("<end><cbr><br>"+jt+" v"+qt+": "+t.length+" panel(s)"),this.edit&&this.closeEdit(),this.ctx=null,this.pv=null,this.strokes=[];let r=Yt(t,{
graxpert:this.gxCheck.checked});r.NC={tiles:{},bytes:0,kern:{},kept:1},r.R=null,r.mcache={},r.colors=function(t){
for(var r=[[1,.35,.3],[.25,.85,1],[1,.85,.2],[.85,.4,1],[.35,1,.4],[.35,.5,1],[1,.6,.15],[1,.45,.75],[.6,1,.85],[.75,.75,.4]],e=[],a=0;a<t;a++)if(a<r.length)e.push(r[a]);else{
var o=.618034*a%1*6,i=Math.floor(o),n=o-i,s=.3,h=1-.7*n,l=.3+.7*n;e.push([[1,l,s],[h,1,s],[s,1,l],[s,h,1],[l,s,1],[1,s,h]][i%6])}return e}(r.names.length),
r.argb=r.colors.map(t=>(4278190080|Math.round(255*t[0])<<16|Math.round(255*t[1])<<8|Math.round(255*t[2]))>>>0),r.labels=zt(r.S);let e=(a=r.S,
Math.max(2,Math.round(Math.max(a.W,a.H)/1800)));var a;this.ctx=r,this.showPanels(),
r.gxSuggest&&new MessageBox("<p>Strong or complex background gradients were detected. If seams or blotches remain visible, tick <i>Remove gradients with GraXpert</i> and build again.</p>",jt,StdIcon.Information,StdButton.Ok).execute(),
r.excluded.length&&new MessageBox("<p>The mosaic was built from "+r.names.length+" panels. Left out:</p><ul>"+r.excluded.map(t=>"<li><b>"+t.id+"</b>: "+t.reason+"</li>").join("")+"</ul>",jt,StdIcon.Warning,StdButton.Ok).execute(),
this.pv={b:e,stf:Bt(r.S,e).stf,tg:null,prot:null},console.noteln("Preview: noise synthesis (once; then sliders only rescale it)"),this.recompute(),
this.preview.zoom=1,
this.preview.ox=this.preview.oy=0,this.redraw(!0),console.noteln("Zoom into the preview to check the result; Create image makes the mosaic.")})}makeImage(){
this.ctx&&this.run(()=>{let t=function(t,r){let a=new ElapsedTime,o=t=>{console.writeln(format("%7.1f s  ",a.value)+t),Et()},i=t.S,n=i.nc,s=xt(i,t.sig,r)
;console.noteln("<end><cbr>Noise transition x"+format("%.2f",r.blend)+", object detection "+format("%.2f",r.maskStrength)+", mask softness "+format("%.0f",r.maskFeather)+" px"),
console.writeln(format("Noise transition x%.2f, object protection %.2f, mask softness %.0f px",r.blend,r.maskStrength,r.maskFeather)),
console.writeln("Transition width per panel (px): "+t.names.map((t,r)=>t+" "+s.widths[r].toFixed(0)).join(", ")),t.mcache[2]||(t.mcache[2]={})
;let l=function(t,r,e,a){return kt(t,r,e,a,2)}(i,s,t.sig,{maskStrength:r.maskStrength,maskFeather:r.maskFeather,cache:t.mcache[2]})
;o(format("object protection: %.1f%% of the mosaic fully protected, %.1f%% partly",100*l.full,100*l.part));let f=Ct(i,s,t.spectra,l,{log:o,cache:t.NC});l=null,
o("noise added ("+f.tiles+" tiles)");for(let r of function(t,r,a){
for(var o=t.W,i=t.H,n=h(r,o,i),s=rt(n,o,i,6),l=et(n,o,i,1),f=["Result noise per region (luminance, robust): sigma px, sigma 3x3 bin, ratio 3x3/px"],u=0;u<a.length;u++){
for(var c=[],d=[],p=0;p<o*i;p+=3)t.labf[p]===u&&(c.push(n[p]-s[p]),d.push(l[p]-s[p]));if(!(c.length<3e3)){var v=e(c).sigma,m=e(d).sigma
;f.push("  "+T(a[u],10)+" "+v.toExponential(3)+"  "+m.toExponential(3)+"  "+(m/v).toFixed(3))}}return f}(i,f.chans,t.names))console.writeln(r)
;let u=r.crop?t.crop:[0,0,i.W,i.H],c=u[2]-u[0],d=u[3]-u[1],p=new ImageWindow(c,d,n,32,!0,t.isColor,"AutoPano"),v=p.mainView;v.beginProcess(UndoFlag.NoSwapFile)
;try{for(let t=0;t<n;++t){let e=f.chans[t];if(r.crop){let t=new Float32Array(c*d);for(let r=0;r<d;++r)t.set(e.subarray((u[1]+r)*i.W+u[0],(u[1]+r)*i.W+u[2]),r*c)
;e=t}v.image.setSamples(e,new Rect(0,0,c,d),t)}}finally{v.endProcess()}
r.crop&&console.writeln(format("Cropped to the filled area: x %d..%d, y %d..%d (%d x %d px, %.1f%% of the canvas)",u[0],u[2],u[1],u[3],c,d,100*c*d/(i.W*i.H)))
;let m=[];for(let e of r.crop?function(t,r,e){return t.map(function(t){return"CRPIX1"===t[0]?[t[0],t[1]-e[0],t[2]]:"CRPIX2"===t[0]?[t[0],t[1]-(r-e[3]),t[2]]:t})
}(t.wcs,i.H,u):t.wcs)m.push(new FITSKeyword(e[0],String(e[1]),e[2]))
;m.push(new FITSKeyword("HISTORY","",format("AutoPano %s: %d panels, seams + multiband blend",qt,t.nPanels))),
m.push(new FITSKeyword("HISTORY","",format("AutoPano noise transition x%.2f, object detection %.2f, mask softness %.0f px",r.blend,r.maskStrength,r.maskFeather))),
p.keywords=m;try{p.regenerateAstrometricSolution()}catch(t){console.warningln("** could not attach the astrometric solution: "+t.toString())}return p.show(),
p.zoomToFit(),console.noteln(format("<end><cbr>AutoPano: %s (%d x %d px) in %.1f s",v.id,c,d,a.value)),p}(this.ctx,this.options())
;this.infoLabel.text=this.info+" Created "+t.mainView.id+" (behind this dialog)."})}}!function(){if(console.hide(),
ImageWindow.openWindows.length<2)return void new MessageBox("Open the panel masters first (at least two).",jt,StdIcon.Information,StdButton.Ok).execute()
;let t=new $t;t.execute(),t.saveSettings()}()}();
